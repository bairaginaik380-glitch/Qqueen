#!/usr/bin/env python3
"""
Queen AI Voice Assistant - 100 Unique Access Token Generator & Admin Tool
Created for Developer Shyam Kadam

Format Rules:
- Exactly 10 characters
- First character: 'Q'
- Remaining 9 characters from [2-9A-HJ-NP-Z] (excludes 0, O, 1, I)
- Cryptographically secure random generation
"""

import secrets
import hashlib
import json
import time
import os

# Unambiguous alphabet excluding 0, O, 1, I
ALPHABET = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"

def generate_queen_token():
    # 'Q' followed by 9 random characters from ALPHABET
    random_part = "".join(secrets.choice(ALPHABET) for _ in range(9))
    return f"Q{random_part}"

def generate_100_tokens():
    tokens = set()
    while len(tokens) < 100:
        tokens.add(generate_queen_token())

    records = []
    plain_export = []

    for idx, token in enumerate(sorted(list(tokens)), start=1):
        token_hash = hashlib.sha256(token.encode('utf-8')).hexdigest()
        plain_export.append({
            "id": idx,
            "token": token,
            "masked": f"{token[:3]}••••{token[-2:]}"
        })
        records.append({
            "id": idx,
            "token_prefix": token[:3],
            "sha256_hash": token_hash,
            "status": "ACTIVE",  # ACTIVE, ASSIGNED, REVOKED
            "assigned_to": None,
            "created_at": int(time.time()),
            "last_used_at": None,
            "usage_count": 0,
            "rate_limit_per_min": 60
        })

    os.makedirs(os.path.dirname(os.path.abspath(__file__)), exist_ok=True)

    # 1. Server database registry (secure hashed records)
    with open("queen-admin/tokens_registry.json", "w") as f:
        json.dump({
            "generated_at": int(time.time()),
            "total_tokens": 100,
            "records": records
        }, f, indent=2)

    # 2. Owner distribution sheet (confidential plain tokens for initial user onboarding)
    with open("queen-admin/owner_distribution_list.txt", "w") as f:
        f.write("# QUEEN AI - CONFIDENTIAL 100 INITIAL ACCESS TOKENS\n")
        f.write("# Generated for Developer Shyam Kadam\n")
        f.write("# Format: Q[2-9A-HJ-NP-Z]{9}\n\n")
        for item in plain_export:
            f.write(f"Token #{item['id']:03d}: {item['token']}\n")

    print(f"Successfully generated 100 unique Queen Access Tokens!")
    print(f"Hashed registry saved to: queen-admin/tokens_registry.json")
    print(f"Distribution list saved to: queen-admin/owner_distribution_list.txt")

if __name__ == "__main__":
    generate_100_tokens()
