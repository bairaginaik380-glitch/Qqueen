package com.example.command

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

data class ContactMatch(
    val contactId: String,
    val name: String,
    val phoneNumber: String,
    val typeLabel: String = "Mobile"
)

sealed class ContactLookupResult {
    data class Found(val contact: ContactMatch) : ContactLookupResult()
    data class Ambiguous(val query: String, val matches: List<ContactMatch>) : ContactLookupResult()
    data class NotFound(val query: String) : ContactLookupResult()
    object PermissionDenied : ContactLookupResult()
    data class Error(val message: String) : ContactLookupResult()
}

class ContactsHelper {

    fun hasContactsPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Looks up contacts matching the given query by searching phone records.
     * Safely handles permissions, missing contacts, and ambiguous matches.
     */
    fun searchContact(context: Context, query: String): ContactLookupResult {
        if (!hasContactsPermission(context)) {
            return ContactLookupResult.PermissionDenied
        }

        val cleanedQuery = query.trim()
        if (cleanedQuery.isEmpty()) {
            return ContactLookupResult.NotFound(query)
        }

        return try {
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.TYPE
            )

            val uri: Uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
            val selectionArgs = arrayOf("%$cleanedQuery%")

            val matches = mutableListOf<ContactMatch>()
            val resolver = context.contentResolver

            // 1. First attempt targeted query with LIKE
            var cursor: Cursor? = resolver.query(
                uri,
                projection,
                selection,
                selectionArgs,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )

            // If targeted search returned no results, query all to perform token-level match
            if (cursor == null || cursor.count == 0) {
                cursor?.close()
                cursor = resolver.query(
                    uri,
                    projection,
                    null,
                    null,
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
                )
            }

            cursor?.use { c ->
                val idIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                val nameIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                val typeIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.TYPE)

                while (c.moveToNext()) {
                    val id = if (idIdx >= 0) c.getString(idIdx) ?: "" else ""
                    val name = if (nameIdx >= 0) c.getString(nameIdx) ?: "" else ""
                    val rawNumber = if (numIdx >= 0) c.getString(numIdx) ?: "" else ""
                    val type = if (typeIdx >= 0) c.getInt(typeIdx) else ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE

                    val cleanNum = cleanPhoneNumber(rawNumber)
                    if (cleanNum.isNotEmpty() && name.isNotBlank()) {
                        val typeLabel = when (type) {
                            ContactsContract.CommonDataKinds.Phone.TYPE_HOME -> "Home"
                            ContactsContract.CommonDataKinds.Phone.TYPE_WORK -> "Work"
                            else -> "Mobile"
                        }
                        if (matchesContactQuery(name, cleanedQuery)) {
                            matches.add(ContactMatch(id, name.trim(), cleanNum, typeLabel))
                        }
                    }
                }
            }

            // Deduplicate matches by contact ID or exact name
            val distinctByName = matches.groupBy { it.name.lowercase() }
            val distinctContacts = distinctByName.values.map { list ->
                // Prefer Mobile type if available
                list.find { it.typeLabel == "Mobile" } ?: list.first()
            }

            when {
                distinctContacts.isEmpty() -> {
                    ContactLookupResult.NotFound(cleanedQuery)
                }
                distinctContacts.size == 1 -> {
                    ContactLookupResult.Found(distinctContacts.first())
                }
                else -> {
                    // Check if one exact match exists
                    val exactMatch = distinctContacts.find {
                        it.name.equals(cleanedQuery, ignoreCase = true)
                    }
                    if (exactMatch != null) {
                        ContactLookupResult.Found(exactMatch)
                    } else {
                        ContactLookupResult.Ambiguous(cleanedQuery, distinctContacts)
                    }
                }
            }
        } catch (e: Exception) {
            ContactLookupResult.Error("Error querying contacts: ${e.localizedMessage}")
        }
    }

    private fun matchesContactQuery(contactName: String, query: String): Boolean {
        val nameLower = contactName.lowercase()
        val queryLower = query.lowercase()

        if (nameLower.contains(queryLower)) return true

        // Check token matches (e.g., query "Rahul" matches "Rahul Sharma" or "Dr. Rahul")
        val tokens = nameLower.split(" ", ".", "-", "_").filter { it.isNotBlank() }
        val queryTokens = queryLower.split(" ", ".", "-", "_").filter { it.isNotBlank() }

        return queryTokens.any { qTok -> tokens.any { it.startsWith(qTok) || it == qTok } }
    }

    companion object {
        fun cleanPhoneNumber(rawNumber: String): String {
            val sb = StringBuilder()
            rawNumber.forEach { ch ->
                if (ch.isDigit() || ch == '+') {
                    sb.append(ch)
                }
            }
            return sb.toString()
        }
    }
}
