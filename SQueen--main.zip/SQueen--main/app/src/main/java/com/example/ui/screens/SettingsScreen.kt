package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.QueenBackground
import com.example.ui.theme.QueenBorder
import com.example.ui.theme.QueenBorderGold
import com.example.ui.theme.QueenError
import com.example.ui.theme.QueenGold
import com.example.ui.theme.QueenGoldSoft
import com.example.ui.theme.QueenSuccess
import com.example.ui.theme.QueenSurface
import com.example.ui.theme.QueenSurfaceVariant
import com.example.ui.theme.QueenTextMuted
import com.example.ui.theme.QueenTextPrimary
import com.example.ui.viewmodel.AarohiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: AarohiViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToUserName: () -> Unit,
    onNavigateToVoiceSelection: () -> Unit,
    onNavigateToApiKey: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    onNavigateToStorageMemory: () -> Unit,
    onNavigateToAbout: () -> Unit,
    onNavigateToLearnMore: () -> Unit
) {
    val userName by viewModel.userName.collectAsState()
    val selectedVoiceId by viewModel.selectedVoiceId.collectAsState()
    val isSetupComplete by viewModel.isSetupComplete.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        containerColor = QueenBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Settings",
                        fontWeight = FontWeight.Bold,
                        color = QueenTextPrimary,
                        fontSize = 20.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("settings_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Home",
                            tint = QueenTextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = QueenBackground
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. User Name
            SettingsMenuItem(
                title = "User Name",
                subtitle = if (userName.isNotBlank()) userName else "Not configured (Optional)",
                icon = Icons.Default.Person,
                testTag = "menu_user_name",
                onClick = onNavigateToUserName
            )

            // 2. Select Voice
            SettingsMenuItem(
                title = "Select Voice",
                subtitle = "$selectedVoiceId voice selected",
                icon = Icons.Default.RecordVoiceOver,
                testTag = "menu_select_voice",
                onClick = onNavigateToVoiceSelection
            )

            // 3. API & Key
            SettingsMenuItem(
                title = "API & Key",
                subtitle = if (isSetupComplete) "Verified & Active" else "Setup Required",
                statusBadge = if (isSetupComplete) "Verified" else "Required",
                statusColor = if (isSetupComplete) QueenSuccess else QueenError,
                icon = Icons.Default.Key,
                testTag = "menu_api_and_key",
                onClick = onNavigateToApiKey
            )

            // 4. Permissions (Directly below API & Key)
            SettingsMenuItem(
                title = "Permissions",
                subtitle = "Microphone, Camera & App Access",
                icon = Icons.Default.Security,
                testTag = "menu_permissions",
                onClick = onNavigateToPermissions
            )

            // 5. Storage & Memory (Directly below Permissions)
            SettingsMenuItem(
                title = "Storage & Memory",
                subtitle = "Manage backup, history & cache",
                icon = Icons.Default.Storage,
                testTag = "menu_storage_and_memory",
                onClick = onNavigateToStorageMemory
            )

            // 5. Learn More (License & Device Policy)
            SettingsMenuItem(
                title = "Learn More",
                subtitle = "License, Device Binding & Recovery Policy",
                icon = Icons.Default.Info,
                testTag = "menu_learn_more",
                onClick = onNavigateToLearnMore
            )

            // 6. About
            SettingsMenuItem(
                title = "About",
                subtitle = "Queen v1.0 • By Shyam Kadam",
                icon = Icons.Default.Info,
                testTag = "menu_about",
                onClick = onNavigateToAbout
            )

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun SettingsMenuItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    testTag: String,
    statusBadge: String? = null,
    statusColor: Color = QueenGold,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = QueenSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, QueenBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    color = QueenSurfaceVariant,
                    shape = CircleShape,
                    border = BorderStroke(1.dp, QueenBorderGold),
                    modifier = Modifier.size(42.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = QueenGoldSoft,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Column {
                    Text(
                        text = title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = QueenTextPrimary
                    )
                    Text(
                        text = subtitle,
                        fontSize = 13.sp,
                        color = QueenTextMuted
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (statusBadge != null) {
                    Surface(
                        color = statusColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, statusColor.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = statusBadge,
                            color = statusColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                    contentDescription = null,
                    tint = QueenTextMuted,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}
