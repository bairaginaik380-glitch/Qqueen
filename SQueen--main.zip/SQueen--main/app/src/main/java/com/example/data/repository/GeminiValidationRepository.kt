package com.example.data.repository

import com.example.data.model.CredentialValidationState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiValidationRepository(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
) {

    suspend fun validateKey(apiKey: String): CredentialValidationState = withContext(Dispatchers.IO) {
        val trimmed = apiKey.trim()
        if (trimmed.isEmpty()) {
            return@withContext CredentialValidationState.Invalid("Gemini API Key is missing.")
        }
        if (trimmed.contains("MY_GEMINI_API_KEY") || trimmed.length < 20) {
            return@withContext CredentialValidationState.Invalid("Invalid Gemini API key length or placeholder format.")
        }

        try {
            // Validate against Google Generative Language API
            val url = "https://generativelanguage.googleapis.com/v1beta/models?key=$trimmed"
            val request = Request.Builder()
                .url(url)
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    return@withContext CredentialValidationState.Valid
                } else {
                    val code = response.code
                    val errorBody = response.body?.string() ?: ""
                    val message = try {
                        val json = JSONObject(errorBody)
                        json.optJSONObject("error")?.optString("message")
                            ?: "HTTP $code: Invalid API Key or Unauthorized."
                    } catch (e: Exception) {
                        "HTTP $code: API Key validation failed."
                    }
                    return@withContext CredentialValidationState.Invalid(message)
                }
            }
        } catch (e: Exception) {
            return@withContext CredentialValidationState.Invalid(
                "Network error validating Gemini API Key: ${e.localizedMessage ?: "Unknown error"}"
            )
        }
    }
}
