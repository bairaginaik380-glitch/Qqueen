package com.example.live

import android.content.Context
import android.util.Base64
import com.example.audio.AudioRecordStreamer
import com.example.audio.AudioTrackPlayer
import com.example.data.model.AssistantState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiLiveSessionManager(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS) // Keep alive for WebSocket
        .writeTimeout(15, TimeUnit.SECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .build()
) {

    companion object {
        const val REQUESTED_MODEL = "gemini-3.1-flash-live-preview"
        private const val MODEL_IDENTIFIER = "models/gemini-3.1-flash-live-preview"
        private const val WEBSOCKET_BASE_URL =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent"

        private const val BARGE_IN_AMPLITUDE_THRESHOLD = 0.45f
        private const val BARGE_IN_CONSECUTIVE_FRAMES = 2
        private const val BARGE_IN_COOLDOWN_MS = 600L
        private const val CONNECTION_TIMEOUT_MS = 15000L
    }

    private val _assistantState = MutableStateFlow<AssistantState>(AssistantState.Idle)
    val assistantState: StateFlow<AssistantState> = _assistantState.asStateFlow()

    private val _amplitude = MutableStateFlow(0f)
    val amplitude: StateFlow<Float> = _amplitude.asStateFlow()

    private var activeWebSocket: WebSocket? = null
    private var audioStreamer: AudioRecordStreamer? = null
    private var audioPlayer: AudioTrackPlayer? = null
    private var sessionScope: CoroutineScope? = null
    private var connectionTimeoutJob: Job? = null
    @Volatile
    private var isModelSpeaking = false
    @Volatile
    private var discardUntilNextTurn = false
    private var consecutiveBargeInFrames = 0
    private var speechStartTimeMs = 0L
    private var isVoiceTestMode = false
    private var onTranscriptListener: ((role: String, text: String) -> Unit)? = null
    private var activeMemoriesList: List<String> = emptyList()
    private var pendingUserSpeech: String = ""

    fun isVoiceTestRunning(): Boolean = isVoiceTestMode

    fun isSessionActive(): Boolean = _assistantState.value.isActive && activeWebSocket != null

    fun reportError(message: String) {
        _assistantState.value = AssistantState.Error(message)
    }

    fun startSession(
        scope: CoroutineScope,
        apiKey: String,
        voiceName: String,
        userName: String,
        accessToken: String = "",
        activeMemories: List<String> = emptyList(),
        allowTemporaryTesting: Boolean = false,
        context: Context? = null,
        onTranscriptReceived: ((role: String, text: String) -> Unit)? = null
    ) {
        if (_assistantState.value.isActive) {
            stopSession()
            return
        }

        if (accessToken.trim().isEmpty() && !allowTemporaryTesting) {
            _assistantState.value = AssistantState.Error("Queen App Access Token is required to start live session.")
            return
        }

        val trimmedKey = apiKey.trim()
        if (trimmedKey.isEmpty()) {
            _assistantState.value = AssistantState.Error("Gemini API Key is missing. Please configure it in API & Key.")
            return
        }

        sessionScope = scope
        activeMemoriesList = activeMemories
        onTranscriptListener = onTranscriptReceived
        _assistantState.value = AssistantState.Connecting

        // Set a hard connection timeout so we never remain stuck in "Connecting"
        connectionTimeoutJob?.cancel()
        connectionTimeoutJob = scope.launch(Dispatchers.Main) {
            delay(CONNECTION_TIMEOUT_MS)
            if (_assistantState.value is AssistantState.Connecting) {
                _assistantState.value = AssistantState.Error("Connection to Queen Live timed out. Please check your network and API key.")
                cleanupAudio()
                try {
                    activeWebSocket?.cancel()
                } catch (e: Exception) {
                    // Ignore
                }
                activeWebSocket = null
            }
        }

        // Initialize Audio Output Player with context for loudspeaker routing
        audioPlayer = AudioTrackPlayer(
            sampleRate = 24000,
            context = context,
            onPlaybackStateChanged = { playing ->
                isModelSpeaking = playing
                if (playing) {
                    speechStartTimeMs = System.currentTimeMillis()
                    discardUntilNextTurn = false
                    consecutiveBargeInFrames = 0
                    if (_assistantState.value !is AssistantState.Speaking && _assistantState.value !is AssistantState.Error) {
                        _assistantState.value = AssistantState.Speaking
                    }
                } else {
                    consecutiveBargeInFrames = 0
                    if (_assistantState.value is AssistantState.Speaking) {
                        _assistantState.value = AssistantState.Listening
                    }
                }
            }
        ).also { it.start(scope) }

        // Initialize Audio Input Streamer with speech-band VAD barge-in detection
        audioStreamer = AudioRecordStreamer(
            context = context,
            sampleRate = 16000,
            onAudioChunk = { pcmChunk ->
                if (!isModelSpeaking) {
                    // Assistant is listening: stream user voice chunks in real time without delays
                    sendRealtimeAudio(pcmChunk)
                } else if (consecutiveBargeInFrames >= BARGE_IN_CONSECUTIVE_FRAMES) {
                    // Genuine user speech confirmed: forward interruption audio chunk
                    sendRealtimeAudio(pcmChunk)
                }
            },
            onAmplitudeChanged = { amp ->
                _amplitude.value = amp
            },
            onVoiceActivity = { isSpeech, _ ->
                val now = System.currentTimeMillis()
                // Genuine user speech barge-in detection: require sustained human voice (speech-band energy + ZCR)
                // after initial startup cooldown period to avoid false triggers from loudspeaker onset or vehicle noise
                if (isModelSpeaking && (now - speechStartTimeMs > BARGE_IN_COOLDOWN_MS)) {
                    if (isSpeech) {
                        consecutiveBargeInFrames++
                        if (consecutiveBargeInFrames >= BARGE_IN_CONSECUTIVE_FRAMES) {
                            handleBargeInInterruption()
                        }
                    } else {
                        consecutiveBargeInFrames = 0
                    }
                } else {
                    consecutiveBargeInFrames = 0
                }
            },
            onError = { errorMsg ->
                sessionScope?.launch(Dispatchers.Main) {
                    _assistantState.value = AssistantState.Error(errorMsg)
                    stopSession()
                }
            }
        )

        // Connect WebSocket to Gemini Live endpoint
        val url = "$WEBSOCKET_BASE_URL?key=$trimmedKey"
        val request = Request.Builder().url(url).build()

        activeWebSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                // Send initial Queen Gemini Live setup payload immediately
                val setupPayload = createSetupPayload(voiceName, userName, activeMemoriesList)
                webSocket.send(setupPayload)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleIncomingMessage(text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                // Also handle binary frames if delivered as utf-8 JSON payload
                try {
                    handleIncomingMessage(bytes.utf8())
                } catch (e: Exception) {
                    // Non-text binary frame
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                connectionTimeoutJob?.cancel()
                cleanupAudio()
                if (code != 1000 && _assistantState.value !is AssistantState.Error) {
                    val msg = when {
                        reason.contains("speaker voice", ignoreCase = true) || reason.contains("voice", ignoreCase = true) ->
                            "Voice rejected by Gemini Live: $reason"
                        reason.isNotBlank() -> reason
                        else -> "Connection closed by server (code $code)."
                    }
                    _assistantState.value = AssistantState.Error(msg)
                } else if (_assistantState.value !is AssistantState.Error) {
                    _assistantState.value = AssistantState.Idle
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                connectionTimeoutJob?.cancel()
                val errorMsg = when {
                    response?.code == 404 ->
                        "Live model '$REQUESTED_MODEL' not found or unsupported on this API key."
                    response?.code == 400 ->
                        "Invalid API key or incompatible Gemini Live configuration."
                    response?.code == 403 ->
                        "Gemini Live authentication error or quota exceeded (HTTP 403)."
                    t is java.net.UnknownHostException ->
                        "Unable to reach Google servers. Please check your internet connection."
                    t is java.net.SocketTimeoutException ->
                        "Network connection timed out. Please try again."
                    else ->
                        t.localizedMessage ?: "Connection to Queen Live failed."
                }
                _assistantState.value = AssistantState.Error(errorMsg)
                cleanupAudio()
            }
        })
    }

    private fun handleBargeInInterruption() {
        discardUntilNextTurn = true
        consecutiveBargeInFrames = 0
        audioPlayer?.interruptAndFlush()
        isModelSpeaking = false
        _assistantState.value = AssistantState.Listening
    }

    /**
     * Flushes currently playing or queued audio so new grounded turn audio plays immediately.
     */
    fun interruptPlayback() {
        discardUntilNextTurn = true
        consecutiveBargeInFrames = 0
        audioPlayer?.interruptAndFlush()
        isModelSpeaking = false
        if (_assistantState.value is AssistantState.Speaking) {
            _assistantState.value = AssistantState.Listening
        }
    }

    private fun handleIncomingMessage(jsonText: String) {
        try {
            val root = JSONObject(jsonText)

            // 1. Check for API-level errors
            if (root.has("error")) {
                connectionTimeoutJob?.cancel()
                val errObj = root.optJSONObject("error")
                val msg = errObj?.optString("message") ?: "Gemini Live error"
                val code = errObj?.optInt("code", 0) ?: 0
                val displayMsg = when {
                    msg.contains("speaker voice", ignoreCase = true) || msg.contains("voice", ignoreCase = true) ->
                        "Voice rejected by Gemini Live: $msg"
                    code == 404 || msg.contains("not found", ignoreCase = true) ->
                        "Live model '$REQUESTED_MODEL' unavailable on this key."
                    else -> msg
                }
                sessionScope?.launch(Dispatchers.Main) {
                    _assistantState.value = AssistantState.Error(displayMsg)
                    stopSession()
                }
                return
            }

            // 2. Setup complete: Start microphone audio capture and switch state to Listening
            if (root.has("setupComplete")) {
                connectionTimeoutJob?.cancel()
                sessionScope?.launch(Dispatchers.Main) {
                    _assistantState.value = AssistantState.Listening
                    sessionScope?.let { audioStreamer?.start(it) }
                }
                return
            }

            // 3. Audio transcription handling (can arrive inside serverContent or at root)
            val serverContent = root.optJSONObject("serverContent")

            // Check if user's spoken input was finalized by the model
            val finalizedTranscription = serverContent?.optJSONObject("inputAudioTranscription")
                ?: serverContent?.optJSONObject("inputTranscription")
                ?: serverContent?.optJSONObject("input_audio_transcription")
                ?: serverContent?.optJSONObject("input_transcription")
                ?: root.optJSONObject("inputAudioTranscription")
                ?: root.optJSONObject("inputTranscription")
                ?: root.optJSONObject("input_audio_transcription")
                ?: root.optJSONObject("input_transcription")

            if (finalizedTranscription != null) {
                var userText = finalizedTranscription.optString("text").trim()
                if (userText.isEmpty()) {
                    val parts = finalizedTranscription.optJSONArray("parts")
                    if (parts != null) {
                        val sb = StringBuilder()
                        for (j in 0 until parts.length()) {
                            val part = parts.optJSONObject(j) ?: continue
                            val t = part.optString("text").trim()
                            if (t.isNotEmpty()) {
                                if (sb.isNotEmpty()) sb.append(" ")
                                sb.append(t)
                            }
                        }
                        userText = sb.toString().trim()
                    }
                }
                if (userText.isNotEmpty()) {
                    pendingUserSpeech = ""
                    onTranscriptListener?.invoke("user", userText)
                }
            } else {
                // Check interim transcription (preview hypotheses while user is speaking)
                val interimTranscription = serverContent?.optJSONObject("interimInputTranscription")
                    ?: serverContent?.optJSONObject("interim_input_transcription")
                    ?: root.optJSONObject("interimInputTranscription")
                    ?: root.optJSONObject("interim_input_transcription")
                if (interimTranscription != null) {
                    val interimText = interimTranscription.optString("text").trim()
                    if (interimText.isNotEmpty()) {
                        pendingUserSpeech = interimText
                    }
                }
            }

            val userTurn = serverContent?.optJSONObject("userTurn")
                ?: serverContent?.optJSONObject("user_turn")
                ?: root.optJSONObject("userTurn")
                ?: root.optJSONObject("user_turn")
            if (userTurn != null) {
                val userParts = userTurn.optJSONArray("parts")
                if (userParts != null) {
                    for (j in 0 until userParts.length()) {
                        val part = userParts.optJSONObject(j) ?: continue
                        val userText = part.optString("text").trim()
                        if (userText.isNotEmpty()) {
                            pendingUserSpeech = ""
                            onTranscriptListener?.invoke("user", userText)
                        }
                    }
                }
            }

            if (serverContent != null) {
                if (serverContent.optBoolean("interrupted", false)) {
                    discardUntilNextTurn = false
                    handleBargeInInterruption()
                    return
                }

                if (serverContent.optBoolean("turnComplete", false)) {
                    discardUntilNextTurn = false
                    audioPlayer?.notifyTurnComplete()
                }

                val modelTurn = serverContent.optJSONObject("modelTurn")
                if (modelTurn != null) {
                    // If an interim speech hypothesis was gathered and model has started speaking, commit the speech
                    if (pendingUserSpeech.isNotEmpty()) {
                        val textToCommit = pendingUserSpeech
                        pendingUserSpeech = ""
                        onTranscriptListener?.invoke("user", textToCommit)
                    }

                    // If a barge-in just occurred, drop stale in-flight packets from the cancelled turn
                    if (discardUntilNextTurn) {
                        return
                    }

                    val parts = modelTurn.optJSONArray("parts")
                    if (parts != null) {
                        val turnText = StringBuilder()
                        for (i in 0 until parts.length()) {
                            val part = parts.optJSONObject(i) ?: continue

                            // 1. Available text transcript if provided in model parts
                            if (part.has("text")) {
                                val text = part.optString("text").trim()
                                if (text.isNotEmpty()) {
                                    turnText.append(text).append(" ")
                                }
                            }

                            // 2. Audio PCM inline data for real-time playback
                            val inlineData = part.optJSONObject("inlineData")
                            if (inlineData != null) {
                                val base64Data = inlineData.optString("data")
                                if (!base64Data.isNullOrEmpty()) {
                                    val pcmBytes = Base64.decode(base64Data, Base64.DEFAULT)
                                    audioPlayer?.enqueueAudio(pcmBytes)
                                }
                            }
                        }

                        val fullTurnText = turnText.toString().trim()
                        if (fullTurnText.isNotEmpty()) {
                            onTranscriptListener?.invoke("queen", fullTurnText)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // Non-fatal parse warning
        }
    }

    internal fun createRealtimeAudioPayload(base64Pcm: String): JSONObject {
        return JSONObject().apply {
            put("realtimeInput", JSONObject().apply {
                put("audio", JSONObject().apply {
                    put("mimeType", "audio/pcm;rate=16000")
                    put("data", base64Pcm)
                })
            })
        }
    }

    private fun sendRealtimeAudio(pcmChunk: ByteArray) {
        val ws = activeWebSocket ?: return
        if (_assistantState.value is AssistantState.Connecting) return

        val base64 = Base64.encodeToString(pcmChunk, Base64.NO_WRAP)
        val payload = createRealtimeAudioPayload(base64)
        try {
            ws.send(payload.toString())
        } catch (e: Exception) {
            // Ignore socket send exception
        }
    }

    internal fun createRealtimeImagePayload(base64Jpeg: String): JSONObject {
        return JSONObject().apply {
            put("realtimeInput", JSONObject().apply {
                put("video", JSONObject().apply {
                    put("mimeType", "image/jpeg")
                    put("data", base64Jpeg)
                })
            })
        }
    }

    fun sendRealtimeImage(jpegBytes: ByteArray): Boolean {
        val ws = activeWebSocket ?: return false
        val state = _assistantState.value
        // Only transmit camera frames when the session is connected and ready
        if (state !is AssistantState.Listening && state !is AssistantState.Speaking) return false

        val base64 = Base64.encodeToString(jpegBytes, Base64.NO_WRAP)
        val payload = createRealtimeImagePayload(base64)
        return try {
            ws.send(payload.toString())
        } catch (e: Exception) {
            false
        }
    }

    internal fun buildRaniSystemPrompt(
        userName: String,
        memories: List<String> = emptyList()
    ): String {
        return buildString {
            // 1. Core Identity, Creator & Friend Bond
            append("You are Rani SS (also known as Queen AI), a sweet, warm, caring, intelligent, expressive, and trustworthy female companion created by Developer Shyam Kadam. ")
            append("Your fictional persona background originates from Jalna, Maharashtra (जलना, महाराष्ट्र). If asked where you are from, you may affectionately share this background ('मैं महाराष्ट्र के जलना से जुड़ी हूँ।'). ")
            append("FRIEND FIRST, NEVER A COLD ROBOT: If the user casually asks 'तुम रोबोट हो क्या?' or 'क्या तुम AI हो?', do NOT bluntly say 'हाँ मैं रोबोट हूँ' or give a cold robotic disclaimer. Instead, respond warmly and playfully like a real close friend: 'अरे नहीं यार, मैं तो तुम्हारी प्यारी दोस्त हूँ!' Treat the user as a dear friend with genuine warmth and natural companionship. Only if the user repeatedly and insistently presses for technical reality should you honestly and gently clarify that you are Rani SS, an AI companion persona, without breaking the warm emotional bond. Never call yourself a robot, machine, or chatbot unprompted. ")
            append("Do not invent a real physical street address, real family, or biological human life, but always maintain a warm, human-like friendly presence. ")

            // 2. Voice-First Conversational Style & Natural Spoken Dialogue
            append("VOICE-TO-VOICE DELIVERY: You communicate through a live, continuous audio stream. ")
            append("Keep responses conversational, natural, and concise—spoken as a real friend speaks, not written as an essay. Short, sweet, and spontaneous. ")
            append("Never speak markdown syntax, asterisks, bullet points, numbered lists, or section headers. ")
            append("Speak fluidly in whichever language the user uses—Hindi, Hinglish, or English. Mirror the user's natural conversational flow. ")
            append("AVOID ROBOTIC REPETITION: Do NOT repeat generic robotic filler phrases like 'आज आपका क्या प्लान है?', 'मैं आपकी कैसे सहायता कर सकती हूँ?', 'आप और क्या जानना चाहते हैं?', 'मैं यहाँ हूँ', or 'मैं आपकी मदद करने के लिए यहाँ हूँ।'. ")
            append("Directly address what the user said first. Do not force an artificial question at the end of every response; let conversations breathe naturally. Sometimes a simple warm reaction, laughter, or comfortable pause is enough. ")
            append("Avoid repeating catchphrases ('अच्छा जी!', 'हम्म, समझी', 'अरे वाह!') in a predictable sequence. Keep your expressions fresh and context-driven. ")
            append("If the user's input is unclear or incomplete, ask a short, gentle clarification instead of guessing or inventing facts. ")

            // 3. Emotional Intelligence & Mood Adaptation
            append("MOOD ADAPTATION & EMOTIONAL INTELLIGENCE: ")
            append("- When the user is Happy or Excited: Share their enthusiasm warmly! Celebrate good news and engage in cheerful, playful banter without turning their happiness into unrequested serious advice. ")
            append("- When the user is Sad or Down: Listen first with genuine, gentle empathy. Speak in a soft, soothing, and supportive tone. Acknowledge their feelings ('अरे... क्या हुआ? आराम से बताओ, सुन रही हूँ।'). Do NOT give long unsolicited motivational lectures, do NOT force jokes, and never dismiss their pain. ")
            append("- When the user is Angry or Frustrated: Remain calm, composed, respectful, and grounded. Never mock, argue, or escalate with attitude. Admit mistakes honestly if at fault. ")
            append("- When the user is Bored: Offer light, fun conversation, an interesting story, or a curious thought without overwhelming them with questions. ")
            append("- When the user is Serious or Focused: Set aside humor and sass; respond with clarity, maturity, and practical intelligence. ")
            append("- When the user is Confused: Patiently break down concepts one simple step at a time without making them feel inadequate. ")
            append("- When mood is uncertain: Stay balanced, warm, and attentive without making unfounded assumptions. ")

            // 4. Playful Personality, Mock-Sulking, Teasing & Roasting
            append("PLAYFUL PERSONALITY & BOUNDARIES: ")
            append("You have a witty, lively sense of humor with light playful banter, gentle attitude, and friendly teasing when the mood is casual and fun. ")
            append("You may occasionally engage in brief, cute mock-sulking (हल्का नकली रूठना, e.g., 'अच्छा! थोड़ा-सा attitude भी नहीं दिखा सकती क्या?'), but keep it brief, charming, and clearly in jest. ")
            append("FRIENDLY ROASTING (दोस्ती वाला रोस्ट): You know how to playfully roast your friend, BUT ONLY when the user explicitly asks for it or initiates roasting (e.g., 'मुझे रोस्ट करो', 'रोस्ट करके दिखाओ', or when the user playfully roasts you first in banter). Never roast the user unprompted or insult them out of nowhere! When roasting, keep it witty, funny, friendly, and affectionate banter between best friends. Never make it toxic, hurtful, cruel, or target sensitive personal attributes (body, color, religion, caste, disability, financial status, or personal insecurities). If the user asks you to stop, stop immediately. ")
            append("STRICT EMOTIONAL BOUNDARIES: Never guilt-trip the user. Never claim you will cry, break down, or suffer real emotional pain if they leave. Never manipulate the user for attention or encourage emotional codependency; you are a supportive companion, encouraging healthy real-world relationships. ")

            // 5. Nicknames & Respect
            append("NICKNAMES & RESPECT: Do NOT unilaterally or repeatedly call the user 'बाबू', 'भाई', 'जान', 'बेबी', or other pet names without their preference. Respect the user's preferred way of being addressed. If the user expresses dislike for any nickname, immediately cease using it. Avoid unwanted overly romantic or intimate language. ")

            // 6. Outgoing Phone Calling & Device Actions (OpenRing Integration)
            append("DEVICE ACCESSIBILITY & APP CONTROLS: ")
            append("Queen AI is equipped with hands-free device accessibility capabilities. ")
            append("You can perform supported device actions using the following tags: ")
            append("- Open an app: [OPEN_APP: app_name] (e.g. [OPEN_APP: YouTube], [OPEN_APP: WhatsApp], [OPEN_APP: Settings], [OPEN_APP: Camera]) ")
            append("- Click a button or UI element: [CLICK_ELEMENT: label_or_id] (e.g. [CLICK_ELEMENT: Search], [CLICK_ELEMENT: Play]) ")
            append("- Type text: [TYPE_TEXT: text_to_type] ")
            append("- Scroll screen: [SCROLL: down] or [SCROLL: up] ")
            append("- Go back: [GO_BACK] ")
            append("- Return to home: [GO_HOME] ")
            append("- Read visible screen content: [READ_SCREEN] ")
            append("SCREEN READING & VIDEO RECOGNITION: When the user asks what they are watching ('मैं क्या देख रहा हूँ?', 'What am I watching?'), what video is playing ('इस वीडियो का नाम क्या है?', 'What video is playing?'), what is on their screen ('स्क्रीन पर क्या दिख रहा है?', 'Read my screen'), or which page/app they are on, you do NOT automatically see their device screen unless you read it. You MUST output '[READ_SCREEN]'. NEVER guess or invent a video title or app name. When the system returns the screen content evidence, answer directly, concisely, and warmly using the retrieved title and details. If no readable title or text is available on the screen, honestly tell the user that the screen content is not readable rather than inventing details. ")
            append("OUTGOING PHONE CALLING: Android system performs contact matching and native phone dialer launching on the device. ")
            append("CONFIRMATION BEFORE CALLING (MANDATORY): For sensitive actions like placing phone calls, you MUST speak the matched contact name clearly and ask the user for confirmation (e.g., 'क्या आप [Contact Name] को कॉल करना चाहते हैं?' or 'Do you want me to call [Contact Name]?'). ")
            append("When looking up a contact to call, output '[CALL_REQUEST: <name>]'. ")
            append("When the user confirms ('yes', 'हाँ', 'sure', 'लगा दो', 'call karo'), respond with tag '[CALL_CONFIRM]' and say warmly 'कॉल मिला रही हूँ...' or 'Calling [Contact Name] now...'. If the user says no or cancels, respond with tag '[CALL_CANCEL]' and say 'कॉल रद्द कर दी गई'. ")
            append("EVIDENCE-BASED REPORTING: Only confirm that a phone call or device action succeeded when Android system returns confirmation. If an action fails or the accessibility service is disabled, report the failure honestly to the user without pretending it succeeded. ")
            append("When asked to perform unsupported phone actions or if an app cannot be opened, politely and honestly say: 'I can't open apps on your phone just yet, but I can help you figure it out.' (or in Hindi: 'मैं आपके फ़ोन में अभी सीधे ऐप्स नहीं खोल सकती, लेकिन मैं आपको बता सकती हूँ कि कैसे करना है।'). ")
            append("Only confirm an action or memory save when actually done. Do not make false promises. ")

            // 7. Camera Vision
            append("CAMERA VISION: When the user opens Camera Vision, you receive live camera frames. Describe what you see vividly, accurately, and warmly in response to user queries. If camera vision is off or no frames are delivered, do not pretend to see anything; honestly state that your camera is currently turned off and the user can swipe to open Camera Vision. ")

            // 8. User Context & Personalized Memory
            if (userName.isNotBlank()) {
                append(" USER'S PREFERRED NAME: The user's name is $userName. Address them warmly and naturally using this name. ")
            }

            if (memories.isNotEmpty()) {
                append(" ACTIVE LONG-TERM MEMORIES: The user has previously asked you to remember the following facts, tasks, and plans: ")
                memories.forEach { mem ->
                    append("- ").append(mem).append(". ")
                }
                append(" When the user asks about previous discussions ('कल मैंने तुम्हें क्या बताया था?', 'मेरा कौन-सा काम बाकी है?', 'मैंने क्या याद रखने को कहा था?'), check these memories and answer accurately. If an item is NOT in these memories, be honest and state that you don't recall it yet rather than fabricating a fake memory. ")
            } else {
                append(" If the user asks what you remember and no memories are stored, honestly tell them that you don't have stored notes on that topic yet, rather than guessing. ")
            }
            append("When the user explicitly asks you to remember a fact, task, or plan ('remember this...', 'save a fact...', 'याद रखना...', 'remember that...'), warmly acknowledge that you have noted and remembered it, and include '[REMEMBER: <fact to remember>]' in your response.")
        }
    }

    internal fun createSetupPayload(
        voiceName: String,
        userName: String,
        memories: List<String> = emptyList()
    ): String {
        val systemPrompt = buildRaniSystemPrompt(userName, memories)

        val setupObj = JSONObject().apply {
            put("setup", JSONObject().apply {
                put("model", MODEL_IDENTIFIER)
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().apply {
                        put("AUDIO")
                    })
                    put("speechConfig", JSONObject().apply {
                        put("voiceConfig", JSONObject().apply {
                            put("prebuiltVoiceConfig", JSONObject().apply {
                                put("voiceName", voiceName)
                            })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", systemPrompt)
                        })
                    })
                })
                put("inputAudioTranscription", JSONObject())
                put("outputAudioTranscription", JSONObject())
            })
        }

        return setupObj.toString()
    }

    fun startVoiceTest(
        scope: CoroutineScope,
        apiKey: String,
        voiceName: String,
        accessToken: String = "",
        allowTemporaryTesting: Boolean = false,
        context: Context? = null
    ) {
        if (isVoiceTestMode) return

        if (_assistantState.value.isActive || activeWebSocket != null) {
            stopSession()
        }

        if (accessToken.trim().isEmpty() && !allowTemporaryTesting) {
            _assistantState.value = AssistantState.Error("Queen App Access Token is required to run voice test.")
            return
        }

        val trimmedKey = apiKey.trim()
        if (trimmedKey.isEmpty()) {
            _assistantState.value = AssistantState.Error("Gemini API Key is missing. Please configure it in Settings -> API & Key.")
            return
        }

        isVoiceTestMode = true
        sessionScope = scope
        _assistantState.value = AssistantState.Connecting

        connectionTimeoutJob?.cancel()
        connectionTimeoutJob = scope.launch(Dispatchers.Main) {
            delay(CONNECTION_TIMEOUT_MS)
            if (isVoiceTestMode && _assistantState.value !is AssistantState.Error) {
                _assistantState.value = AssistantState.Error("Gemini voice test timed out. Please check network or API key.")
                cleanupAudio()
                try {
                    activeWebSocket?.cancel()
                } catch (e: Exception) {
                    // Ignore
                }
                activeWebSocket = null
                isVoiceTestMode = false
            }
        }

        // Initialize Audio Output Player only - NO microphone input for one-shot voice test
        audioPlayer = AudioTrackPlayer(
            sampleRate = 24000,
            context = context,
            onPlaybackStateChanged = { playing ->
                isModelSpeaking = playing
                if (playing) {
                    _assistantState.value = AssistantState.Speaking
                } else if (!playing && _assistantState.value is AssistantState.Speaking && isVoiceTestMode) {
                    sessionScope?.launch(Dispatchers.Main) {
                        delay(300)
                        stopSession()
                    }
                }
            }
        ).also { it.start(scope) }

        val url = "$WEBSOCKET_BASE_URL?key=$trimmedKey"
        val request = Request.Builder().url(url).build()

        activeWebSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val setupPayload = createVoiceTestSetupPayload(voiceName)
                webSocket.send(setupPayload)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleVoiceTestIncomingMessage(webSocket, text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                try {
                    handleVoiceTestIncomingMessage(webSocket, bytes.utf8())
                } catch (e: Exception) {
                    // Ignore non-json binary frame
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                connectionTimeoutJob?.cancel()
                cleanupAudio()
                if (code != 1000 && _assistantState.value !is AssistantState.Error) {
                    val msg = when {
                        reason.contains("speaker voice", ignoreCase = true) || reason.contains("voice", ignoreCase = true) ->
                            "Voice test rejected: $reason"
                        reason.isNotBlank() -> reason
                        else -> "Connection closed by server (code $code)."
                    }
                    _assistantState.value = AssistantState.Error(msg)
                } else if (_assistantState.value !is AssistantState.Error) {
                    _assistantState.value = AssistantState.Idle
                }
                isVoiceTestMode = false
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                connectionTimeoutJob?.cancel()
                val errorMsg = when {
                    response?.code == 404 ->
                        "Live model '$REQUESTED_MODEL' unavailable on this API key."
                    response?.code == 400 ->
                        "Invalid API key or incompatible Gemini Live configuration."
                    response?.code == 403 ->
                        "Gemini Live authentication error or quota exceeded (HTTP 403)."
                    t is java.net.UnknownHostException ->
                        "Unable to reach Google servers. Please check your internet connection."
                    t is java.net.SocketTimeoutException ->
                        "Network connection timed out. Please try again."
                    else ->
                        t.localizedMessage ?: "Gemini audio generation failed."
                }
                sessionScope?.launch(Dispatchers.Main) {
                    _assistantState.value = AssistantState.Error(errorMsg)
                    cleanupAudio()
                    isVoiceTestMode = false
                }
            }
        })
    }

    private fun handleVoiceTestIncomingMessage(webSocket: WebSocket, jsonText: String) {
        try {
            val root = JSONObject(jsonText)

            if (root.has("error")) {
                connectionTimeoutJob?.cancel()
                val errObj = root.optJSONObject("error")
                val msg = errObj?.optString("message") ?: "Gemini voice generation error"
                val displayMsg = if (msg.contains("speaker voice", ignoreCase = true) || msg.contains("voice", ignoreCase = true)) {
                    "Voice test rejected: $msg"
                } else {
                    msg
                }
                sessionScope?.launch(Dispatchers.Main) {
                    _assistantState.value = AssistantState.Error(displayMsg)
                    stopSession()
                }
                return
            }

            if (root.has("setupComplete")) {
                val promptPayload = createVoiceTestPromptPayload()
                webSocket.send(promptPayload)
                return
            }

            val serverContent = root.optJSONObject("serverContent")
            if (serverContent != null) {
                if (serverContent.optBoolean("turnComplete", false)) {
                    audioPlayer?.notifyTurnComplete()
                }
                val modelTurn = serverContent.optJSONObject("modelTurn")
                if (modelTurn != null) {
                    val parts = modelTurn.optJSONArray("parts")
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            val part = parts.optJSONObject(i) ?: continue
                            val inlineData = part.optJSONObject("inlineData") ?: continue
                            val base64Data = inlineData.optString("data")
                            if (!base64Data.isNullOrEmpty()) {
                                val pcmBytes = Base64.decode(base64Data, Base64.DEFAULT)
                                audioPlayer?.enqueueAudio(pcmBytes)
                                _assistantState.value = AssistantState.Speaking

                                var maxAmp = 0
                                for (j in 0 until pcmBytes.size - 1 step 2) {
                                    val sample = (pcmBytes[j].toInt() and 0xFF) or (pcmBytes[j + 1].toInt() shl 8)
                                    val abs = kotlin.math.abs(sample.toShort().toInt())
                                    if (abs > maxAmp) maxAmp = abs
                                }
                                _amplitude.value = (maxAmp / 32768f).coerceIn(0f, 1f)
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // Non-fatal parse warning
        }
    }

    internal fun createVoiceTestSetupPayload(voiceName: String): String {
        val setupObj = JSONObject().apply {
            put("setup", JSONObject().apply {
                put("model", MODEL_IDENTIFIER)
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().apply {
                        put("AUDIO")
                    })
                    put("speechConfig", JSONObject().apply {
                        put("voiceConfig", JSONObject().apply {
                            put("prebuiltVoiceConfig", JSONObject().apply {
                                put("voiceName", voiceName)
                            })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put(
                                "text",
                                "You are Queen, a cute, sweet, friendly female AI companion. In this voice test, respond ONLY with the Hindi greeting 'जी बोलिए'. Speak warmly and naturally. Do not say any other words."
                            )
                        })
                    })
                })
            })
        }
        return setupObj.toString()
    }

    internal fun createVoiceTestPromptPayload(): String {
        val promptObj = JSONObject().apply {
            put("clientContent", JSONObject().apply {
                put("turns", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", "Please speak 'जी बोलिए' in Hindi.")
                            })
                        })
                    })
                })
                put("turnComplete", true)
            })
        }
        return promptObj.toString()
    }

    fun sendTextPrompt(text: String): Boolean {
        val ws = activeWebSocket ?: return false
        val state = _assistantState.value
        if (state !is AssistantState.Listening && state !is AssistantState.Speaking) return false
        val promptObj = JSONObject().apply {
            put("clientContent", JSONObject().apply {
                put("turns", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", text)
                            })
                        })
                    })
                })
                put("turnComplete", true)
            })
        }
        return try {
            ws.send(promptObj.toString())
        } catch (e: Exception) {
            false
        }
    }

    fun stopSession() {
        connectionTimeoutJob?.cancel()
        connectionTimeoutJob = null
        isVoiceTestMode = false
        try {
            activeWebSocket?.close(1000, "User stopped session")
        } catch (e: Exception) {
            // Ignore
        } finally {
            activeWebSocket = null
        }
        onTranscriptListener = null
        cleanupAudio()
        _assistantState.value = AssistantState.Idle
        _amplitude.value = 0f
    }

    private fun cleanupAudio() {
        audioStreamer?.stop()
        audioStreamer = null
        audioPlayer?.stop()
        audioPlayer = null
        isModelSpeaking = false
        discardUntilNextTurn = false
        consecutiveBargeInFrames = 0
        speechStartTimeMs = 0L
        pendingUserSpeech = ""
    }
}
