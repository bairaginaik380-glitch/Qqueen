package com.example.data.repository

import android.content.Context
import com.example.data.model.CredentialValidationState
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.security.MessageDigest
import java.util.Date
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * AccessTokenRepository
 *
 * Securely validates Queen App Access Tokens either:
 * 1. Directly against Firebase Firestore with Firebase Anonymous Authentication (Zero-Server, Spark Free compatible)
 * 2. Via custom HTTP verification endpoint if explicitly configured.
 *
 * Enforces:
 * - Exactly 10 characters: Starts with 'Q' followed by 9 chars from [2-9A-HJ-NP-Z]
 * - Single-device registration enforcement (1 token = 1 phone)
 * - Strict rejection of invalid, expired, revoked, or already-bound tokens
 * - Zero testing bypasses or arbitrary token acceptance
 */
class AccessTokenRepository(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
) {

    companion object {
        const val TOKENS_COLLECTION = "queen_access_tokens"

        // Pattern: Starts with 'Q', followed by 9 chars from unambiguous uppercase & digits
        val QUEEN_TOKEN_REGEX = Regex("^Q[2-9A-HJ-NP-Z]{9}$")

        // Revoked token blacklist
        val REVOKED_TOKENS = setOf(
            "QREVOKED99",
            "QDISABLED1"
        )

        fun computeSha256(input: String): String {
            val normalized = input.trim().uppercase()
            val digest = MessageDigest.getInstance("SHA-256")
            val hashBytes = digest.digest(normalized.toByteArray(Charsets.UTF_8))
            return hashBytes.joinToString("") { "%02x".format(it) }
        }
    }

    suspend fun verifyToken(
        token: String,
        deviceId: String,
        authEndpoint: String = "",
        context: Context? = null
    ): CredentialValidationState = withContext(Dispatchers.IO) {
        val normalized = token.trim().uppercase()

        if (normalized.isEmpty()) {
            return@withContext CredentialValidationState.Invalid("Queen App Access Token is required.")
        }

        if (normalized.length != 10) {
            return@withContext CredentialValidationState.Invalid(
                "Invalid token length (${normalized.length}/10). Queen tokens must be exactly 10 characters."
            )
        }

        if (!normalized.startsWith("Q")) {
            return@withContext CredentialValidationState.Invalid(
                "Invalid token prefix. Queen tokens must begin with uppercase 'Q'."
            )
        }

        if (!QUEEN_TOKEN_REGEX.matches(normalized)) {
            return@withContext CredentialValidationState.Invalid(
                "Invalid token format. Must be 'Q' followed by 9 unambiguous characters (excluding 0, O, 1, I)."
            )
        }

        if (REVOKED_TOKENS.contains(normalized)) {
            return@withContext CredentialValidationState.Invalid(
                "This Queen App Access Token has been revoked or disabled by the administrator."
            )
        }

        val targetEndpoint = authEndpoint.trim()
        val hasHttpEndpoint = targetEndpoint.isNotBlank() &&
                !targetEndpoint.contains("example.com") &&
                !targetEndpoint.contains("your-firebase-project")

        // Option 1: Custom HTTP Endpoint if configured
        if (hasHttpEndpoint) {
            return@withContext verifyViaHttp(normalized, deviceId, targetEndpoint)
        }

        // Option 2: Direct Firebase Firestore with Anonymous Authentication
        val isFirebaseInitialized = try {
            if (context != null) {
                FirebaseApp.getApps(context).isNotEmpty()
            } else {
                FirebaseApp.getApps(android.app.Application()).isNotEmpty()
            }
        } catch (_: Exception) {
            false
        }

        if (isFirebaseInitialized) {
            return@withContext verifyViaFirestore(normalized, deviceId)
        }

        // Neither configured yet
        return@withContext CredentialValidationState.Invalid(
            "Firebase Token Verification endpoint is not configured. Please provide google-services.json (Project 'queen') or FIREBASE_AUTH_ENDPOINT."
        )
    }

    private suspend fun verifyViaFirestore(
        token: String,
        deviceId: String
    ): CredentialValidationState {
        val normalized = token.trim().uppercase()
        return try {
            // 1. Silent Firebase Anonymous Authentication (no login screen required)
            val auth = FirebaseAuth.getInstance()
            if (auth.currentUser == null) {
                auth.signInAnonymously().awaitTask()
            }
            val currentUid = auth.currentUser?.uid ?: ""

            // 2. Compute SHA-256 hash (never query or store plaintext token)
            val tokenHash = computeSha256(normalized)
            val db = FirebaseFirestore.getInstance()
            val docRef = db.collection(TOKENS_COLLECTION).document(tokenHash)

            val snapshot = docRef.get().awaitTask()
            if (!snapshot.exists()) {
                return CredentialValidationState.Invalid(
                    "Invalid or unrecognized Queen App Access Token."
                )
            }

            val status = snapshot.getString("status") ?: "ACTIVE"
            if (status == "REVOKED") {
                return CredentialValidationState.Invalid(
                    "This access token has been revoked by the administrator."
                )
            }

            if (status == "EXPIRED") {
                return CredentialValidationState.Invalid(
                    "This access token has expired."
                )
            }

            val expiresAt = snapshot.getTimestamp("expires_at")
            if (expiresAt != null && expiresAt.toDate().before(Date())) {
                return CredentialValidationState.Invalid(
                    "This access token has expired."
                )
            }

            // 3. Single-Device Binding Enforcement
            val boundDeviceId = snapshot.getString("bound_device_id")
            if (boundDeviceId.isNullOrBlank()) {
                // First-time activation: atomically bind to this device
                val updates = mapOf(
                    "bound_device_id" to deviceId,
                    "bound_uid" to currentUid,
                    "bound_at" to FieldValue.serverTimestamp(),
                    "last_used_at" to FieldValue.serverTimestamp(),
                    "usage_count" to FieldValue.increment(1)
                )
                docRef.update(updates).awaitTask()
                CredentialValidationState.Valid
            } else if (boundDeviceId == deviceId) {
                // Subsequent app launch on the same registered phone
                try {
                    docRef.update(
                        mapOf(
                            "last_used_at" to FieldValue.serverTimestamp(),
                            "usage_count" to FieldValue.increment(1)
                        )
                    ).awaitTask()
                } catch (_: Exception) {
                    // Updating last_used_at timestamp is non-critical if offline
                }
                CredentialValidationState.Valid
            } else {
                // Token already bound to a different device!
                CredentialValidationState.Invalid(
                    "This token is already activated on another device. Lifetime single-device policy enforced."
                )
            }
        } catch (e: Exception) {
            CredentialValidationState.Invalid(
                "Firebase Firestore error: ${e.localizedMessage ?: "Failed to verify token"}"
            )
        }
    }

    private fun verifyViaHttp(
        token: String,
        deviceId: String,
        endpoint: String
    ): CredentialValidationState {
        val normalized = token.trim().uppercase()
        return try {
            val payload = JSONObject().apply {
                put("token", normalized)
                put("deviceId", deviceId)
                put("tokenHash", computeSha256(normalized))
            }
            val requestBody = payload.toString()
                .toRequestBody("application/json; charset=utf-8".toMediaType())

            val request = Request.Builder()
                .url(endpoint)
                .addHeader("Authorization", "Bearer $normalized")
                .addHeader("X-Device-Id", deviceId)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string() ?: ""
                val json = try {
                    JSONObject(bodyStr)
                } catch (e: Exception) {
                    JSONObject()
                }

                when (response.code) {
                    200 -> {
                        val isValid = json.optBoolean("valid", false)
                        if (isValid) {
                            CredentialValidationState.Valid
                        } else {
                            val msg = json.optString("message", "Token rejected by authorization server.")
                            CredentialValidationState.Invalid(msg)
                        }
                    }
                    409 -> {
                        val msg = json.optString(
                            "message",
                            "This token is already bound to another registered device. Single-device license enforced."
                        )
                        CredentialValidationState.Invalid(msg)
                    }
                    403 -> {
                        val msg = json.optString(
                            "message",
                            "This access token has expired or been revoked by the administrator."
                        )
                        CredentialValidationState.Invalid(msg)
                    }
                    401, 404 -> {
                        val msg = json.optString(
                            "message",
                            "Token not found or unrecognized."
                        )
                        CredentialValidationState.Invalid(msg)
                    }
                    else -> {
                        val msg = json.optString(
                            "message",
                            "Server returned error HTTP ${response.code}"
                        )
                        CredentialValidationState.Invalid(msg)
                    }
                }
            }
        } catch (e: Exception) {
            CredentialValidationState.Invalid(
                "Cannot reach verification server: ${e.localizedMessage ?: "Network error"}"
            )
        }
    }
}

/**
 * Extension helper to await Google Play / Firebase Tasks in coroutines.
 */
private suspend fun <T> Task<T>.awaitTask(): T =
    suspendCancellableCoroutine { cont ->
        addOnSuccessListener { result -> cont.resume(result) }
        addOnFailureListener { exception -> cont.resumeWithException(exception) }
    }
