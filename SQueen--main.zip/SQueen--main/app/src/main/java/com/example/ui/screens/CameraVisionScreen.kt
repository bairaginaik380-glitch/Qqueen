package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraControl
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.data.model.AssistantState
import com.example.ui.theme.QueenBackground
import com.example.ui.theme.QueenBorder
import com.example.ui.theme.QueenBorderGold
import com.example.ui.theme.QueenError
import com.example.ui.theme.QueenGold
import com.example.ui.theme.QueenGoldBright
import com.example.ui.theme.QueenGoldSoft
import com.example.ui.theme.QueenSuccess
import com.example.ui.theme.QueenSurface
import com.example.ui.theme.QueenSurfaceVariant
import com.example.ui.theme.QueenTextMuted
import com.example.ui.theme.QueenTextPrimary
import com.example.ui.theme.QueenTextSecondary
import com.example.ui.viewmodel.AarohiViewModel
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

@Composable
fun CameraVisionScreen(
    viewModel: AarohiViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val assistantState by viewModel.assistantState.collectAsState()
    val isVisionTransmitting by viewModel.isVisionTransmitting.collectAsState()
    val lensFacing by viewModel.cameraLensFacing.collectAsState()

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val cam = results[Manifest.permission.CAMERA] == true
        hasCameraPermission = cam
        if (cam) {
            viewModel.setCameraVisionActive(true)
        }
    }

    // Zoom state
    var minZoom by remember { mutableFloatStateOf(1f) }
    var maxZoom by remember { mutableFloatStateOf(5f) }
    var currentZoom by remember { mutableFloatStateOf(1f) }
    var cameraControl by remember { mutableStateOf<CameraControl?>(null) }
    var cameraError by remember { mutableStateOf<String?>(null) }
    var previewViewRef by remember { mutableStateOf<PreviewView?>(null) }
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    // Start vision session on launch, stop when leaving
    LaunchedEffect(hasCameraPermission) {
        if (hasCameraPermission) {
            viewModel.setCameraVisionActive(true)
        } else {
            permissionLauncher.launch(
                arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            )
        }
    }

    DisposableEffect(lifecycleOwner) {
        onDispose {
            viewModel.setCameraVisionActive(false)
            try {
                ProcessCameraProvider.getInstance(context).get().unbindAll()
            } catch (_: Exception) {}
            cameraExecutor.shutdown()
        }
    }

    // Handle back navigation cleanly without terminating the voice session
    BackHandler {
        viewModel.setCameraVisionActive(false)
        onNavigateBack()
    }

    // Bind and rebind CameraX whenever permission, lensFacing, or preview surface changes
    LaunchedEffect(hasCameraPermission, lensFacing, previewViewRef) {
        val previewView = previewViewRef
        if (!hasCameraPermission || previewView == null) return@LaunchedEffect

        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            try {
                val cameraProvider = cameraProviderFuture.get()

                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

                var lastFrameTime = 0L
                val imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                    .also { analysis ->
                        analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                            try {
                                if (!viewModel.isCameraVisionActive.value || !viewModel.isLiveSessionReadyForVision()) {
                                    return@setAnalyzer
                                }
                                val now = System.currentTimeMillis()
                                if (now - lastFrameTime >= 1200L) {
                                    lastFrameTime = now
                                    val bitmap: Bitmap? = imageProxy.toBitmap()
                                    if (bitmap != null) {
                                        val maxDim = 640
                                        val scale = if (bitmap.width > maxDim || bitmap.height > maxDim) {
                                            maxDim.toFloat() / maxOf(bitmap.width, bitmap.height)
                                        } else {
                                            1.0f
                                        }
                                        val scaled = if (scale < 1.0f) {
                                            Bitmap.createScaledBitmap(
                                                bitmap,
                                                (bitmap.width * scale).toInt(),
                                                (bitmap.height * scale).toInt(),
                                                true
                                            )
                                        } else {
                                            bitmap
                                        }

                                        val stream = ByteArrayOutputStream()
                                        scaled.compress(Bitmap.CompressFormat.JPEG, 70, stream)
                                        val jpegBytes = stream.toByteArray()
                                        if (scaled != bitmap) {
                                            scaled.recycle()
                                        }
                                        bitmap.recycle()
                                        viewModel.sendCameraVisionFrame(jpegBytes)
                                    }
                                }
                            } catch (e: Exception) {
                                // Non-fatal frame processing exception
                            } finally {
                                imageProxy.close()
                            }
                        }
                    }

                val selector = CameraSelector.Builder()
                    .requireLensFacing(lensFacing)
                    .build()

                cameraProvider.unbindAll()
                val camera: Camera = cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    selector,
                    preview,
                    imageAnalysis
                )

                cameraControl = camera.cameraControl
                val cameraInfo: CameraInfo = camera.cameraInfo

                cameraInfo.zoomState.observe(lifecycleOwner) { state ->
                    if (state != null) {
                        minZoom = state.minZoomRatio
                        maxZoom = state.maxZoomRatio.coerceAtMost(10f)
                        currentZoom = state.zoomRatio
                    }
                }
                cameraError = null
            } catch (e: Exception) {
                cameraError = "Camera initialization failed: ${e.localizedMessage ?: "Unknown error"}"
            }
        }, ContextCompat.getMainExecutor(context))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(QueenBackground)
            // Swipe left-to-right to close Camera Vision and return home
            .pointerInput(Unit) {
                detectHorizontalDragGestures { _, dragAmount ->
                    if (dragAmount > 60f) {
                        viewModel.setCameraVisionActive(false)
                        onNavigateBack()
                    }
                }
            }
            .testTag("camera_vision_screen")
    ) {
        if (hasCameraPermission) {
            // Live Camera Preview using CameraX
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    // Pinch-to-zoom gesture
                    .pointerInput(minZoom, maxZoom) {
                        detectTransformGestures { _, _, zoomChange, _ ->
                            val newZoom = (currentZoom * zoomChange).coerceIn(minZoom, maxZoom)
                            currentZoom = newZoom
                            cameraControl?.setZoomRatio(newZoom)
                        }
                    }
            ) {
                AndroidView(
                    factory = { ctx ->
                        PreviewView(ctx).apply {
                            scaleType = PreviewView.ScaleType.FILL_CENTER
                            previewViewRef = this
                        }
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("camera_preview_view")
                )
            }
        } else {
            // Permission Denied / Request State
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Surface(
                    color = QueenSurfaceVariant,
                    shape = CircleShape,
                    border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorderGold),
                    modifier = Modifier.size(72.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.VideocamOff,
                            contentDescription = null,
                            tint = QueenGoldBright,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Camera Access Required",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = QueenTextPrimary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Queen AI needs camera permission so Rani can see your surroundings and answer questions about objects, text, and people in real time.",
                    fontSize = 14.sp,
                    color = QueenTextSecondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = { permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = QueenGoldSoft,
                        contentColor = QueenBackground
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("grant_camera_permission_button")
                ) {
                    Icon(imageVector = Icons.Default.Videocam, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Grant Camera Access", fontWeight = FontWeight.Bold)
                }
            }
        }

        // TOP BAR OVERLAY: Back/Close button, Status indicator, Camera switch
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Visible Back / Close control (Requirement 1 fallback)
            Surface(
                color = Color(0xBB141416),
                shape = CircleShape,
                border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorderGold),
                modifier = Modifier.size(44.dp)
            ) {
                IconButton(
                    onClick = {
                        viewModel.setCameraVisionActive(false)
                        onNavigateBack()
                    },
                    modifier = Modifier.testTag("camera_close_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Close Camera Vision",
                        tint = QueenTextPrimary
                    )
                }
            }

            // Live Vision Pill
            Surface(
                color = Color(0xDD0D0D0E),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isVisionTransmitting) QueenSuccess.copy(alpha = 0.8f) else QueenBorderGold
                ),
                modifier = Modifier.testTag("camera_vision_badge")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isVisionTransmitting) QueenSuccess else QueenGold)
                    )
                    Text(
                        text = if (isVisionTransmitting) "Rani Vision: Active" else "Camera Vision",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isVisionTransmitting) QueenSuccess else QueenGoldBright
                    )
                }
            }

            // Front / Back camera switch button
            Surface(
                color = Color(0xBB141416),
                shape = CircleShape,
                border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorderGold),
                modifier = Modifier.size(44.dp)
            ) {
                IconButton(
                    onClick = { viewModel.toggleCameraLens() },
                    modifier = Modifier.testTag("switch_camera_lens_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Cameraswitch,
                        contentDescription = "Switch Camera",
                        tint = QueenGoldBright
                    )
                }
            }
        }

        // BOTTOM CONTROLS OVERLAY: Zoom slider, Zoom badges, and Voice Assistant status
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Zoom Controls (Pinch-to-zoom is active + Slider for precision)
            if (hasCameraPermission && maxZoom > minZoom) {
                Surface(
                    color = Color(0xDD0D0D0E),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ZoomIn,
                                    contentDescription = null,
                                    tint = QueenGoldSoft,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Zoom: ${String.format("%.1f", currentZoom)}x",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = QueenGoldBright,
                                    modifier = Modifier.testTag("zoom_ratio_text")
                                )
                            }

                            // Quick preset zoom chips
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(1.0f, 2.0f, 5.0f).forEach { preset ->
                                    if (preset in minZoom..maxZoom) {
                                        Surface(
                                            color = if (kotlin.math.abs(currentZoom - preset) < 0.2f) QueenGoldSoft else Color(0x44FFFFFF),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.clip(RoundedCornerShape(6.dp))
                                        ) {
                                            Text(
                                                text = "${preset.toInt()}x",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (kotlin.math.abs(currentZoom - preset) < 0.2f) QueenBackground else QueenTextPrimary,
                                                modifier = Modifier
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                                    .pointerInput(Unit) {
                                                        currentZoom = preset
                                                        cameraControl?.setZoomRatio(preset)
                                                    }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Slider(
                            value = currentZoom,
                            onValueChange = { newZoom ->
                                currentZoom = newZoom
                                cameraControl?.setZoomRatio(newZoom)
                            },
                            valueRange = minZoom..maxZoom,
                            colors = SliderDefaults.colors(
                                thumbColor = QueenGoldBright,
                                activeTrackColor = QueenGold,
                                inactiveTrackColor = QueenSurfaceVariant
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(28.dp)
                                .testTag("camera_zoom_slider")
                        )
                    }
                }
            }
        }
    }
}
