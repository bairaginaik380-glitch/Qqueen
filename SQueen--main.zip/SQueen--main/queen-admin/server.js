/**
 * Queen AI - Token Verification Service
 * Developed for Shyam Kadam
 *
 * Runs an authenticated verification endpoint for Queen Android App clients.
 * Endpoints:
 *   GET /v1/token/verify
 *   Header: Authorization: Bearer <QueenAppAccessToken>
 */

const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 8080;

// Load hashed token registry
const registryPath = path.join(__dirname, 'tokens_registry.json');
let registry = { records: [] };
if (fs.existsSync(registryPath)) {
  registry = JSON.parse(fs.readFileSync(registryPath, 'utf8'));
}

// In-memory rate limiter per IP / token
const rateLimitMap = new Map();

app.use(express.json());

app.get('/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: Date.now() });
});

  const handleVerify = (req, res) => {
    let token = '';
    const authHeader = req.headers['authorization'];
    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.replace('Bearer ', '').trim().toUpperCase();
    } else if (req.body && req.body.token) {
      token = String(req.body.token).trim().toUpperCase();
    }

    const deviceId = req.headers['x-device-id'] || (req.body && req.body.deviceId) || '';

    if (!token) {
      return res.status(401).json({
        valid: false,
        message: 'Authorization missing. Provide: Bearer <token> or body token'
      });
    }

    // Validate format Q + 9 chars
    if (!/^Q[2-9A-HJ-NP-Z]{9}$/.test(token)) {
      return res.status(400).json({
        valid: false,
        message: 'Invalid Queen token format.'
      });
    }

    if (!deviceId) {
      return res.status(400).json({
        valid: false,
        message: 'Device identifier (X-Device-Id) is required for license validation.'
      });
    }

    // Rate limiting check
    const now = Date.now();
    const rateData = rateLimitMap.get(token) || { count: 0, resetAt: now + 60000 };
    if (now > rateData.resetAt) {
      rateData.count = 1;
      rateData.resetAt = now + 60000;
    } else {
      rateData.count++;
    }
    rateLimitMap.set(token, rateData);

    if (rateData.count > 60) {
      return res.status(429).json({
        valid: false,
        message: 'Rate limit exceeded. Please try again shortly.'
      });
    }

    // Hash token to compare against stored secure records
    const hash = crypto.createHash('sha256').update(token).digest('hex');
    const record = registry.records.find(r => r.sha256_hash === hash);

    if (!record) {
      return res.status(401).json({
        valid: false,
        message: 'Token not found or unrecognized.'
      });
    }

    if (record.status === 'REVOKED') {
      return res.status(403).json({
        valid: false,
        message: 'This access token has been revoked.'
      });
    }

    // Expiry check using server time
    const expField = record.expires_at || record.expiresAt;
    let isExpired = record.status === 'EXPIRED';
    if (expField) {
      let expiryMs = null;
      if (typeof expField === 'number') {
        expiryMs = expField < 100000000000 ? expField * 1000 : expField;
      } else if (typeof expField === 'string') {
        expiryMs = Date.parse(expField);
      }
      if (expiryMs && !isNaN(expiryMs) && now > expiryMs) {
        isExpired = true;
      }
    }

    if (isExpired) {
      return res.status(403).json({
        valid: false,
        message: 'This access token has expired.'
      });
    }

    // Enforce single registered device per token
    if (!record.bound_device_id) {
      record.bound_device_id = deviceId;
      record.bound_at = Math.floor(now / 1000);
      record.last_used_at = Math.floor(now / 1000);
      record.usage_count = (record.usage_count || 0) + 1;
      return res.json({
        valid: true,
        status: record.status,
        tokenId: record.id,
        message: 'Token registered to this device.'
      });
    }

    if (record.bound_device_id !== deviceId) {
      return res.status(409).json({
        valid: false,
        message: 'This token is already registered to another device. Single-device license enforced.'
      });
    }

    // Update metadata for already bound device
    record.last_used_at = Math.floor(now / 1000);
    record.usage_count = (record.usage_count || 0) + 1;

    return res.json({
      valid: true,
      status: record.status,
      tokenId: record.id,
      message: 'Token authorized for this device.'
    });
  };

  app.get('/v1/token/verify', handleVerify);
  app.post('/v1/token/verify', handleVerify);

app.listen(PORT, () => {
  console.log(`Queen Token Verification Server running on port ${PORT}`);
});
