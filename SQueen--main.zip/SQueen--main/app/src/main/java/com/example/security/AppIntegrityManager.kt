package com.example.security

import android.content.Context
import android.os.Build
import android.os.Debug
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket

/**
 * AppIntegrityManager
 *
 * Provides practical, defense-in-depth Android device integrity and tamper detection.
 *
 * IMPORTANT SECURITY NOTE:
 * Client-side tamper and integrity checks provide meaningful defense-in-depth and raise
 * the barrier for unauthorized instrumentation, but NO client-side check can claim that
 * tampering is mathematically impossible on a fully compromised or rooted device.
 */
object AppIntegrityManager {

    data class IntegrityStatus(
        val isTampered: Boolean,
        val title: String = "Security Integrity Warning",
        val reason: String = ""
    )

    private val KNOWN_SU_PATHS = arrayOf(
        "/system/bin/su",
        "/system/xbin/su",
        "/sbin/su",
        "/system/sd/xbin/su",
        "/system/bin/failsafe/su",
        "/data/local/xbin/su",
        "/data/local/bin/su",
        "/data/local/su",
        "/data/adb/magisk"
    )

    private val KNOWN_FRIDA_PATHS = arrayOf(
        "/data/local/tmp/frida-server",
        "/data/local/tmp/re.frida.server"
    )

    /**
     * Runs practical integrity checks.
     * Returns an [IntegrityStatus] indicating whether potential tampering or hooking was detected.
     */
    fun checkIntegrity(context: Context): IntegrityStatus {
        // 1. Check for active debugger connection
        if (Debug.isDebuggerConnected() || Debug.waitingForDebugger()) {
            return IntegrityStatus(
                isTampered = true,
                reason = "An active debugger is attached to the application. Protected Queen features are disabled."
            )
        }

        // 2. Check for Xposed framework reflection
        if (isXposedDetected()) {
            return IntegrityStatus(
                isTampered = true,
                reason = "Dynamic instrumentation hook (Xposed framework) detected in runtime memory."
            )
        }

        // 3. Check for Frida server file or default port
        if (isFridaDetected()) {
            return IntegrityStatus(
                isTampered = true,
                reason = "Dynamic reverse-engineering instrumentation (Frida) detected on device."
            )
        }

        // 4. Check for root binaries in standard filesystem paths
        if (isSuBinaryPresent()) {
            return IntegrityStatus(
                isTampered = true,
                reason = "Root superuser binary detected in system binaries path."
            )
        }

        return IntegrityStatus(isTampered = false)
    }

    private fun isSuBinaryPresent(): Boolean {
        for (path in KNOWN_SU_PATHS) {
            try {
                val file = File(path)
                if (file.exists()) {
                    return true
                }
            } catch (_: Exception) {
                // Ignore security exceptions on permission-restricted paths
            }
        }
        return false
    }

    private fun isFridaDetected(): Boolean {
        for (path in KNOWN_FRIDA_PATHS) {
            try {
                val file = File(path)
                if (file.exists()) {
                    return true
                }
            } catch (_: Exception) {
                // Ignore
            }
        }
        return false
    }

    private fun isXposedDetected(): Boolean {
        return try {
            Class.forName("de.robv.android.xposed.XposedBridge")
            true
        } catch (_: ClassNotFoundException) {
            false
        } catch (_: Throwable) {
            false
        }
    }
}
