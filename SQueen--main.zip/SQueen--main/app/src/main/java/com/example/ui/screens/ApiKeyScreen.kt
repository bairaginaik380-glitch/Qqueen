package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CredentialValidationState
import com.example.ui.theme.QueenBackground
import com.example.ui.theme.QueenBorder
import com.example.ui.theme.QueenBorderGold
import com.example.ui.theme.QueenError
import com.example.ui.theme.QueenGold
import com.example.ui.theme.QueenGoldBright
import com.example.ui.theme.QueenGoldSoft
import com.example.ui.theme.QueenSuccess
import com.example.ui.theme.QueenSurface
import com.example.ui.theme.QueenSurfaceVariant
import com.example.ui.theme.QueenTextMuted
import com.example.ui.theme.QueenTextPrimary
import com.example.ui.theme.QueenTextSecondary
import com.example.ui.viewmodel.AarohiViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiKeyScreen(
    viewModel: AarohiViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToLearnMore: () -> Unit
) {
    val geminiValidation by viewModel.geminiValidationState.collectAsState()
    val tokenValidation by viewModel.tokenValidationState.collectAsState()
    val savedGeminiMasked by viewModel.savedGeminiKeyMasked.collectAsState()
    val savedTokenMasked by viewModel.savedTokenMasked.collectAsState()
    val isSetupComplete by viewModel.isSetupComplete.collectAsState()

    val storedGeminiKey = remember { viewModel.getRawGeminiApiKey() }
    val storedToken = remember { viewModel.getRawAppAccessToken() }
    var geminiKeyInput by remember { mutableStateOf(storedGeminiKey) }
    var tokenInput by remember { mutableStateOf(storedToken) }

    var showGeminiKey by remember { mutableStateOf(false) }
    var showToken by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val scrollState = rememberScrollState()
    val context = LocalContext.current

    Scaffold(
        containerColor = QueenBackground,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "API & Key Setup",
                        fontWeight = FontWeight.Bold,
                        color = QueenTextPrimary,
                        fontSize = 20.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("api_key_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = QueenTextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = QueenBackground
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Overall Status Banner
            Surface(
                color = if (isSetupComplete) QueenSuccess.copy(alpha = 0.12f) else QueenSurface,
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isSetupComplete) QueenSuccess.copy(alpha = 0.4f) else QueenBorderGold
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = if (isSetupComplete) Icons.Default.CheckCircle else Icons.Default.Security,
                        contentDescription = null,
                        tint = if (isSetupComplete) QueenSuccess else QueenGold,
                        modifier = Modifier.size(26.dp)
                    )
                    Column {
                        Text(
                            text = if (isSetupComplete) "Authorization Verified" else "Setup Authorization Gate",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = QueenTextPrimary
                        )
                        Text(
                            text = if (isSetupComplete)
                                "Credentials passed verification. You can tap Start on Home to begin your voice session."
                            else if (AarohiViewModel.isTemporaryTestingAccessActive())
                                "Gemini API Key is required to start voice sessions."
                            else
                                "Both Gemini API Key and Queen App Access Token are required to start voice sessions.",
                            fontSize = 12.sp,
                            color = QueenTextSecondary,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            // ========================================================
            // PROMINENT CARD 1: GEMINI API SETUP (YouTube Link)
            // ========================================================
            Surface(
                color = QueenSurface,
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorderGold),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayCircle,
                            contentDescription = "YouTube",
                            tint = Color(0xFFFF0000), // YouTube red
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "Gemini API Setup",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = QueenTextPrimary
                        )
                    }

                    Text(
                        text = "Learn how to create your Gemini API Key.",
                        fontSize = 13.sp,
                        color = QueenTextSecondary
                    )

                    Text(
                        text = "Opens developer channel: youtube.com/@ksdgrind",
                        fontSize = 11.sp,
                        color = QueenTextMuted
                    )

                    OutlinedButton(
                        onClick = {
                            openUrl(context, "https://youtube.com/@ksdgrind?si=509A3GDA-tS14BvS")
                        },
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, QueenGoldSoft),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("watch_setup_tutorial_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                            contentDescription = null,
                            tint = QueenGoldBright,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                        Text(
                            text = "Watch Setup Tutorial",
                            color = QueenGoldBright,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // ========================================================
            // PROMINENT CARD 2: CONTACT DEVELOPER (WhatsApp Link)
            // ========================================================
            Surface(
                color = QueenSurface,
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorderGold),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "WhatsApp",
                            tint = Color(0xFF25D366), // WhatsApp green
                            modifier = Modifier.size(22.dp)
                        )
                        Text(
                            text = "Contact Developer",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = QueenTextPrimary
                        )
                    }

                    Text(
                        text = "Get help with Queen App Access.",
                        fontSize = 13.sp,
                        color = QueenTextSecondary
                    )

                    Text(
                        text = "Developer Shyam Kadam (+91 9404471855)",
                        fontSize = 11.sp,
                        color = QueenTextMuted
                    )

                    OutlinedButton(
                        onClick = {
                            openUrl(context, "https://wa.me/919404471855")
                        },
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF25D366)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("contact_on_whatsapp_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                            contentDescription = null,
                            tint = Color(0xFF25D366),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                        Text(
                            text = "Contact on WhatsApp",
                            color = Color(0xFF25D366),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // ========================================================
            // CREDENTIAL INPUT A: GEMINI API KEY
            // ========================================================
            Surface(
                color = QueenSurface,
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            tint = QueenGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "A. Google AI Studio Gemini API Key",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = QueenTextPrimary
                        )
                    }

                    Text(
                        text = "Connects directly to the 'gemini-3.1-flash-live-preview' voice engine. Stored securely in Android KeyStore.",
                        fontSize = 12.sp,
                        color = QueenTextMuted
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Saved: $savedGeminiMasked",
                            fontSize = 13.sp,
                            color = QueenTextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                        ValidationStatusBadge(geminiValidation)
                    }

                    OutlinedTextField(
                        value = geminiKeyInput,
                        onValueChange = { geminiKeyInput = it },
                        label = { Text("Enter / Update Gemini API Key") },
                        placeholder = { Text("AIzaSy...") },
                        singleLine = true,
                        visualTransformation = if (showGeminiKey) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            IconButton(onClick = { showGeminiKey = !showGeminiKey }) {
                                Icon(
                                    imageVector = if (showGeminiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null,
                                    tint = QueenTextMuted
                                )
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = QueenSurfaceVariant,
                            unfocusedContainerColor = QueenSurfaceVariant,
                            focusedBorderColor = QueenGold,
                            unfocusedBorderColor = QueenBorder,
                            focusedTextColor = QueenTextPrimary,
                            unfocusedTextColor = QueenTextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("gemini_key_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.saveAndValidateGeminiKey(geminiKeyInput)
                                scope.launch {
                                    snackbarHostState.showSnackbar("Validating Gemini API Key...")
                                }
                            },
                            enabled = geminiKeyInput.isNotBlank() && geminiValidation !is CredentialValidationState.Validating,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = QueenGold,
                                contentColor = Color.Black
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("save_gemini_key_button")
                        ) {
                            if (geminiValidation is CredentialValidationState.Validating) {
                                CircularProgressIndicator(
                                    color = Color.Black,
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.size(8.dp))
                                Text("Validating...")
                            } else {
                                Text(
                                    if (geminiValidation is CredentialValidationState.Valid) "Update Key" else "Save & Validate Key",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        if (geminiKeyInput.isNotBlank() || geminiValidation is CredentialValidationState.Valid) {
                            OutlinedButton(
                                onClick = {
                                    viewModel.deleteGeminiKey()
                                    geminiKeyInput = ""
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Gemini API Key deleted.")
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, QueenError),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = QueenError),
                                modifier = Modifier.testTag("delete_gemini_key_button")
                            ) {
                                Text("Delete")
                            }
                        }
                    }

                    if (geminiValidation is CredentialValidationState.Invalid) {
                        Text(
                            text = (geminiValidation as CredentialValidationState.Invalid).message,
                            color = QueenError,
                            fontSize = 12.sp,
                            modifier = Modifier.testTag("gemini_error_message")
                        )
                    }
                }
            }

            // ========================================================
            // CREDENTIAL INPUT B: QUEEN APP ACCESS TOKEN (Hidden during temporary testing)
            // ========================================================
            if (!AarohiViewModel.isTemporaryTestingAccessActive()) {
                Surface(
                    color = QueenSurface,
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = QueenGoldSoft,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "B. Queen App Access Token",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = QueenTextPrimary
                        )
                    }

                    Text(
                        text = "10-character token issued by owner (e.g. Q7M4K9P2R6). Verifies authorization rights.",
                        fontSize = 12.sp,
                        color = QueenTextMuted
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Saved: $savedTokenMasked",
                            fontSize = 13.sp,
                            color = QueenTextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                        ValidationStatusBadge(tokenValidation)
                    }

                    OutlinedTextField(
                        value = tokenInput,
                        onValueChange = { tokenInput = it.uppercase() },
                        label = { Text("Enter Queen Access Token") },
                        placeholder = { Text("Q...") },
                        singleLine = true,
                        visualTransformation = if (showToken) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            IconButton(onClick = { showToken = !showToken }) {
                                Icon(
                                    imageVector = if (showToken) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null,
                                    tint = QueenTextMuted
                                )
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = QueenSurfaceVariant,
                            unfocusedContainerColor = QueenSurfaceVariant,
                            focusedBorderColor = QueenGoldSoft,
                            unfocusedBorderColor = QueenBorder,
                            focusedTextColor = QueenTextPrimary,
                            unfocusedTextColor = QueenTextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("app_token_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.saveAndValidateToken(tokenInput.trim().uppercase())
                                scope.launch {
                                    snackbarHostState.showSnackbar("Verifying Queen Access Token...")
                                }
                            },
                            enabled = tokenInput.isNotBlank() && tokenValidation !is CredentialValidationState.Validating,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = QueenGoldSoft,
                                contentColor = Color.Black
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("save_token_button")
                        ) {
                            if (tokenValidation is CredentialValidationState.Validating) {
                                CircularProgressIndicator(
                                    color = Color.Black,
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.size(8.dp))
                                Text("Verifying...")
                            } else {
                                Text(
                                    if (tokenValidation is CredentialValidationState.Valid) "Update Token" else "Save & Verify Token",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        if (tokenInput.isNotBlank() || tokenValidation is CredentialValidationState.Valid) {
                            OutlinedButton(
                                onClick = {
                                    viewModel.deleteToken()
                                    tokenInput = ""
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Queen Access Token deleted.")
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, QueenError),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = QueenError),
                                modifier = Modifier.testTag("delete_token_button")
                            ) {
                                Text("Delete")
                            }
                        }
                    }

                    if (tokenValidation is CredentialValidationState.Invalid) {
                        Text(
                            text = (tokenValidation as CredentialValidationState.Invalid).message,
                            color = QueenError,
                            fontSize = 12.sp,
                            modifier = Modifier.testTag("token_error_message")
                        )
                    }

                    OutlinedButton(
                        onClick = onNavigateToLearnMore,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorderGold),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("learn_more_token_policy_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = QueenGoldSoft,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                        Text(
                            text = "Learn More (License & Device Policy)",
                            color = QueenGoldSoft,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

private fun openUrl(context: Context, url: String) {
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Could not open link: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun ValidationStatusBadge(state: CredentialValidationState) {
    val (label, color) = when (state) {
        is CredentialValidationState.Valid -> "Verified" to QueenSuccess
        is CredentialValidationState.Validating -> "Verifying..." to QueenGold
        is CredentialValidationState.Invalid -> "Missing/Invalid" to QueenError
        is CredentialValidationState.Unchecked -> "Unchecked" to QueenTextMuted
    }

    Surface(
        color = color.copy(alpha = 0.15f),
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f))
    ) {
        Text(
            text = label,
            color = color,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}
