package com.example.data.storage

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.example.BuildConfig
import com.example.data.model.VoiceOption
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class CredentialStorage(context: Context) {

    val appContext: Context = context.applicationContext
    private val prefs: SharedPreferences =
        appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    init {
        ensureKeyStoreKey()
    }

    private fun ensureKeyStoreKey() {
        try {
            val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER)
            keyStore.load(null)
            if (!keyStore.containsAlias(KEY_ALIAS)) {
                val keyGenerator = KeyGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_AES,
                    KEYSTORE_PROVIDER
                )
                val spec = KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
                keyGenerator.init(spec)
                keyGenerator.generateKey()
            }
        } catch (e: Exception) {
            // Android KeyStore initialized or fallback
        }
    }

    private fun getSecretKey(): SecretKey? {
        return try {
            val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER)
            keyStore.load(null)
            keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        } catch (e: Exception) {
            null
        }
    }

    private fun encrypt(plainText: String): String {
        if (plainText.isEmpty()) return ""
        val secretKey = getSecretKey() ?: return Base64.encodeToString(
            plainText.toByteArray(StandardCharsets.UTF_8),
            Base64.NO_WRAP
        )
        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey)
            val iv = cipher.iv
            val encryptedBytes = cipher.doFinal(plainText.toByteArray(StandardCharsets.UTF_8))
            val combined = ByteArray(iv.size + encryptedBytes.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(encryptedBytes, 0, combined, iv.size, encryptedBytes.size)
            Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (e: Exception) {
            Base64.encodeToString(plainText.toByteArray(StandardCharsets.UTF_8), Base64.NO_WRAP)
        }
    }

    private fun decrypt(cipherTextBase64: String): String {
        if (cipherTextBase64.isEmpty()) return ""
        return try {
            val combined = Base64.decode(cipherTextBase64, Base64.NO_WRAP)
            val secretKey = getSecretKey()
            if (secretKey != null && combined.size > GCM_IV_LENGTH) {
                val iv = ByteArray(GCM_IV_LENGTH)
                val encryptedBytes = ByteArray(combined.size - GCM_IV_LENGTH)
                System.arraycopy(combined, 0, iv, 0, GCM_IV_LENGTH)
                System.arraycopy(combined, GCM_IV_LENGTH, encryptedBytes, 0, encryptedBytes.size)
                val cipher = Cipher.getInstance(TRANSFORMATION)
                val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
                cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)
                String(cipher.doFinal(encryptedBytes), StandardCharsets.UTF_8)
            } else {
                String(combined, StandardCharsets.UTF_8)
            }
        } catch (e: Exception) {
            // In case of fallback or direct decode
            try {
                String(Base64.decode(cipherTextBase64, Base64.NO_WRAP), StandardCharsets.UTF_8)
            } catch (ex: Exception) {
                ""
            }
        }
    }

    // --- Gemini API Key ---
    fun saveGeminiApiKey(key: String) {
        val encrypted = encrypt(key.trim())
        prefs.edit()
            .putString(KEY_GEMINI_API_KEY, encrypted)
            .putBoolean(KEY_GEMINI_EXPLICITLY_DELETED, false)
            .apply()
    }

    fun getGeminiApiKey(): String {
        if (prefs.getBoolean(KEY_GEMINI_EXPLICITLY_DELETED, false)) {
            return ""
        }
        val storedEncrypted = prefs.getString(KEY_GEMINI_API_KEY, null)
        if (!storedEncrypted.isNullOrEmpty()) {
            val decrypted = decrypt(storedEncrypted)
            if (decrypted.isNotBlank()) return decrypted
        }
        // Fallback to BuildConfig if provided via Secrets panel and not placeholder
        val buildKey = BuildConfig.GEMINI_API_KEY
        if (buildKey.isNotBlank() && !buildKey.contains("MY_GEMINI_API_KEY") && !buildKey.contains("your_gemini_api_key")) {
            return buildKey
        }
        return ""
    }

    fun deleteGeminiApiKey() {
        prefs.edit()
            .remove(KEY_GEMINI_API_KEY)
            .putBoolean(KEY_GEMINI_EXPLICITLY_DELETED, true)
            .apply()
    }

    fun hasGeminiApiKey(): Boolean = getGeminiApiKey().isNotBlank()

    // --- App Access Token ---
    fun saveAppAccessToken(token: String) {
        val normalized = token.trim().uppercase()
        val encrypted = encrypt(normalized)
        prefs.edit().putString(KEY_APP_ACCESS_TOKEN, encrypted).apply()
    }

    fun getAppAccessToken(): String {
        val storedEncrypted = prefs.getString(KEY_APP_ACCESS_TOKEN, null)
        if (!storedEncrypted.isNullOrEmpty()) {
            val decrypted = decrypt(storedEncrypted)
            if (decrypted.isNotBlank()) return decrypted.trim().uppercase()
        }
        return ""
    }

    fun deleteAppAccessToken() {
        prefs.edit().remove(KEY_APP_ACCESS_TOKEN).apply()
    }

    fun hasAppAccessToken(): Boolean = getAppAccessToken().isNotBlank()

    // --- Device ID for Single-Device License Binding ---
    fun getOrCreateDeviceId(): String {
        val existing = prefs.getString(KEY_DEVICE_ID, null)
        if (!existing.isNullOrBlank()) return existing

        val androidId = try {
            android.provider.Settings.Secure.getString(
                appContext.contentResolver,
                android.provider.Settings.Secure.ANDROID_ID
            ) ?: ""
        } catch (e: Exception) {
            ""
        }
        val generated = if (androidId.isNotBlank() && androidId != "9774d56d682e549c") {
            "queen_dev_" + androidId.take(16)
        } else {
            "queen_dev_" + java.util.UUID.randomUUID().toString().replace("-", "").take(16)
        }
        prefs.edit().putString(KEY_DEVICE_ID, generated).apply()
        return generated
    }

    // --- Firebase Auth Endpoint ---
    fun getFirebaseAuthEndpoint(): String {
        val stored = prefs.getString(KEY_FIREBASE_AUTH_ENDPOINT, null)
        if (!stored.isNullOrBlank()) return stored
        return try {
            val field = BuildConfig::class.java.getField("FIREBASE_AUTH_ENDPOINT")
            val url = field.get(null) as? String ?: ""
            if (url.isNotBlank() && !url.contains("your-firebase-project")) url else ""
        } catch (e: Exception) {
            ""
        }
    }

    fun saveFirebaseAuthEndpoint(endpoint: String) {
        prefs.edit().putString(KEY_FIREBASE_AUTH_ENDPOINT, endpoint.trim()).apply()
    }

    // --- User Name ---
    fun saveUserName(name: String) {
        prefs.edit().putString(KEY_USER_NAME, name.trim()).apply()
    }

    fun getUserName(): String {
        return prefs.getString(KEY_USER_NAME, "") ?: ""
    }

    // --- Voice Selection ---
    fun saveVoice(voiceId: String) {
        val trimmed = voiceId.trim()
        if (trimmed.isNotEmpty()) {
            prefs.edit().putString(KEY_SELECTED_VOICE, trimmed).commit()
        }
    }

    fun getVoice(): String {
        val saved = prefs.getString(KEY_SELECTED_VOICE, VoiceOption.DEFAULT.id)
        return if (!saved.isNullOrBlank()) saved.trim() else VoiceOption.DEFAULT.id
    }

    /**
     * Checks if the 2-hour temporary testing window is active for DEBUG builds.
     * Starts the 2-hour countdown on the first activation of the testing window.
     * Always returns false for RELEASE builds to enforce server-verified access tokens.
     */
    fun isTemporaryTestingAccessActive(): Boolean {
        if (!BuildConfig.DEBUG) return false
        val now = System.currentTimeMillis()
        var startTime = prefs.getLong(KEY_TESTING_WINDOW_START_TIME, 0L)
        if (startTime <= 0L) {
            startTime = now
            prefs.edit().putLong(KEY_TESTING_WINDOW_START_TIME, startTime).apply()
        }
        val elapsed = now - startTime
        return elapsed in 0 until TESTING_WINDOW_DURATION_MS
    }

    // --- Masking Helpers ---
    companion object {
        private const val PREFS_NAME = "aarohi_secure_vault"
        private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
        private const val KEY_ALIAS = "AarohiMasterKeyAlias"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_IV_LENGTH = 12
        private const val GCM_TAG_LENGTH = 128

        private const val KEY_GEMINI_API_KEY = "encrypted_gemini_api_key"
        private const val KEY_GEMINI_EXPLICITLY_DELETED = "gemini_key_explicitly_deleted"
        private const val KEY_APP_ACCESS_TOKEN = "encrypted_app_access_token"
        private const val KEY_DEVICE_ID = "pref_device_id"
        private const val KEY_FIREBASE_AUTH_ENDPOINT = "pref_firebase_auth_endpoint"
        private const val KEY_USER_NAME = "pref_user_name"
        private const val KEY_SELECTED_VOICE = "pref_selected_voice"
        private const val KEY_TESTING_WINDOW_START_TIME = "debug_testing_window_start_time"

        const val TESTING_WINDOW_DURATION_MS = 2 * 60 * 60 * 1000L // 2 hours

        fun maskSecret(secret: String): String {
            if (secret.isBlank()) return "Not Configured"
            if (secret.length <= 8) return "••••••••"
            val start = secret.take(4)
            val end = secret.takeLast(4)
            return "$start••••••••$end"
        }
    }
}
