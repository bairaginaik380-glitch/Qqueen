package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Pure Black Premium Luxury Theme for Queen
val QueenBackground = Color(0xFF000000)
val QueenSurface = Color(0xFF0B0B0C)
val QueenSurfaceVariant = Color(0xFF141416)
val QueenSurfaceElevated = Color(0xFF1C1C1F)

val QueenGold = Color(0xFFD4AF37)
val QueenGoldBright = Color(0xFFF3D079)
val QueenGoldSoft = Color(0xFFC5A059)
val QueenGoldContainer = Color(0xFF2E2410)
val QueenOnGoldContainer = Color(0xFFFDE68A)

val QueenTextPrimary = Color(0xFFF9F9F8)
val QueenTextSecondary = Color(0xFFBFBDB6)
val QueenTextMuted = Color(0xFF787774)

val QueenBorder = Color(0xFF26262A)
val QueenBorderGold = Color(0xFF4A3B1B)

val QueenSuccess = Color(0xFF34D399)
val QueenError = Color(0xFFF87171)
val QueenGoldGlow = Color(0x66D4AF37)
