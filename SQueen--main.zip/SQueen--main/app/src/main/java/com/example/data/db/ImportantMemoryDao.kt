package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.ImportantMemoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ImportantMemoryDao {

    @Query("SELECT * FROM important_memories ORDER BY timestamp DESC")
    fun getAllMemories(): Flow<List<ImportantMemoryEntity>>

    @Query("SELECT * FROM important_memories ORDER BY timestamp DESC")
    suspend fun getAllMemoriesList(): List<ImportantMemoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: ImportantMemoryEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(memories: List<ImportantMemoryEntity>)

    @Query("DELETE FROM important_memories WHERE id = :id")
    suspend fun deleteById(id: Long): Int

    @Query("DELETE FROM important_memories")
    suspend fun clearAll(): Int

    @Query("SELECT COUNT(*) FROM important_memories")
    suspend fun getCount(): Int
}
