package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Represents an important long-term memory (fact, task, plan) saved by Queen/Rani
 * when the user explicitly asks to remember something.
 *
 * Kept strictly separate from regular conversation history so clearing history
 * does not erase important memories.
 */
@Entity(
    tableName = "important_memories",
    indices = [Index(value = ["content"], unique = true)]
)
data class ImportantMemoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val category: String = "FACT", // "FACT", "TASK", "PLAN", "GENERAL"
    val content: String
)
