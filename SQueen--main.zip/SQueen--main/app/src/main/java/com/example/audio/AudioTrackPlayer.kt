package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class AudioTrackPlayer(
    private val sampleRate: Int = 24000,
    private val context: Context? = null,
    private val onPlaybackStateChanged: (Boolean) -> Unit = {}
) {
    private var audioTrack: AudioTrack? = null
    private val audioQueue = Channel<ByteArray>(Channel.UNLIMITED)
    private var playbackJob: Job? = null
    private var idleJob: Job? = null
    private var sessionScope: CoroutineScope? = null
    private val bufferSize: Int
    @Volatile
    private var isPlayingState = false
    @Volatile
    private var totalFramesWritten = 0L
    @Volatile
    private var isTurnCompletedByServer = false

    init {
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        bufferSize = if (minBuf > 0) maxOf(minBuf * 4, 8192) else 8192
    }

    fun start(scope: CoroutineScope) {
        if (playbackJob != null) return
        sessionScope = scope

        // Ensure stream music is audible and not muted to 0
        val audioManager = context?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (audioManager != null) {
            try {
                val currentVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                if (currentVol == 0 && maxVol > 0) {
                    val target = maxOf(1, (maxVol * 0.70f).toInt())
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
                }
            } catch (_: Exception) {}
        }

        try {
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()

            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()

            var track: AudioTrack? = null
            try {
                track = AudioTrack.Builder()
                    .setAudioAttributes(attributes)
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(bufferSize)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            } catch (_: Exception) {
                track = null
            }

            if (track == null || track.state != AudioTrack.STATE_INITIALIZED) {
                track?.release()
                @Suppress("DEPRECATION")
                track = AudioTrack(
                    AudioManager.STREAM_MUSIC,
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize,
                    AudioTrack.MODE_STREAM
                )
            }

            if (track.state != AudioTrack.STATE_INITIALIZED) {
                track.release()
                audioTrack = null
                return
            }

            audioTrack = track
            try {
                track.setVolume(1.0f)
                track.play()
            } catch (_: Exception) {}
        } catch (e: Exception) {
            audioTrack?.release()
            audioTrack = null
            return
        }

        playbackJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                try {
                    val chunk = audioQueue.receive()
                    if (chunk.isNotEmpty()) {
                        val track = audioTrack
                        if (track != null && track.state == AudioTrack.STATE_INITIALIZED) {
                            if (track.playState != AudioTrack.PLAYSTATE_PLAYING) {
                                try { track.play() } catch (_: Exception) {}
                            }
                            if (!isPlayingState) {
                                isPlayingState = true
                                onPlaybackStateChanged(true)
                            }
                            var offset = 0
                            while (offset < chunk.size && isActive) {
                                val written = track.write(chunk, offset, chunk.size - offset, AudioTrack.WRITE_BLOCKING)
                                if (written > 0) {
                                    offset += written
                                    totalFramesWritten += written / 2
                                } else {
                                    break
                                }
                            }
                            scheduleIdleCheck(scope)
                        }
                    }
                } catch (e: Exception) {
                    if (isActive) {
                        delay(20)
                    }
                }
            }
        }
    }

    fun notifyTurnComplete() {
        isTurnCompletedByServer = true
        sessionScope?.let { scheduleIdleCheck(it) }
    }

    private fun scheduleIdleCheck(scope: CoroutineScope) {
        idleJob?.cancel()
        idleJob = scope.launch(Dispatchers.IO) {
            while (isActive && isPlayingState) {
                if (audioQueue.isEmpty) {
                    val track = audioTrack
                    val head = try {
                        (track?.playbackHeadPosition?.toLong() ?: 0L) and 0xFFFFFFFFL
                    } catch (_: Exception) { 0L }

                    val remainingFrames = maxOf(0L, totalFramesWritten - head)
                    val remainingMs = (remainingFrames * 1000L) / sampleRate

                    if (isTurnCompletedByServer) {
                        if (remainingMs > 0) {
                            delay(remainingMs + 60L)
                        } else {
                            delay(60L)
                        }
                        if (audioQueue.isEmpty && isPlayingState) {
                            isPlayingState = false
                            isTurnCompletedByServer = false
                            onPlaybackStateChanged(false)
                            break
                        }
                    } else {
                        val waitMs = maxOf(remainingMs + 300L, 1200L)
                        delay(waitMs)
                        if (audioQueue.isEmpty && isPlayingState) {
                            isPlayingState = false
                            onPlaybackStateChanged(false)
                            break
                        }
                    }
                } else {
                    delay(50)
                }
            }
        }
    }

    fun enqueueAudio(pcmData: ByteArray) {
        if (pcmData.isNotEmpty()) {
            isTurnCompletedByServer = false
            idleJob?.cancel()
            audioQueue.trySend(pcmData)
        }
    }

    fun interruptAndFlush() {
        idleJob?.cancel()
        idleJob = null
        isTurnCompletedByServer = false
        while (!audioQueue.isEmpty) {
            audioQueue.tryReceive()
        }
        val track = audioTrack
        try {
            if (track != null && track.state == AudioTrack.STATE_INITIALIZED) {
                track.pause()
                track.flush()
                track.play()
                val head = (track.playbackHeadPosition.toLong() and 0xFFFFFFFFL)
                totalFramesWritten = head
            } else {
                totalFramesWritten = 0L
            }
        } catch (_: Exception) {
            totalFramesWritten = 0L
        }
        if (isPlayingState) {
            isPlayingState = false
            onPlaybackStateChanged(false)
        }
    }

    fun stop() {
        idleJob?.cancel()
        idleJob = null
        isTurnCompletedByServer = false
        playbackJob?.cancel()
        playbackJob = null
        while (!audioQueue.isEmpty) {
            audioQueue.tryReceive()
        }
        try {
            audioTrack?.apply {
                if (state == AudioTrack.STATE_INITIALIZED) {
                    try { pause() } catch (_: Exception) {}
                    try { flush() } catch (_: Exception) {}
                    try { stop() } catch (_: Exception) {}
                }
                release()
            }
        } catch (_: Exception) {} finally {
            audioTrack = null
            totalFramesWritten = 0L
            if (isPlayingState) {
                isPlayingState = false
                onPlaybackStateChanged(false)
            }
        }
    }
}
