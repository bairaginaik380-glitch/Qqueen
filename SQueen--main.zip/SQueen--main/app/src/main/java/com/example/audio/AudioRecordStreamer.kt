package com.example.audio

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sqrt

class AudioRecordStreamer(
    private val context: Context? = null,
    private val sampleRate: Int = 16000,
    private val onAudioChunk: (ByteArray) -> Unit,
    private val onAmplitudeChanged: (Float) -> Unit = {},
    private val onVoiceActivity: (isSpeech: Boolean, amp: Float) -> Unit = { _, _ -> },
    private val onError: (String) -> Unit = {}
) {
    private var audioRecord: AudioRecord? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var automaticGainControl: AutomaticGainControl? = null
    private var recordingJob: Job? = null
    private val bufferSize: Int
    var isSimulatedInput: Boolean = false
        private set

    init {
        val minBuf = try {
            AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
        } catch (_: Throwable) {
            -1
        }
        bufferSize = if (minBuf > 0) maxOf(minBuf * 2, 4096) else 4096
    }

    @SuppressLint("MissingPermission")
    fun start(scope: CoroutineScope) {
        if (recordingJob != null) return

        val hasMicPermission = context == null || ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        var record: AudioRecord? = null

        if (hasMicPermission) {
            val sources = listOf(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                MediaRecorder.AudioSource.MIC,
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                MediaRecorder.AudioSource.DEFAULT
            )

            for (source in sources) {
                try {
                    val candidate = AudioRecord(
                        source,
                        sampleRate,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        bufferSize
                    )
                    if (candidate.state == AudioRecord.STATE_INITIALIZED) {
                        record = candidate
                        break
                    } else {
                        candidate.release()
                    }
                } catch (_: Throwable) {
                    // Try next candidate
                }
            }
        }

        // If hardware mic initialization failed (e.g. In virtualized cloud emulator with status -1)
        // or permission is not granted, gracefully fallback to simulated silence audio stream
        // so the Gemini Live WebSocket session remains healthy and responsive.
        if (record == null || record.state != AudioRecord.STATE_INITIALIZED) {
            try { record?.release() } catch (_: Throwable) {}
            audioRecord = null
            startSimulatedStream(scope)
            return
        }

        try {
            val sessionId = record.audioSessionId
            if (sessionId != 0) {
                if (AcousticEchoCanceler.isAvailable()) {
                    try {
                        echoCanceler = AcousticEchoCanceler.create(sessionId)?.apply {
                            enabled = true
                        }
                    } catch (_: Throwable) {}
                }
                if (NoiseSuppressor.isAvailable()) {
                    try {
                        noiseSuppressor = NoiseSuppressor.create(sessionId)?.apply {
                            enabled = true
                        }
                    } catch (_: Throwable) {}
                }
                if (AutomaticGainControl.isAvailable()) {
                    try {
                        automaticGainControl = AutomaticGainControl.create(sessionId)?.apply {
                            enabled = true
                        }
                    } catch (_: Throwable) {}
                }
            }

            audioRecord = record
            record.startRecording()

            if (record.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                record.release()
                audioRecord = null
                startSimulatedStream(scope)
                return
            }
        } catch (_: Throwable) {
            try { record.release() } catch (_: Throwable) {}
            audioRecord = null
            startSimulatedStream(scope)
            return
        }


        recordingJob = scope.launch(Dispatchers.IO) {
            val buffer = ByteArray(bufferSize)
            var prevSample = 0
            while (isActive && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                try {
                    val readBytes = audioRecord?.read(buffer, 0, buffer.size) ?: -1
                    if (readBytes > 0) {
                        val chunk = buffer.copyOf(readBytes)

                        // 1. Raw RMS amplitude & zero-crossing rate
                        var sum = 0.0
                        var speechBandSum = 0.0
                        var zeroCrossings = 0
                        val shortCount = readBytes / 2
                        var lastVal = prevSample

                        for (i in 0 until shortCount) {
                            val sample = ((chunk[i * 2 + 1].toInt() shl 8) or (chunk[i * 2].toInt() and 0xFF)).toShort().toInt()
                            sum += sample * sample

                            // Pre-emphasis / speech formant filter y[n] = x[n] - 0.95*x[n-1]
                            // Attenuates sub-200Hz vehicle rumbles and low mechanical hums
                            val filtered = sample - (0.95 * lastVal)
                            speechBandSum += filtered * filtered

                            // Zero crossing count
                            if ((sample >= 0 && lastVal < 0) || (sample < 0 && lastVal >= 0)) {
                                zeroCrossings++
                            }
                            lastVal = sample
                        }
                        if (shortCount > 0) {
                            prevSample = lastVal
                        }

                        val rms = if (shortCount > 0) sqrt(sum / shortCount) else 0.0
                        val normalized = (rms / 32768.0).toFloat().coerceIn(0f, 1f)

                        val speechRms = if (shortCount > 0) sqrt(speechBandSum / shortCount) else 0.0
                        val speechBandNormalized = (speechRms / 32768.0).toFloat().coerceIn(0f, 1f)

                        val zcr = if (shortCount > 0) zeroCrossings.toFloat() / shortCount else 0f
                        val speechEnergyRatio = if (sum > 100.0) (speechBandSum / (sum + 1e-6)).toFloat() else 0f

                        // Speech Activity Decision:
                        // - Sufficient energy (normalized >= 0.12f)
                        // - High energy in human speech frequencies (speechBandNormalized >= 0.06f)
                        // - Zero-crossing rate within human vocalization spectrum (0.035 to 0.38)
                        // - Low-frequency vehicle rumble (<150Hz) produces low ZCR (<0.02) and low energy ratio, rejecting traffic noise
                        val isHumanSpeech = normalized >= 0.12f &&
                                speechBandNormalized >= 0.06f &&
                                zcr in 0.035f..0.38f &&
                                speechEnergyRatio >= 0.35f

                        onAmplitudeChanged(normalized)
                        onVoiceActivity(isHumanSpeech, normalized)
                        onAudioChunk(chunk)
                    } else if (readBytes < 0) {
                        // Read error, brief delay before retry
                        delay(20)
                    }
                } catch (e: Exception) {
                    if (isActive) {
                        delay(50)
                    }
                }
            }
        }
    }

    fun stop() {
        recordingJob?.cancel()
        recordingJob = null
        try {
            audioRecord?.apply {
                if (recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    stop()
                }
                release()
            }
        } catch (e: Exception) {
            // Ignore during cleanup
        } finally {
            audioRecord = null
            try {
                echoCanceler?.release()
                noiseSuppressor?.release()
                automaticGainControl?.release()
            } catch (_: Exception) {}
            echoCanceler = null
            noiseSuppressor = null
            automaticGainControl = null
            isSimulatedInput = false
            onAmplitudeChanged(0f)
        }
    }

    private fun startSimulatedStream(scope: CoroutineScope) {
        isSimulatedInput = true
        recordingJob = scope.launch(Dispatchers.IO) {
            // Emits 100ms chunks of 16kHz 16-bit mono silence (3200 bytes per chunk)
            val chunkBytes = 3200
            val silentChunk = ByteArray(chunkBytes)
            while (isActive) {
                onAudioChunk(silentChunk)
                onAmplitudeChanged(0f)
                onVoiceActivity(false, 0f)
                delay(100)
            }
        }
    }
}

