package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val QueenColorScheme = darkColorScheme(
    primary = QueenGold,
    onPrimary = Color.Black,
    primaryContainer = QueenGoldContainer,
    onPrimaryContainer = QueenOnGoldContainer,
    secondary = QueenGoldSoft,
    onSecondary = Color.Black,
    secondaryContainer = QueenGoldContainer,
    onSecondaryContainer = QueenGoldBright,
    background = QueenBackground,
    onBackground = QueenTextPrimary,
    surface = QueenSurface,
    onSurface = QueenTextPrimary,
    surfaceVariant = QueenSurfaceVariant,
    onSurfaceVariant = QueenTextSecondary,
    outline = QueenBorder,
    error = QueenError,
    onError = Color.Black
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = QueenColorScheme,
        typography = Typography,
        content = content
    )
}
