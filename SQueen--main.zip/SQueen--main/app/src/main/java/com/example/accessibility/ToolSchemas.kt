package com.example.accessibility

/**
 * OpenRing ToolSchemas defines the tool names, parameter specifications,
 * and system prompt descriptors for accessibility and intent actions.
 */
object ToolSchemas {

    const val TOOL_OPEN_APP = "open_app"
    const val TOOL_CLICK_ELEMENT = "click_element"
    const val TOOL_TYPE_TEXT = "type_text"
    const val TOOL_SCROLL = "scroll"
    const val TOOL_NAVIGATE_BACK = "navigate_back"
    const val TOOL_NAVIGATE_HOME = "navigate_home"
    const val TOOL_READ_SCREEN = "read_screen"

    /**
     * Concise instructions describing available device actions to Gemini Live assistant.
     */
    val PROMPT_INSTRUCTIONS = """
DEVICE ACCESSIBILITY & APP CONTROLS:
You can control the phone using the following action tags:
- Open an app: [OPEN_APP: app_name] (e.g. [OPEN_APP: YouTube], [OPEN_APP: WhatsApp], [OPEN_APP: Settings])
- Click a button or UI element: [CLICK_ELEMENT: text_or_id] (e.g. [CLICK_ELEMENT: Search], [CLICK_ELEMENT: Submit])
- Enter or type text: [TYPE_TEXT: text] (e.g. [TYPE_TEXT: Hello World])
- Scroll on screen: [SCROLL: down] or [SCROLL: up]
- Go back: [GO_BACK]
- Return to home: [GO_HOME]
- Read visible screen contents: [READ_SCREEN]

IMPORTANT ACCESSIBILITY RULES:
1. Always confirm with the user before performing destructive actions (like deleting data or making phone calls).
2. If an action fails or the accessibility service is disabled, report the failure honestly without pretending it succeeded.
""".trimIndent()
}
