package com.example.accessibility

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import com.example.accessibility.model.ActionResult
import com.example.accessibility.model.ErrorCode

/**
 * OpenRing IntentRouter launches supported apps and system destinations via Android intents.
 */
class IntentRouter {

    companion object {
        private val COMMON_APP_PACKAGES = mapOf(
            "youtube" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp",
            "chrome" to "com.android.chrome",
            "maps" to "com.google.android.apps.maps",
            "google maps" to "com.google.android.apps.maps",
            "gmail" to "com.google.android.gm",
            "calculator" to "com.google.android.calculator",
            "clock" to "com.google.android.deskclock",
            "spotify" to "com.spotify.music",
            "instagram" to "com.instagram.android",
            "telegram" to "org.telegram.messenger"
        )
    }

    /**
     * Launches an application given its name or package identifier.
     */
    fun launchApp(context: Context, appQuery: String): ActionResult {
        val query = appQuery.trim().lowercase()
        if (query.isEmpty()) {
            return ActionResult.failure("App name cannot be empty.", ErrorCode.UNSUPPORTED_ACTION)
        }

        val pm = context.packageManager

        // 1. Check known common system destinations
        when (query) {
            "settings", "setting", "phone settings" -> {
                return launchIntentSafe(context, Intent(Settings.ACTION_SETTINGS), "Settings")
            }
            "camera", "cam" -> {
                val cameraIntent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                return launchIntentSafe(context, cameraIntent, "Camera")
            }
            "contacts", "contact", "address book" -> {
                val contactsIntent = Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                return launchIntentSafe(context, contactsIntent, "Contacts")
            }
            "dialer", "phone", "call app" -> {
                val dialerIntent = Intent(Intent.ACTION_DIAL).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                return launchIntentSafe(context, dialerIntent, "Phone Dialer")
            }
            "browser", "internet", "web" -> {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                return launchIntentSafe(context, browserIntent, "Browser")
            }
            "alarm", "alarms", "clock" -> {
                val alarmIntent = Intent(AlarmClock.ACTION_SHOW_ALARMS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                if (alarmIntent.resolveActivity(pm) != null) {
                    return launchIntentSafe(context, alarmIntent, "Clock")
                }
            }
            "messages", "sms", "message" -> {
                val smsIntent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_APP_MESSAGING)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                if (smsIntent.resolveActivity(pm) != null) {
                    return launchIntentSafe(context, smsIntent, "Messages")
                }
            }
        }

        // 2. Check predefined package mappings
        val knownPackage = COMMON_APP_PACKAGES[query]
        if (knownPackage != null) {
            val launchIntent = pm.getLaunchIntentForPackage(knownPackage)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                return launchIntentSafe(context, launchIntent, query.replaceFirstChar { it.uppercase() })
            }
        }

        // 3. Check directly by package name if query contains a dot
        if (query.contains('.')) {
            val launchIntent = pm.getLaunchIntentForPackage(query)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                return launchIntentSafe(context, launchIntent, query)
            }
        }

        // 4. Search installed applications by display label
        try {
            val installed = pm.getInstalledApplications(0)
            for (appInfo in installed) {
                val label = pm.getApplicationLabel(appInfo).toString().lowercase()
                if (label == query || label.contains(query) || query.contains(label)) {
                    val launchIntent = pm.getLaunchIntentForPackage(appInfo.packageName)
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        val displayTitle = pm.getApplicationLabel(appInfo).toString()
                        return launchIntentSafe(context, launchIntent, displayTitle)
                    }
                }
            }
        } catch (e: Exception) {
            // Ignore search exceptions and fallback to failure
        }

        return ActionResult.failure("App '$appQuery' was not found on this device.", ErrorCode.APP_NOT_FOUND)
    }

    private fun launchIntentSafe(context: Context, intent: Intent, appName: String): ActionResult {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            ActionResult.success("Opened $appName.")
        } catch (e: ActivityNotFoundException) {
            ActionResult.failure("No application available to open $appName.", ErrorCode.APP_NOT_FOUND)
        } catch (e: SecurityException) {
            ActionResult.failure("Permission denied to open $appName.", ErrorCode.PERMISSION_DENIED)
        } catch (e: Exception) {
            ActionResult.failure("Could not open $appName: ${e.localizedMessage ?: "Unknown error"}", ErrorCode.ACTION_FAILED)
        }
    }
}
