package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.CredentialValidationState
import com.example.data.model.VoiceOption
import com.example.data.repository.AccessTokenRepository
import com.example.data.storage.CredentialStorage
import com.example.command.AssistantCommand
import com.example.command.CommandExecutor
import com.example.command.ContactsHelper
import com.example.command.ExecutionResult
import com.example.command.PendingCall
import kotlinx.coroutines.runBlocking
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read app name from context returns Queen`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Queen", appName)
    }

    @Test
    fun `verify four supported Gemini Live voice options exist`() {
        val voices = VoiceOption.ALL_VOICES
        assertEquals(4, voices.size)
        val ids = voices.map { it.id }
        assertTrue(ids.contains("Aoede"))
        assertTrue(ids.contains("Kore"))
        assertTrue(ids.contains("Leda"))
        assertTrue(ids.contains("Puck"))

        // Verify all 4 map to verified Gemini Live prebuilt voice IDs
        assertEquals("Aoede", VoiceOption.getGeminiVoiceName("Aoede"))
        assertEquals("Kore", VoiceOption.getGeminiVoiceName("Kore"))
        assertEquals("Leda", VoiceOption.getGeminiVoiceName("Leda"))
        assertEquals("Puck", VoiceOption.getGeminiVoiceName("Puck"))
    }

    @Test
    fun `voice selection persists across storage and reloads in ViewModel`() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        val storage = CredentialStorage(context)

        storage.saveVoice("Kore")
        assertEquals("Kore", storage.getVoice())

        storage.saveVoice("Leda")
        assertEquals("Leda", storage.getVoice())

        storage.saveVoice("Puck")
        assertEquals("Puck", storage.getVoice())

        storage.saveVoice("Aoede")
        assertEquals("Aoede", storage.getVoice())
    }

    @Test
    fun `gemini live session setup payload configures selected voice correctly`() {
        val manager = com.example.live.GeminiLiveSessionManager()

        for (voice in listOf("Aoede", "Kore", "Leda", "Puck")) {
            val geminiVoice = VoiceOption.getGeminiVoiceName(voice)
            val payloadStr = manager.createSetupPayload(
                voiceName = geminiVoice,
                userName = "TestUser",
                memories = emptyList()
            )
            val json = org.json.JSONObject(payloadStr)
            val voiceConfig = json.getJSONObject("setup")
                .getJSONObject("generationConfig")
                .getJSONObject("speechConfig")
                .getJSONObject("voiceConfig")
                .getJSONObject("prebuiltVoiceConfig")
            assertEquals(geminiVoice, voiceConfig.getString("voiceName"))
        }
    }

    @Test
    fun `credential masking hides secret characters`() {
        val maskedEmpty = CredentialStorage.maskSecret("")
        assertEquals("Not Configured", maskedEmpty)

        val maskedShort = CredentialStorage.maskSecret("12345")
        assertEquals("••••••••", maskedShort)

        val maskedLong = CredentialStorage.maskSecret("AIzaSyB8uK7192xyzabc1234")
        assertTrue(maskedLong.startsWith("AIza"))
        assertTrue(maskedLong.endsWith("1234"))
        assertTrue(maskedLong.contains("••••••••"))
    }

    @Test
    fun `queen access token verification correctly validates 10-char Q tokens and rejects invalid formats`() = runBlocking {
        val repo = AccessTokenRepository()
        val deviceId = "queen_dev_test_device"

        // 1. Empty token -> Invalid
        val emptyResult = repo.verifyToken("", deviceId)
        assertTrue(emptyResult is CredentialValidationState.Invalid)

        // 2. Wrong length (e.g. 8 chars) -> Invalid
        val shortResult = repo.verifyToken("Q7M4K9P2", deviceId)
        assertTrue(shortResult is CredentialValidationState.Invalid)

        // 3. Doesn't start with 'Q' -> Invalid
        val noQResult = repo.verifyToken("A7M4K9P2R6", deviceId)
        assertTrue(noQResult is CredentialValidationState.Invalid)

        // 4. Contains ambiguous characters like '0' or 'O' or 'I' -> Invalid
        val ambiguousResult = repo.verifyToken("Q7M4K9P0R6", deviceId)
        assertTrue(ambiguousResult is CredentialValidationState.Invalid)

        // 5. Revoked token -> Invalid
        val revokedResult = repo.verifyToken("QREVOKED99", deviceId)
        assertTrue(revokedResult is CredentialValidationState.Invalid)

        // 6. Valid format but unconfigured endpoint -> Invalid (No bypass allowed)
        val noEndpointResult = repo.verifyToken("Q7M4K9P2R6", deviceId, "")
        assertTrue(noEndpointResult is CredentialValidationState.Invalid)
        val errorMsg = (noEndpointResult as CredentialValidationState.Invalid).message
        assertTrue(errorMsg.contains("Firebase Token Verification endpoint is not configured"))
    }

    @Test
    fun `token normalization trims whitespace, converts to uppercase, and computes consistent SHA-256 hash`() = runBlocking {
        val rawToken = "Q7M4K9P2R6"
        val unnormalizedToken = "  q7m4k9p2r6  \t"

        // Both compute identical SHA-256 hashes
        val hashRaw = AccessTokenRepository.computeSha256(rawToken)
        val hashNormalized = AccessTokenRepository.computeSha256(unnormalizedToken)
        assertEquals(hashRaw, hashNormalized)

        // Storage also normalizes on save and retrieval
        val context = ApplicationProvider.getApplicationContext<Context>()
        val storage = CredentialStorage(context)
        storage.saveAppAccessToken(unnormalizedToken)
        assertEquals(rawToken, storage.getAppAccessToken())
    }

    @Test
    fun `token verification enforces single-device registration and rejects binding conflict`() = runBlocking {
        val mockClient = okhttp3.OkHttpClient.Builder()
            .addInterceptor { chain ->
                val request = chain.request()
                val deviceId = request.header("X-Device-Id")
                if (deviceId == "dev_owner_phone") {
                    okhttp3.Response.Builder()
                        .request(request)
                        .protocol(okhttp3.Protocol.HTTP_1_1)
                        .code(200)
                        .message("OK")
                        .body(
                            """{"valid": true, "status": "ACTIVE", "message": "Token registered"}"""
                                .toResponseBody("application/json".toMediaType())
                        )
                        .build()
                } else if (deviceId == "dev_second_phone") {
                    okhttp3.Response.Builder()
                        .request(request)
                        .protocol(okhttp3.Protocol.HTTP_1_1)
                        .code(409)
                        .message("Conflict")
                        .body(
                            """{"valid": false, "message": "This token is already registered to another device. Single-device license enforced."}"""
                                .toResponseBody("application/json".toMediaType())
                        )
                        .build()
                } else {
                    okhttp3.Response.Builder()
                        .request(request)
                        .protocol(okhttp3.Protocol.HTTP_1_1)
                        .code(401)
                        .message("Unauthorized")
                        .body(
                            """{"valid": false, "message": "Token not found"}"""
                                .toResponseBody("application/json".toMediaType())
                        )
                        .build()
                }
            }
            .build()

        val repo = AccessTokenRepository(mockClient)
        val testEndpoint = "https://my-firebase-project.cloudfunctions.net/verifyQueenToken"

        // Registered device succeeds
        val successResult = repo.verifyToken("Q7M4K9P2R6", "dev_owner_phone", testEndpoint)
        assertTrue(successResult is CredentialValidationState.Valid)

        // Second device attempting to use the same token is rejected with 409
        val conflictResult = repo.verifyToken("Q7M4K9P2R6", "dev_second_phone", testEndpoint)
        assertTrue(conflictResult is CredentialValidationState.Invalid)
        val conflictMsg = (conflictResult as CredentialValidationState.Invalid).message
        assertTrue(conflictMsg.contains("already registered to another device"))
    }

    @Test
    fun `credential storage saves loads persists and deletes api key and token properly`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val storage = CredentialStorage(context)

        // Initially clean
        storage.deleteGeminiApiKey()
        storage.deleteAppAccessToken()
        assertEquals("", storage.getGeminiApiKey())
        assertEquals("", storage.getAppAccessToken())

        // Save Gemini key
        val testKey = "AIzaSyTestUserCustomKey12345"
        storage.saveGeminiApiKey(testKey)
        assertEquals(testKey, storage.getGeminiApiKey())
        assertTrue(storage.hasGeminiApiKey())

        // Save Access token
        val testToken = "Q7M4K9P2R6"
        storage.saveAppAccessToken(testToken)
        assertEquals(testToken, storage.getAppAccessToken())
        assertTrue(storage.hasAppAccessToken())

        // Device ID is non-empty and stable
        val deviceId1 = storage.getOrCreateDeviceId()
        val deviceId2 = storage.getOrCreateDeviceId()
        assertTrue(deviceId1.isNotBlank())
        assertEquals(deviceId1, deviceId2)

        // Delete keys
        storage.deleteGeminiApiKey()
        assertEquals("", storage.getGeminiApiKey())
        assertFalse(storage.hasGeminiApiKey())

        storage.deleteAppAccessToken()
        assertEquals("", storage.getAppAccessToken())
        assertFalse(storage.hasAppAccessToken())
    }

    @Test
    fun `outgoing realtime audio payload uses realtimeInput audio and not deprecated mediaChunks`() {
        val manager = com.example.live.GeminiLiveSessionManager()
        val testPcmBase64 = "UklGRgAAAABXQVZFZm10"
        val payload = manager.createRealtimeAudioPayload(testPcmBase64)

        assertTrue(payload.has("realtimeInput"))
        val realtimeInput = payload.getJSONObject("realtimeInput")
        assertFalse("mediaChunks must not be present", realtimeInput.has("mediaChunks"))
        assertFalse("media_chunks must not be present", realtimeInput.has("media_chunks"))
        assertTrue("audio field must be present", realtimeInput.has("audio"))

        val audio = realtimeInput.getJSONObject("audio")
        assertEquals("audio/pcm;rate=16000", audio.getString("mimeType"))
        assertEquals(testPcmBase64, audio.getString("data"))
    }

    @Test
    fun `hindi tts manager phrase is correct and handles initialization`() {
        assertEquals("जी बोलिए", com.example.audio.HindiTtsManager.PHRASE)
        val context = ApplicationProvider.getApplicationContext<Context>()
        val ttsManager = com.example.audio.HindiTtsManager(context)
        ttsManager.speakJiBoliye()
        ttsManager.stop()
        ttsManager.shutdown()
    }

    @Test
    fun `gemini live voice test payloads are properly constructed with model voice and prompt`() {
        val manager = com.example.live.GeminiLiveSessionManager()
        val setupPayloadString = manager.createVoiceTestSetupPayload("Aoede")
        val setupJson = org.json.JSONObject(setupPayloadString)

        assertTrue(setupJson.has("setup"))
        val setup = setupJson.getJSONObject("setup")
        assertEquals("models/gemini-3.1-flash-live-preview", setup.getString("model"))

        val genConfig = setup.getJSONObject("generationConfig")
        val modalities = genConfig.getJSONArray("responseModalities")
        assertEquals("AUDIO", modalities.getString(0))

        val voiceConfig = genConfig.getJSONObject("speechConfig")
            .getJSONObject("voiceConfig")
            .getJSONObject("prebuiltVoiceConfig")
        assertEquals("Aoede", voiceConfig.getString("voiceName"))

        val promptPayloadString = manager.createVoiceTestPromptPayload()
        val promptJson = org.json.JSONObject(promptPayloadString)
        assertTrue(promptJson.has("clientContent"))
        val clientContent = promptJson.getJSONObject("clientContent")
        assertTrue(clientContent.getBoolean("turnComplete"))
        val turns = clientContent.getJSONArray("turns")
        val userTurn = turns.getJSONObject(0)
        assertEquals("user", userTurn.getString("role"))
        val parts = userTurn.getJSONArray("parts")
        assertTrue(parts.getJSONObject(0).getString("text").contains("जी बोलिए"))
    }

    @Test
    fun `gemini live session setup payload does not place inputAudioTranscription inside generationConfig`() {
        val manager = com.example.live.GeminiLiveSessionManager()
        val setupPayloadString = manager.createSetupPayload(
            voiceName = "Aoede",
            userName = "Shyam",
            memories = listOf("User likes masala chai")
        )
        val setupJson = org.json.JSONObject(setupPayloadString)
        assertTrue(setupJson.has("setup"))
        val setup = setupJson.getJSONObject("setup")

        assertEquals("models/gemini-3.1-flash-live-preview", setup.getString("model"))

        val genConfig = setup.getJSONObject("generationConfig")
        // inputAudioTranscription and outputAudioTranscription must NOT be inside generationConfig
        assertFalse(
            "generationConfig must not contain inputAudioTranscription",
            genConfig.has("inputAudioTranscription")
        )
        assertFalse(
            "generationConfig must not contain outputAudioTranscription",
            genConfig.has("outputAudioTranscription")
        )

        // They must reside directly under setup
        assertTrue("setup must contain inputAudioTranscription", setup.has("inputAudioTranscription"))
        assertTrue("setup must contain outputAudioTranscription", setup.has("outputAudioTranscription"))

        val modalities = genConfig.getJSONArray("responseModalities")
        assertEquals("AUDIO", modalities.getString(0))
    }

    @Test
    fun `rani system prompt contains brain personality rules creator name and mood instructions`() {
        val manager = com.example.live.GeminiLiveSessionManager()
        val testMemories = listOf("User likes masala chai in the morning", "Meeting at 4 PM")
        val prompt = manager.buildRaniSystemPrompt(userName = "Shyam", memories = testMemories)

        // 1. Identity & Creator
        assertTrue(prompt.contains("Rani SS"))
        assertTrue(prompt.contains("Shyam Kadam"))
        assertTrue(prompt.contains("Jalna, Maharashtra"))

        // 2. Personality & Spoken Voice
        assertTrue(prompt.contains("AVOID ROBOTIC REPETITION"))
        assertTrue(prompt.contains("आज आपका क्या प्लान है?"))
        assertTrue(prompt.contains("MOOD ADAPTATION & EMOTIONAL INTELLIGENCE"))
        assertTrue(prompt.contains("PLAYFUL PERSONALITY & BOUNDARIES"))
        assertTrue(prompt.contains("नकली रूठना"))

        // 3. Honesty & Boundaries
        assertTrue(prompt.contains("I can't open apps on your phone just yet"))
        assertTrue(prompt.contains("Camera Vision"))
        assertTrue(prompt.contains("Shyam"))
        assertTrue(prompt.contains("User likes masala chai in the morning"))

        // 4. Friend-First & Roasting Rules
        assertTrue(prompt.contains("FRIEND FIRST, NEVER A COLD ROBOT"))
        assertTrue(prompt.contains("तुम रोबोट हो क्या?"))
        assertTrue(prompt.contains("FRIENDLY ROASTING"))
        assertTrue(prompt.contains("मुझे रोस्ट करो"))
    }

    @Test
    fun `practical android integrity check returns secure status on standard environment`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val result = com.example.security.AppIntegrityManager.checkIntegrity(context)
        // In clean test/emulator environment, no root su or frida is installed
        assertFalse("Practical check should not flag clean test runtime", result.isTampered)
    }

    @Test
    fun `gemini live session manager rejects startSession without accessToken`() = runBlocking {
        val manager = com.example.live.GeminiLiveSessionManager()
        manager.startSession(
            scope = this,
            apiKey = "AIzaSyTestKey12345",
            voiceName = "Aoede",
            userName = "TestUser",
            accessToken = "" // Empty token
        )
        val state = manager.assistantState.value
        assertTrue(state is com.example.data.model.AssistantState.Error)
        val errorMsg = (state as com.example.data.model.AssistantState.Error).message
        assertTrue(errorMsg.contains("Queen App Access Token is required"))
    }

    @Test
    fun `gemini live session manager rejects startVoiceTest without accessToken`() = runBlocking {
        val manager = com.example.live.GeminiLiveSessionManager()
        manager.startVoiceTest(
            scope = this,
            apiKey = "AIzaSyTestKey12345",
            voiceName = "Aoede",
            accessToken = "" // Empty token
        )
        val state = manager.assistantState.value
        assertTrue(state is com.example.data.model.AssistantState.Error)
        val errorMsg = (state as com.example.data.model.AssistantState.Error).message
        assertTrue(errorMsg.contains("Queen App Access Token is required"))
    }

    @Test
    fun `token verification rejects expired token response`() = runBlocking {
        val mockClient = okhttp3.OkHttpClient.Builder()
            .addInterceptor { chain ->
                val request = chain.request()
                okhttp3.Response.Builder()
                    .request(request)
                    .protocol(okhttp3.Protocol.HTTP_1_1)
                    .code(403)
                    .message("Forbidden")
                    .body(
                        """{"valid": false, "message": "This access token has expired."}"""
                            .toResponseBody("application/json".toMediaType())
                    )
                    .build()
            }
            .build()

        val repo = AccessTokenRepository(mockClient)
        val result = repo.verifyToken(
            "Q7M4K9P2R6",
            "test_device_id",
            "https://my-firebase-project.cloudfunctions.net/verifyQueenToken"
        )
        assertTrue(result is CredentialValidationState.Invalid)
        val msg = (result as CredentialValidationState.Invalid).message
        assertTrue(msg.contains("expired"))
    }

    @Test
    fun `conversation history saves available transcript and clears independently without deleting memories`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val memoryRepo = com.example.data.repository.MemoryRepository(context)

        // Clear initially
        memoryRepo.clearConversationHistory()
        memoryRepo.clearImportantMemories()

        // 1. Save conversation transcripts
        val saved1 = memoryRepo.saveConversationMessage("queen", "नमस्ते! मैं रानी हूँ।")
        val saved2 = memoryRepo.saveConversationMessage("queen", "मैं आपकी क्या मदद कर सकती हूँ?")
        assertTrue(saved1)
        assertTrue(saved2)

        // 2. Save an important memory
        val savedMem = memoryRepo.saveImportantMemory("User's favorite color is blue", "FACT")
        assertTrue(savedMem)

        var stats = memoryRepo.getStorageStats()
        assertEquals(2, stats.historyCount)
        assertEquals(1, stats.memoryCount)

        // 3. Clear conversation history ONLY
        val deletedCount = memoryRepo.clearConversationHistory()
        assertEquals(2, deletedCount)

        stats = memoryRepo.getStorageStats()
        // Conversation history cleared to 0
        assertEquals(0, stats.historyCount)
        // Important memory is preserved!
        assertEquals(1, stats.memoryCount)

        val activeMemories = memoryRepo.getActiveMemoriesForPrompt()
        assertEquals(1, activeMemories.size)
        assertEquals("User's favorite color is blue", activeMemories[0])
    }

    @Test
    fun `important memories deduplicate entries and support categorization`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val memoryRepo = com.example.data.repository.MemoryRepository(context)

        memoryRepo.clearImportantMemories()

        // Add task memory
        val res1 = memoryRepo.saveImportantMemory("Buy groceries at 5 PM", "TASK")
        assertTrue(res1)

        // Duplicate entry (case-insensitive) should safely return true without duplicate rows
        val res2 = memoryRepo.saveImportantMemory("buy groceries at 5 pm", "TASK")
        assertTrue(res2)

        val stats = memoryRepo.getStorageStats()
        assertEquals(1, stats.memoryCount)

        // Add plan memory
        val res3 = memoryRepo.saveImportantMemory("Visit Jaipur next month", "PLAN")
        assertTrue(res3)

        val active = memoryRepo.getActiveMemoriesForPrompt()
        assertEquals(2, active.size)
    }

    @Test
    fun `memory backup export and restore safely validates JSON schema and restores items`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val memoryRepo = com.example.data.repository.MemoryRepository(context)

        memoryRepo.clearConversationHistory()
        memoryRepo.clearImportantMemories()

        memoryRepo.saveConversationMessage("queen", "Turn 1 transcript")
        memoryRepo.saveImportantMemory("User loves coding in Kotlin", "FACT")

        // 1. Export backup
        val exportResult = memoryRepo.exportBackup()
        assertTrue(exportResult.success)
        assertTrue(exportResult.filePath.isNotEmpty())
        assertEquals(1, exportResult.historyCount)
        assertEquals(1, exportResult.memoryCount)

        val file = java.io.File(exportResult.filePath)
        assertTrue(file.exists())
        val backupJson = file.readText()

        // 2. Clear all
        memoryRepo.clearConversationHistory()
        memoryRepo.clearImportantMemories()
        assertEquals(0, memoryRepo.getStorageStats().historyCount)
        assertEquals(0, memoryRepo.getStorageStats().memoryCount)

        // 3. Restore backup
        val restoreResult = memoryRepo.restoreBackup(backupJson)
        assertTrue(restoreResult.success)
        assertEquals(1, restoreResult.restoredHistoryCount)
        assertEquals(1, restoreResult.restoredMemoryCount)

        val finalStats = memoryRepo.getStorageStats()
        assertEquals(1, finalStats.historyCount)
        assertEquals(1, finalStats.memoryCount)
    }

    @Test
    fun `memory restore rejects invalid or empty JSON safely without false success claims`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val memoryRepo = com.example.data.repository.MemoryRepository(context)

        // Empty string
        val emptyResult = memoryRepo.restoreBackup("")
        assertFalse(emptyResult.success)
        assertTrue(emptyResult.message.contains("empty", ignoreCase = true))

        // Corrupted JSON
        val invalidResult = memoryRepo.restoreBackup("{not_valid_json")
        assertFalse(invalidResult.success)

        // Unrecognized format
        val unrecognizedResult = memoryRepo.restoreBackup("""{"random_key": 123}""")
        assertFalse(unrecognizedResult.success)
    }

    @Test
    fun `rani memory extraction automatically saves facts with rani hindi and english prefixes`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val memoryRepo = com.example.data.repository.MemoryRepository(context)

        memoryRepo.clearImportantMemories()

        // Test Hindi prefix "रानी याद रखना कि"
        memoryRepo.saveConversationMessage("user", "रानी याद रखना कि कल सुबह 9 बजे मीटिंग है")
        val memories = memoryRepo.getActiveMemoriesForPrompt()
        assertTrue(memories.any { it.contains("कल सुबह 9 बजे मीटिंग है") })

        // Test verbal directive "remember this"
        memoryRepo.saveConversationMessage("user", "remember this: my favorite dish is paneer tikka")
        val updatedMemories = memoryRepo.getActiveMemoriesForPrompt()
        assertTrue(updatedMemories.any { it.contains("my favorite dish is paneer tikka") })

        // Test user directive "save a fact:"
        memoryRepo.saveConversationMessage("user", "save a fact: my anniversary is on October 24")
        val withAnniversary = memoryRepo.getActiveMemoriesForPrompt()
        assertTrue(withAnniversary.any { it.contains("my anniversary is on October 24") })

        // Test user directive "Queen please remember this that ..."
        memoryRepo.saveConversationMessage("user", "Queen please remember this that I am allergic to peanuts")
        val withAllergy = memoryRepo.getActiveMemoriesForPrompt()
        assertTrue(withAllergy.any { it.contains("I am allergic to peanuts") })

        // Test trailing "remember this"
        memoryRepo.saveConversationMessage("user", "The car is parked on floor 3, remember this.")
        val withCar = memoryRepo.getActiveMemoriesForPrompt()
        assertTrue(withCar.any { it.contains("The car is parked on floor 3") })

        // Test explicit Hindi variation "रानी, यह याद रखना"
        memoryRepo.saveConversationMessage("user", "रानी, यह याद रखना कि मेरी दवा का समय दोपहर 2 बजे है")
        val withDawa = memoryRepo.getActiveMemoriesForPrompt()
        assertTrue(withDawa.any { it.contains("मेरी दवा का समय दोपहर 2 बजे है") })

        // Test assistant confirmation tag [REMEMBER: ...]
        memoryRepo.saveConversationMessage("queen", "बिल्कुल! [REMEMBER: यूजर का जन्मदिन 15 अगस्त है]")
        val withBirthday = memoryRepo.getActiveMemoriesForPrompt()
        assertTrue(withBirthday.any { it.contains("यूजर का जन्मदिन 15 अगस्त है") })

        // Test assistant confirmation phrase "मैंने याद रख लिया कि..."
        memoryRepo.saveConversationMessage("queen", "ज़रूर! मैंने याद रख लिया कि कल शाम 6 बजे डॉक्टर की अपॉइंटमेंट है।")
        val withDoctor = memoryRepo.getActiveMemoriesForPrompt()
        assertTrue(withDoctor.any { it.contains("कल शाम 6 बजे डॉक्टर की अपॉइंटमेंट है") })
    }

    @Test
    fun `verify queen destinations includes storage_memory route`() {
        assertEquals("storage_memory", QueenDestinations.STORAGE_MEMORY)
    }

    @Test
    fun `verify queen destinations includes camera_vision route`() {
        assertEquals("camera_vision", QueenDestinations.CAMERA_VISION)
    }

    @Test
    fun `gemini live session manager correctly formats realtime image payload for vision`() {
        val manager = com.example.live.GeminiLiveSessionManager()
        val dummyBase64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII="
        val payload = manager.createRealtimeImagePayload(dummyBase64)

        assertTrue(payload.has("realtimeInput"))
        val input = payload.getJSONObject("realtimeInput")
        assertFalse("mediaChunks must not be present", input.has("mediaChunks"))
        assertFalse("media_chunks must not be present", input.has("media_chunks"))
        assertTrue("video field must be present", input.has("video"))

        val video = input.getJSONObject("video")
        assertEquals("image/jpeg", video.getString("mimeType"))
        assertEquals(dummyBase64, video.getString("data"))
    }

    @Test
    fun `temporary testing access window activates for 2 hours in debug builds`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val storage = CredentialStorage(context)

        // Clear any stored start time for clean test
        context.getSharedPreferences("aarohi_secure_vault", Context.MODE_PRIVATE)
            .edit()
            .remove("debug_testing_window_start_time")
            .commit()

        // In debug build, first activation starts the 2-hour window and returns true
        val active = storage.isTemporaryTestingAccessActive()
        assertEquals(BuildConfig.DEBUG, active)

        // Verify start time was recorded in SharedPreferences
        val prefs = context.getSharedPreferences("aarohi_secure_vault", Context.MODE_PRIVATE)
        val recordedStartTime = prefs.getLong("debug_testing_window_start_time", 0L)
        if (BuildConfig.DEBUG) {
            assertTrue(recordedStartTime > 0L)
            assertTrue(System.currentTimeMillis() - recordedStartTime < 5000L)
        }

        // Test AarohiViewModel.isTemporaryTestingAccessActive
        val vmActive = com.example.ui.viewmodel.AarohiViewModel.isTemporaryTestingAccessActive()
        assertEquals(BuildConfig.DEBUG, vmActive)

        // Test window expiration after 2 hours
        prefs.edit()
            .putLong("debug_testing_window_start_time", System.currentTimeMillis() - (2 * 60 * 60 * 1000L + 1000L))
            .commit()
        assertFalse(storage.isTemporaryTestingAccessActive())
    }

    @Test
    fun `acceptance test speak name mention friend state preference and past event auto saves to long-term memory`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        var memoryRepo = com.example.data.repository.MemoryRepository(context)

        // Clear existing memories for a fresh test run
        memoryRepo.clearConversationHistory()
        memoryRepo.clearImportantMemories()

        // 1. Speak a name
        memoryRepo.saveConversationMessage("user", "My name is Shyam")

        // 2. Mention a friend
        memoryRepo.saveConversationMessage("user", "My friend is Rohan")

        // 3. State one preference
        memoryRepo.saveConversationMessage("user", "My favorite food is pizza")

        // 4. Describe a past event
        memoryRepo.saveConversationMessage("user", "I visited Paris last summer")

        // 5. Speak ordinary greetings (must NOT be saved as memories)
        memoryRepo.saveConversationMessage("user", "Hello Queen")
        memoryRepo.saveConversationMessage("user", "Good morning Rani, how are you?")
        memoryRepo.saveConversationMessage("user", "नमस्ते रानी")

        // Verify memories are extracted automatically without pressing + Add
        var activeMemories = memoryRepo.getActiveMemoriesForPrompt()
        assertEquals(4, activeMemories.size)
        assertTrue("Name must be saved", activeMemories.any { it.contains("Shyam") })
        assertTrue("Friend must be saved", activeMemories.any { it.contains("Rohan") })
        assertTrue("Preference must be saved", activeMemories.any { it.contains("pizza") })
        assertTrue("Past event must be saved", activeMemories.any { it.contains("Paris") })

        // Verify greetings were NOT saved into memories
        assertFalse("Greeting must not be saved", activeMemories.any { it.contains("Hello", ignoreCase = true) })
        assertFalse("Greeting must not be saved", activeMemories.any { it.contains("Good morning", ignoreCase = true) })
        assertFalse("Greeting must not be saved", activeMemories.any { it.contains("नमस्ते") })

        // 6. Simulate closing and reopening the app (new repository instance using same persistent database)
        val reopenedMemoryRepo = com.example.data.repository.MemoryRepository(context)
        val persistedMemories = reopenedMemoryRepo.getActiveMemoriesForPrompt()
        assertEquals("Memories must remain available after closing and reopening the app", 4, persistedMemories.size)
        assertTrue(persistedMemories.any { it.contains("Shyam") })
        assertTrue(persistedMemories.any { it.contains("Rohan") })
        assertTrue(persistedMemories.any { it.contains("pizza") })
        assertTrue(persistedMemories.any { it.contains("Paris") })

        // 7. Clearing conversation history must NOT delete long-term memories
        reopenedMemoryRepo.clearConversationHistory()
        val memoriesAfterClearingHistory = reopenedMemoryRepo.getActiveMemoriesForPrompt()
        assertEquals("Clearing history must strictly preserve long-term memories", 4, memoriesAfterClearingHistory.size)
    }

    @Test
    fun `privacy guard ensures secrets passwords and tokens are never automatically saved to memory`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val memoryRepo = com.example.data.repository.MemoryRepository(context)
        memoryRepo.clearImportantMemories()

        memoryRepo.saveConversationMessage("user", "My password is SecretPassword123!")
        memoryRepo.saveConversationMessage("user", "Here is my api key AIzaSyTestKeyXYZ12345")
        memoryRepo.saveConversationMessage("user", "My access token is Q7M4K9P2R6")

        val memories = memoryRepo.getActiveMemoriesForPrompt()
        assertEquals("No secrets or tokens should ever be saved to memories", 0, memories.size)
    }

    @Test
    fun `contradictions are automatically resolved by updating existing facts`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val memoryRepo = com.example.data.repository.MemoryRepository(context)
        memoryRepo.clearImportantMemories()

        // Initial fact
        memoryRepo.saveConversationMessage("user", "My favorite color is blue")
        var memories = memoryRepo.getActiveMemoriesForPrompt()
        assertEquals(1, memories.size)
        assertTrue(memories.any { it.contains("blue") })

        // Contradicting update
        memoryRepo.saveConversationMessage("user", "My favorite color is emerald green")
        memories = memoryRepo.getActiveMemoriesForPrompt()
        assertEquals(1, memories.size)
        assertTrue(memories.any { it.contains("emerald green") })
        assertFalse(memories.any { it.contains("blue") })
    }

    @Test
    fun `queens own replies and acknowledgements are strictly excluded from memory saving`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val memoryRepo = com.example.data.repository.MemoryRepository(context)
        memoryRepo.clearImportantMemories()

        // Queen replies with acknowledgment or speaking statements
        memoryRepo.saveConversationMessage("queen", "मैंने याद रख लिया कि आपका नाम श्याम है")
        memoryRepo.saveConversationMessage("queen", "I have remembered that you love pizza!")
        memoryRepo.saveConversationMessage("queen", "I am Queen, your personal AI voice companion.")
        memoryRepo.saveConversationMessage("queen", "My friend is Siri.")
        memoryRepo.saveConversationMessage("queen", "I love assisting you.")

        val memories = memoryRepo.getActiveMemoriesForPrompt()
        assertEquals("Queen's replies must never be saved as user facts", 0, memories.size)
    }

    @Test
    fun `explicit remember requests save reliably and duplicates are prevented`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val memoryRepo = com.example.data.repository.MemoryRepository(context)
        memoryRepo.clearImportantMemories()

        // Explicit remember request
        memoryRepo.saveConversationMessage("user", "Remember this: My friend is David")
        var memories = memoryRepo.getActiveMemoriesForPrompt()
        assertEquals(1, memories.size)
        assertTrue(memories.any { it.contains("David") })

        // Repeating same request does not create duplicate
        memoryRepo.saveConversationMessage("user", "Remember this: My friend is David")
        memories = memoryRepo.getActiveMemoriesForPrompt()
        assertEquals("Duplicate memory must be prevented", 1, memories.size)

        // Custom explicit request preserved
        memoryRepo.saveConversationMessage("user", "Please remember that flight AA102 leaves at 9 AM")
        memories = memoryRepo.getActiveMemoriesForPrompt()
        assertEquals(2, memories.size)
        assertTrue(memories.any { it.contains("flight AA102 leaves at 9 AM") })
    }

    @Test
    fun `automatic memory extraction correctly extracts birthdays anniversaries dislikes friends and relations`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val memoryRepo = com.example.data.repository.MemoryRepository(context)
        memoryRepo.clearImportantMemories()

        // 1. Birthday
        memoryRepo.saveConversationMessage("user", "My birthday is on August 15")
        // 2. Anniversary
        memoryRepo.saveConversationMessage("user", "My anniversary is on October 24")
        // 3. Dislike
        memoryRepo.saveConversationMessage("user", "I don't like broccoli")
        // 4. Friend
        memoryRepo.saveConversationMessage("user", "I have a friend named Vikram")
        // 5. Relationship
        memoryRepo.saveConversationMessage("user", "My sister is Ananya")

        val memories = memoryRepo.getActiveMemoriesForPrompt()
        assertEquals(5, memories.size)
        assertTrue("Birthday must be saved", memories.any { it.contains("August 15") })
        assertTrue("Anniversary must be saved", memories.any { it.contains("October 24") })
        assertTrue("Dislike must be saved", memories.any { it.contains("broccoli") })
        assertTrue("Friend must be saved", memories.any { it.contains("Vikram") })
        assertTrue("Sister relation must be saved", memories.any { it.contains("Ananya") })
    }

    @Test
    fun `complete pipeline test from user speech to local db insert and reload after simulated restart`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val memoryRepo1 = com.example.data.repository.MemoryRepository(context)
        memoryRepo1.clearImportantMemories()
        memoryRepo1.clearConversationHistory()

        // User speaks a personal fact
        val messageSaved = memoryRepo1.saveConversationMessage("user", "My favorite food is lasagna")
        assertTrue(messageSaved)

        // Verify inserted into DB and active memories flow
        val memoriesBeforeRestart = memoryRepo1.getActiveMemoriesForPrompt()
        assertEquals(1, memoriesBeforeRestart.size)
        assertTrue(memoriesBeforeRestart[0].contains("lasagna"))

        // Simulate application restart with a fresh MemoryRepository instance connecting to same SQLite database
        val memoryRepo2 = com.example.data.repository.MemoryRepository(context)
        val memoriesAfterRestart = memoryRepo2.getActiveMemoriesForPrompt()
        assertEquals(1, memoriesAfterRestart.size)
        assertTrue(memoriesAfterRestart[0].contains("lasagna"))

        // Stats reflect the stored records
        val stats = memoryRepo2.getStorageStats()
        assertEquals(1, stats.historyCount)
        assertEquals(1, stats.memoryCount)
    }

    @Test
    fun `verify queen destinations includes permissions route`() {
        assertEquals("permissions", QueenDestinations.PERMISSIONS)
    }

    @Test
    fun `check accessibility service returns false in clean test environment without crashing`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val isEnabled = com.example.ui.screens.checkAccessibilityServiceEnabled(context)
        assertFalse(isEnabled)
    }

    @Test
    fun `test AssistantCommand parses english call requests`() {
        val cmd1 = AssistantCommand.parse("call Rahul")
        assertTrue(cmd1 is AssistantCommand.CallContact)
        assertEquals("Rahul", (cmd1 as AssistantCommand.CallContact).contactName)

        val cmd2 = AssistantCommand.parse("please call Shyam Kadam")
        assertTrue(cmd2 is AssistantCommand.CallContact)
        assertEquals("Shyam Kadam", (cmd2 as AssistantCommand.CallContact).contactName)

        val cmd3 = AssistantCommand.parse("make a call to Mom")
        assertTrue(cmd3 is AssistantCommand.CallContact)
        assertEquals("Mom", (cmd3 as AssistantCommand.CallContact).contactName)
    }

    @Test
    fun `test AssistantCommand parses hindi and hinglish call requests`() {
        val cmd1 = AssistantCommand.parse("राहुल को कॉल करो")
        assertTrue(cmd1 is AssistantCommand.CallContact)
        assertEquals("राहुल", (cmd1 as AssistantCommand.CallContact).contactName)

        val cmd2 = AssistantCommand.parse("Shyam ko phone lagao")
        assertTrue(cmd2 is AssistantCommand.CallContact)
        assertEquals("Shyam", (cmd2 as AssistantCommand.CallContact).contactName)

        val cmd3 = AssistantCommand.parse("कॉल करो पूजा को")
        assertTrue(cmd3 is AssistantCommand.CallContact)
        assertEquals("पूजा", (cmd3 as AssistantCommand.CallContact).contactName)

        val cmd4 = AssistantCommand.parse("अमित को फोन मिलाओ")
        assertTrue(cmd4 is AssistantCommand.CallContact)
        assertEquals("अमित", (cmd4 as AssistantCommand.CallContact).contactName)
    }

    @Test
    fun `test AssistantCommand parses confirmation when pending`() {
        // Affirmative in Hindi and English
        val confirmEn = AssistantCommand.parse("yes please", isPendingConfirmation = true)
        assertTrue(confirmEn is AssistantCommand.ConfirmCall)
        assertTrue((confirmEn as AssistantCommand.ConfirmCall).confirmed)

        val confirmHi = AssistantCommand.parse("हाँ लगा दो", isPendingConfirmation = true)
        assertTrue(confirmHi is AssistantCommand.ConfirmCall)
        assertTrue((confirmHi as AssistantCommand.ConfirmCall).confirmed)

        val confirmSure = AssistantCommand.parse("sure", isPendingConfirmation = true)
        assertTrue(confirmSure is AssistantCommand.ConfirmCall)
        assertTrue((confirmSure as AssistantCommand.ConfirmCall).confirmed)

        // Negative in Hindi and English
        val cancelEn = AssistantCommand.parse("cancel", isPendingConfirmation = true)
        assertTrue(cancelEn is AssistantCommand.ConfirmCall)
        assertFalse((cancelEn as AssistantCommand.ConfirmCall).confirmed)

        val cancelHi = AssistantCommand.parse("नहीं मत करो", isPendingConfirmation = true)
        assertTrue(cancelHi is AssistantCommand.ConfirmCall)
        assertFalse((cancelHi as AssistantCommand.ConfirmCall).confirmed)
    }

    @Test
    fun `test ContactsHelper cleanPhoneNumber correctly normalizes numbers`() {
        assertEquals("+919876543210", ContactsHelper.cleanPhoneNumber("+91 (987) 654-3210"))
        assertEquals("0801234567", ContactsHelper.cleanPhoneNumber("080-123 4567"))
        assertEquals("123456", ContactsHelper.cleanPhoneNumber(" 123 - 456 "))
    }

    @Test
    fun `test CommandExecutor requires contacts permission if not granted`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val executor = CommandExecutor(context)

        val result = executor.processInput("Call Rahul")
        // In clean test environment without granted READ_CONTACTS, returns PermissionRequired
        assertTrue(result is ExecutionResult.PermissionRequired)
        assertEquals(android.Manifest.permission.READ_CONTACTS, (result as ExecutionResult.PermissionRequired).permission)
    }

    @Test
    fun `test CommandExecutor pending call confirmation cycle`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val executor = CommandExecutor(context)

        assertFalse(executor.hasPendingCall())

        // Simulating a pending call directly
        val field = CommandExecutor::class.java.getDeclaredField("pendingCall")
        field.isAccessible = true
        field.set(executor, PendingCall("Rahul Sharma", "+919876543210"))

        assertTrue(executor.hasPendingCall())
        assertEquals("Rahul Sharma", executor.getPendingCall()?.contactName)

        // User says cancel
        val cancelResult = executor.processInput("नहीं मत लगाओ")
        assertTrue(cancelResult is ExecutionResult.CallCancelled)
        assertFalse(executor.hasPendingCall())
    }

    @Test
    fun `test CommandExecutor confirmAndExecuteCall launches call intent when permission is granted`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val shadowApp = org.robolectric.Shadows.shadowOf(context as android.app.Application)
        shadowApp.grantPermissions(android.Manifest.permission.CALL_PHONE)

        val executor = CommandExecutor(context)
        val field = CommandExecutor::class.java.getDeclaredField("pendingCall")
        field.isAccessible = true
        field.set(executor, PendingCall("Pooja", "+919876543210"))

        val result = executor.confirmAndExecuteCall()
        assertTrue(result is ExecutionResult.CallInitiated)
        val initiated = result as ExecutionResult.CallInitiated
        assertEquals("Pooja", initiated.contactName)
        assertEquals("+919876543210", initiated.phoneNumber)
        assertFalse(executor.hasPendingCall())

        val startedIntent = shadowApp.nextStartedActivity
        org.junit.Assert.assertNotNull(startedIntent)
        assertEquals(android.content.Intent.ACTION_CALL, startedIntent.action)
        assertEquals("+919876543210", startedIntent.data?.schemeSpecificPart)
    }

    @Test
    fun `test CommandExecutor confirmAndExecuteCall requires permission when CALL_PHONE is not granted`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val shadowApp = org.robolectric.Shadows.shadowOf(context as android.app.Application)
        shadowApp.denyPermissions(android.Manifest.permission.CALL_PHONE)

        val executor = CommandExecutor(context)
        val field = CommandExecutor::class.java.getDeclaredField("pendingCall")
        field.isAccessible = true
        field.set(executor, PendingCall("Pooja", "+919876543210"))

        val result = executor.confirmAndExecuteCall()
        assertTrue(result is ExecutionResult.PermissionRequired)
        assertEquals(android.Manifest.permission.CALL_PHONE, (result as ExecutionResult.PermissionRequired).permission)
        // Intent should not have been launched
        org.junit.Assert.assertNull(shadowApp.nextStartedActivity)
    }

    @Test
    fun `test JarvisAccessibilityService is registered in manifest with label`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val serviceComponent = android.content.ComponentName(context, com.example.service.JarvisAccessibilityService::class.java)
        val serviceInfo = context.packageManager.getServiceInfo(serviceComponent, android.content.pm.PackageManager.GET_META_DATA)
        org.junit.Assert.assertNotNull(serviceInfo)
        assertEquals("android.permission.BIND_ACCESSIBILITY_SERVICE", serviceInfo.permission)
        val label = serviceInfo.loadLabel(context.packageManager).toString()
        assertTrue("Service label should not be blank", label.isNotBlank())
        assertTrue("Service label should mention Accessibility", label.contains("Accessibility", ignoreCase = true))
    }

    @Test
    fun `test checkNotificationsEnabled returns valid boolean without crash`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val enabled = com.example.ui.screens.checkNotificationsEnabled(context)
        // Under Robolectric, NotificationManagerCompat or ContextCompat evaluates cleanly
        org.junit.Assert.assertNotNull(enabled)
    }

    @Test
    fun `test direct phone number dialing triggers ConfirmationRequested without needing contacts permission`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val executor = CommandExecutor(context)

        val result = executor.initiateContactLookup("+91 98765-43210")
        assertTrue(result is ExecutionResult.ConfirmationRequested)
        val conf = result as ExecutionResult.ConfirmationRequested
        assertEquals("+91 98765-43210", conf.contactName)
        assertEquals("+919876543210", conf.phoneNumber)
        assertTrue(executor.hasPendingCall())
    }

    @Test
    fun `test AssistantCommand parses OpenRing action tags and voice utterances`() {
        // Tag parsing
        val openTag = AssistantCommand.parse("[OPEN_APP: YouTube]")
        assertTrue(openTag is AssistantCommand.OpenApp)
        assertEquals("YouTube", (openTag as AssistantCommand.OpenApp).appName)

        val clickTag = AssistantCommand.parse("[CLICK_ELEMENT: Search]")
        assertTrue(clickTag is AssistantCommand.ClickElement)
        assertEquals("Search", (clickTag as AssistantCommand.ClickElement).target)

        val typeTag = AssistantCommand.parse("[TYPE_TEXT: Hello World]")
        assertTrue(typeTag is AssistantCommand.TypeText)
        assertEquals("Hello World", (typeTag as AssistantCommand.TypeText).text)

        val scrollTag = AssistantCommand.parse("[SCROLL: down]")
        assertTrue(scrollTag is AssistantCommand.ScrollScreen)
        assertEquals("down", (scrollTag as AssistantCommand.ScrollScreen).direction)

        assertEquals(AssistantCommand.GoBack, AssistantCommand.parse("[GO_BACK]"))
        assertEquals(AssistantCommand.GoHome, AssistantCommand.parse("[GO_HOME]"))
        assertEquals(AssistantCommand.ReadScreen, AssistantCommand.parse("[READ_SCREEN]"))

        // Natural voice utterances
        val openUtterance = AssistantCommand.parse("open YouTube")
        assertTrue(openUtterance is AssistantCommand.OpenApp)
        assertEquals("YouTube", (openUtterance as AssistantCommand.OpenApp).appName)

        val openHiUtterance = AssistantCommand.parse("WhatsApp kholo")
        assertTrue(openHiUtterance is AssistantCommand.OpenApp)
        assertEquals("WhatsApp", (openHiUtterance as AssistantCommand.OpenApp).appName)

        val backUtterance = AssistantCommand.parse("go back")
        assertEquals(AssistantCommand.GoBack, backUtterance)

        val homeUtterance = AssistantCommand.parse("go home")
        assertEquals(AssistantCommand.GoHome, homeUtterance)
    }

    @Test
    fun `test Gemini Live setup payload includes OpenRing device accessibility instructions`() {
        val manager = com.example.live.GeminiLiveSessionManager()
        val payload = manager.createSetupPayload("Aoede", "Shyam")
        val json = org.json.JSONObject(payload)
        val parts = json.getJSONObject("setup")
            .getJSONObject("systemInstruction")
            .getJSONArray("parts")
        val promptText = parts.getJSONObject(0).getString("text")

        assertTrue(promptText.contains("DEVICE ACCESSIBILITY & APP CONTROLS"))
        assertTrue(promptText.contains("[OPEN_APP: app_name]"))
        assertTrue(promptText.contains("[CLICK_ELEMENT: label_or_id]"))
        assertTrue(promptText.contains("[READ_SCREEN]"))
        assertFalse(promptText.contains("You cannot open apps on your phone"))
    }

    @Test
    fun `test IntentRouter launches settings via system intent`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val shadowApp = org.robolectric.Shadows.shadowOf(context as android.app.Application)
        val router = com.example.accessibility.IntentRouter()

        val result = router.launchApp(context, "settings")
        assertTrue(result.isSuccess)
        val intent = shadowApp.nextStartedActivity
        org.junit.Assert.assertNotNull(intent)
        assertEquals(android.provider.Settings.ACTION_SETTINGS, intent.action)
    }

    @Test
    fun `test QueenVoiceForegroundService is registered in manifest with microphone type`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val serviceComponent = android.content.ComponentName(context, com.example.service.QueenVoiceForegroundService::class.java)
        val serviceInfo = context.packageManager.getServiceInfo(serviceComponent, android.content.pm.PackageManager.GET_SERVICES)
        org.junit.Assert.assertNotNull(serviceInfo)
        assertEquals("com.example.service.QueenVoiceForegroundService", serviceInfo.name)
        assertFalse("QueenVoiceForegroundService should not be exported", serviceInfo.exported)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            val hasMicrophoneType = (serviceInfo.foregroundServiceType and android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) != 0
            assertTrue("Service must declare FOREGROUND_SERVICE_TYPE_MICROPHONE", hasMicrophoneType)
        }
    }

    @Test
    fun `test QueenVoiceForegroundService start and stop lifecycle`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val shadowApp = org.robolectric.Shadows.shadowOf(context as android.app.Application)
        shadowApp.grantPermissions(android.Manifest.permission.RECORD_AUDIO)

        var stopCallbackInvoked = false
        com.example.service.QueenVoiceForegroundService.onStopRequested = {
            stopCallbackInvoked = true
        }

        val serviceController = org.robolectric.Robolectric.buildService(com.example.service.QueenVoiceForegroundService::class.java)
        val service = serviceController.create().get()

        val startIntent = android.content.Intent(context, com.example.service.QueenVoiceForegroundService::class.java).apply {
            action = com.example.service.QueenVoiceForegroundService.ACTION_START
        }
        service.onStartCommand(startIntent, 0, 1)
        assertTrue(com.example.service.QueenVoiceForegroundService.isServiceRunning)

        // Notification channel should exist
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            val channel = notificationManager.getNotificationChannel(com.example.service.QueenVoiceForegroundService.CHANNEL_ID)
            org.junit.Assert.assertNotNull(channel)
            assertEquals("Queen AI Voice Session", channel.name)
        }

        // Send STOP action
        val stopIntent = android.content.Intent(context, com.example.service.QueenVoiceForegroundService::class.java).apply {
            action = com.example.service.QueenVoiceForegroundService.ACTION_STOP
        }
        service.onStartCommand(stopIntent, 0, 2)
        assertFalse(com.example.service.QueenVoiceForegroundService.isServiceRunning)
        assertTrue(stopCallbackInvoked)

        serviceController.destroy()
    }

    @Test
    fun `test openBatteryOptimizationSettings launches settings intent`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val shadowApp = org.robolectric.Shadows.shadowOf(context as android.app.Application)

        com.example.ui.screens.openBatteryOptimizationSettings(context)
        val startedIntent = shadowApp.nextStartedActivity
        org.junit.Assert.assertNotNull(startedIntent)
        assertTrue(
            startedIntent.action == android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS ||
            startedIntent.action == android.provider.Settings.ACTION_SETTINGS ||
            startedIntent.action == android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        )
    }

    @Test
    fun `test AssistantCommand parse recognizes ReadScreen from explicit tag and natural speech queries`() {
        // Explicit tags
        val tagCmd = AssistantCommand.parse("[READ_SCREEN]")
        assertTrue(tagCmd is AssistantCommand.ReadScreen)

        // All 10 required prompt utterances
        assertTrue(AssistantCommand.parse("मैं अभी क्या देख रहा हूँ?") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("मैं किस पेज पर हूँ?") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("स्क्रीन पर क्या दिख रहा है?") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("इस वीडियो का नाम क्या है?") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("मैं कौन-सा वीडियो देख रहा हूँ?") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("What am I watching?") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("What page am I on?") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("What video is playing?") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("What is the title on my screen?") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("Read my screen.") is AssistantCommand.ReadScreen)

        // Common natural speech variations (prefixes, suffixes, alternate spellings, female gender)
        assertTrue(AssistantCommand.parse("रानी बताओ मैं अभी क्या देख रहा हूँ") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("रानी बताओ मैं अभी क्या देख रहा हूं") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("रानी मैं अभी क्या देख रही हूँ") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("रानी बताओ इस वीडियो का नाम क्या है") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("मैं कौन सा वीडियो देख रहा हूं") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("स्क्रीन पे क्या दिख रहा है") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("स्क्रीन पर क्या चल रहा है") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("वीडियो का नाम क्या है") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("वीडियो का टाइटल क्या है") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("Queen what am I watching right now?") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("Rani what page am I on?") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("Can you tell me what video is playing?") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("What's the title on my screen?") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("Please read my screen") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("what is on my screen") is AssistantCommand.ReadScreen)

        // Hinglish queries
        assertTrue(AssistantCommand.parse("main abhi kya dekh raha hoon") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("main abhi kya dekh raha hu") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("main kis page par hu") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("is video ka naam kya hai") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("screen padho") is AssistantCommand.ReadScreen)
        assertTrue(AssistantCommand.parse("screen read karo") is AssistantCommand.ReadScreen)

        // Negative test cases (must NOT match unrelated conversation)
        assertFalse(AssistantCommand.parse("What time is it?") is AssistantCommand.ReadScreen)
        assertFalse(AssistantCommand.parse("Who are you?") is AssistantCommand.ReadScreen)
        assertFalse(AssistantCommand.parse("Call Rahul") is AssistantCommand.ReadScreen)
        assertFalse(AssistantCommand.parse("Open YouTube") is AssistantCommand.ReadScreen)
        assertFalse(AssistantCommand.parse("I am watching a movie tomorrow") is AssistantCommand.ReadScreen)
        assertFalse(AssistantCommand.parse("Tell me about yourself") is AssistantCommand.ReadScreen)
    }

    @Test
    fun `test ViewTreeParser formats screen summary with prioritized visible text nodes`() {
        val parser = com.example.accessibility.ViewTreeParser()

        // Empty root returns message
        assertEquals("Screen is empty or not accessible.", parser.formatScreenSummary(null))

        // Root with empty children
        val emptyRoot = com.example.accessibility.model.ViewNode(
            className = "android.widget.FrameLayout",
            isVisibleToUser = true
        )
        assertEquals("No accessible text or interactive controls visible.", parser.formatScreenSummary(emptyRoot))

        // Root with YouTube video title
        val youtubeRoot = com.example.accessibility.model.ViewNode(
            className = "android.widget.FrameLayout",
            packageName = "com.google.android.youtube",
            isVisibleToUser = true,
            children = mutableListOf(
                com.example.accessibility.model.ViewNode(
                    id = "com.google.android.youtube:id/video_title",
                    text = "Learn Kotlin in 100 Seconds",
                    className = "android.widget.TextView",
                    packageName = "com.google.android.youtube",
                    isVisibleToUser = true
                ),
                com.example.accessibility.model.ViewNode(
                    id = "com.google.android.youtube:id/channel_name",
                    text = "Fireship",
                    className = "android.widget.TextView",
                    packageName = "com.google.android.youtube",
                    isVisibleToUser = true
                ),
                com.example.accessibility.model.ViewNode(
                    className = "android.widget.ImageView",
                    contentDescription = "Play video",
                    packageName = "com.google.android.youtube",
                    isClickable = true,
                    isVisibleToUser = true
                )
            )
        )

        val summary = parser.formatScreenSummary(youtubeRoot)
        assertTrue(summary.contains("YouTube"))
        assertTrue(summary.contains("Primary Title / Video Title: \"Learn Kotlin in 100 Seconds\""))
        assertTrue(summary.contains("Learn Kotlin in 100 Seconds"))
        assertTrue(summary.contains("Fireship"))
        assertTrue(summary.contains("Play video"))
    }

    @Test
    fun `test JarvisAccessibilityService is declared in manifest with BIND_ACCESSIBILITY_SERVICE permission`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val serviceComponent = android.content.ComponentName(context, com.example.service.JarvisAccessibilityService::class.java)
        val serviceInfo = context.packageManager.getServiceInfo(serviceComponent, android.content.pm.PackageManager.GET_SERVICES)
        org.junit.Assert.assertNotNull(serviceInfo)
        assertEquals("com.example.service.JarvisAccessibilityService", serviceInfo.name)
        assertEquals(android.Manifest.permission.BIND_ACCESSIBILITY_SERVICE, serviceInfo.permission)
        assertTrue("AccessibilityService must be exported=true for Android OS binding", serviceInfo.exported)
    }

    @Test
    fun `test ToolDispatcher readScreen returns SERVICE_NOT_CONNECTED when service is not running`() {
        val dispatcher = com.example.accessibility.ToolDispatcher()
        val result = dispatcher.readScreen()
        assertFalse(result.isSuccess)
        assertEquals(com.example.accessibility.model.ErrorCode.SERVICE_NOT_CONNECTED, result.errorCode)
        assertTrue(result.message.contains("Accessibility service is not running"))
    }

    @Test
    fun `test ActionExecutor readScreen validates error codes for service disconnected and empty screen`() {
        val actionExecutor = com.example.accessibility.ActionExecutor()

        // 1. Service disconnected
        val disconnectedResult = actionExecutor.readScreen()
        assertFalse(disconnectedResult.isSuccess)
        assertEquals(com.example.accessibility.model.ErrorCode.SERVICE_NOT_CONNECTED, disconnectedResult.errorCode)
        assertTrue(disconnectedResult.message.contains("Accessibility service is not running"))

        // 2. Mock service with empty screen (no readable text)
        val mockService = object : com.example.accessibility.OpenRingAccessibilityService() {}
        com.example.accessibility.OpenRingAccessibilityService.instance = mockService

        val emptyRootResult = actionExecutor.readScreen()
        assertFalse(emptyRootResult.isSuccess)
        // Without active window, returns ACTION_FAILED
        assertEquals(com.example.accessibility.model.ErrorCode.ACTION_FAILED, emptyRootResult.errorCode)

        // Reset singleton
        com.example.accessibility.OpenRingAccessibilityService.instance = null
    }

    @Test
    fun `test CommandExecutor processInput for ReadScreen produces ActionExecuted when screen reading succeeds`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val mockDispatcher = object : com.example.accessibility.ToolDispatcher() {
            override fun readScreen(): com.example.accessibility.model.ActionResult {
                val summary = "Current App: YouTube (com.google.android.youtube)\nPrimary Title / Video Title: \"Kotlin Coroutines Tutorial\"\n1. [Video Title] \"Kotlin Coroutines Tutorial\""
                return com.example.accessibility.model.ActionResult.success("Screen content retrieved.", summary)
            }
        }

        val executor = CommandExecutor(context, toolDispatcher = mockDispatcher)
        val result = executor.processInput("What video is playing?")
        assertTrue(result is ExecutionResult.ActionExecuted)
        val executed = result as ExecutionResult.ActionExecuted
        assertEquals("Read Screen", executed.actionName)
        assertTrue(executed.details?.contains("Kotlin Coroutines Tutorial") == true)
        assertTrue(executed.messageHi.contains("Kotlin Coroutines Tutorial"))
    }

    @Test
    fun `test CommandExecutor processInput for ReadScreen produces ActionFailed with clear Hindi guidance when service is disabled`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val mockDispatcher = object : com.example.accessibility.ToolDispatcher() {
            override fun readScreen(): com.example.accessibility.model.ActionResult {
                return com.example.accessibility.model.ActionResult.failure(
                    "Accessibility service is not running.",
                    com.example.accessibility.model.ErrorCode.SERVICE_NOT_CONNECTED
                )
            }
        }

        val executor = CommandExecutor(context, toolDispatcher = mockDispatcher)
        val result = executor.processInput("What am I watching?")
        assertTrue(result is ExecutionResult.ActionFailed)
        val failed = result as ExecutionResult.ActionFailed
        assertEquals("Read Screen", failed.actionName)
        assertTrue(failed.messageHi.contains("एक्सेसिबिलिटी सर्विस चालू नहीं है"))
    }
}


