package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.ConversationMessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationHistoryDao {

    @Query("SELECT * FROM conversation_history ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ConversationMessageEntity>>

    @Query("SELECT * FROM conversation_history ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentMessages(limit: Int): List<ConversationMessageEntity>

    @Query("SELECT * FROM conversation_history ORDER BY timestamp ASC")
    suspend fun getAllMessagesList(): List<ConversationMessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ConversationMessageEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(messages: List<ConversationMessageEntity>)

    @Query("DELETE FROM conversation_history")
    suspend fun clearAll(): Int

    @Query("SELECT COUNT(*) FROM conversation_history")
    suspend fun getCount(): Int
}
