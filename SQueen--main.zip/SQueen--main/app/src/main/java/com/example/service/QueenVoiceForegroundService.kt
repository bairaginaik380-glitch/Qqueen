package com.example.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R

/**
 * QueenVoiceForegroundService maintains an active voice session when Queen AI is backgrounded.
 *
 * Complies with Android 14+ (targetSdk 36) background execution restrictions:
 * - Declared with foregroundServiceType="microphone"
 * - Requires FOREGROUND_SERVICE_MICROPHONE and RECORD_AUDIO permissions
 * - Started strictly from user-visible, foreground interactions (e.g. user tapping start)
 * - Displays a persistent, truthful ongoing notification with a Stop button
 */
class QueenVoiceForegroundService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            Log.d(TAG, "Stop action requested via intent")
            stopVoiceService()
            return START_NOT_STICKY
        }

        // Verify RECORD_AUDIO permission before starting foreground microphone service
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "Cannot start microphone foreground service without RECORD_AUDIO permission")
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ServiceCompat.startForeground(
                    this,
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            isServiceRunning = true
            Log.d(TAG, "QueenVoiceForegroundService started successfully in foreground")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to startForeground: ${e.message}", e)
            stopSelf()
            return START_NOT_STICKY
        }

        return START_NOT_STICKY
    }

    private fun stopVoiceService() {
        isServiceRunning = false
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping foreground: ${e.message}")
        }
        try {
            onStopRequested?.invoke()
        } catch (e: Exception) {
            Log.w(TAG, "Error notifying stop callback: ${e.message}")
        }
        stopSelf()
    }

    override fun onDestroy() {
        isServiceRunning = false
        super.onDestroy()
        Log.d(TAG, "QueenVoiceForegroundService destroyed")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            val existing = manager.getNotificationChannel(CHANNEL_ID)
            if (existing == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Queen AI Voice Session",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Displays the status of the active Queen AI background voice session"
                    setShowBadge(false)
                }
                manager.createNotificationChannel(channel)
            }
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, QueenVoiceForegroundService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Queen AI Voice Session Active")
            .setContentText("Queen AI is listening and running in background")
            .setSubText("Voice Session")
            .setContentIntent(openAppPendingIntent)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Stop Session",
                stopPendingIntent
            )
            .build()
    }

    companion object {
        private const val TAG = "QueenVoiceService"
        const val ACTION_START = "com.example.action.START_VOICE_SESSION"
        const val ACTION_STOP = "com.example.action.STOP_VOICE_SESSION"
        const val NOTIFICATION_ID = 2001
        const val CHANNEL_ID = "queen_voice_session_channel"

        @Volatile
        var isServiceRunning: Boolean = false
            private set

        /**
         * Optional listener called when user taps "Stop Session" in notification
         */
        var onStopRequested: (() -> Unit)? = null

        fun start(context: Context) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                Log.w(TAG, "Cannot start QueenVoiceForegroundService: RECORD_AUDIO not granted")
                return
            }
            try {
                val intent = Intent(context, QueenVoiceForegroundService::class.java).apply {
                    action = ACTION_START
                }
                ContextCompat.startForegroundService(context, intent)
            } catch (e: Exception) {
                Log.e(TAG, "Could not start QueenVoiceForegroundService: ${e.message}", e)
            }
        }

        fun stop(context: Context) {
            try {
                val intent = Intent(context, QueenVoiceForegroundService::class.java).apply {
                    action = ACTION_STOP
                }
                context.startService(intent)
            } catch (e: Exception) {
                try {
                    context.stopService(Intent(context, QueenVoiceForegroundService::class.java))
                } catch (_: Exception) {}
            }
            isServiceRunning = false
        }
    }
}
