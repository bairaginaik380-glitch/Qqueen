/**
 * Queen AI — Firebase Cloud Functions Token Verification Service
 * Developed for Shyam Kadam
 *
 * Provides secure server-side validation and single-device registration
 * against Google Cloud Firestore.
 *
 * Deploy with:
 *   firebase deploy --only functions
 */

const functions = require('firebase-functions');
const admin = require('firebase-admin');
const crypto = require('crypto');

admin.initializeApp();
const db = admin.firestore();

// Collection holding hashed tokens
const TOKENS_COLLECTION = 'queen_access_tokens';

// Allowed format: Q followed by 9 unambiguous characters
const TOKEN_REGEX = /^Q[2-9A-HJ-NP-Z]{9}$/;

/**
 * HTTPS Callable or REST Function: verifyQueenToken
 * Accepts POST request with:
 *   Headers:
 *     Authorization: Bearer <QueenAppAccessToken>
 *     X-Device-Id: <DeviceId>
 *   Or JSON Body:
 *     { token: "Q...", deviceId: "queen_dev_..." }
 */
exports.verifyQueenToken = functions.https.onRequest(async (req, res) => {
  // CORS support
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Device-Id');
  if (req.method === 'OPTIONS') {
    return res.status(204).send('');
  }

  // 1. Extract token
  let token = '';
  const authHeader = req.headers['authorization'];
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.replace('Bearer ', '').trim().toUpperCase();
  } else if (req.body && req.body.token) {
    token = String(req.body.token).trim().toUpperCase();
  }

  // 2. Extract deviceId
  let deviceId = req.headers['x-device-id'] || (req.body && req.body.deviceId) || '';
  deviceId = String(deviceId).trim();

  if (!token) {
    return res.status(401).json({
      valid: false,
      message: 'Queen App Access Token is required.'
    });
  }

  if (!TOKEN_REGEX.test(token)) {
    return res.status(400).json({
      valid: false,
      message: 'Invalid Queen token format. Must be 10 characters starting with Q.'
    });
  }

  if (!deviceId) {
    return res.status(400).json({
      valid: false,
      message: 'Device identifier (X-Device-Id) is required for license validation.'
    });
  }

  // 3. Compute SHA-256 hash (never store or query plaintext tokens)
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const tokenRef = db.collection(TOKENS_COLLECTION).doc(tokenHash);

  try {
    const result = await db.runTransaction(async (transaction) => {
      const doc = await transaction.get(tokenRef);

      if (!doc.exists) {
        return { status: 401, body: { valid: false, message: 'Invalid or unrecognized Queen App Access Token.' } };
      }

      const data = doc.data();

      // Revocation check
      if (data.status === 'REVOKED') {
        return { status: 403, body: { valid: false, message: 'This access token has been revoked by the administrator.' } };
      }

      // Expiry check using server time
      const nowMs = Date.now();
      let isExpired = data.status === 'EXPIRED';
      const expiryField = data.expires_at || data.expiresAt;
      if (expiryField) {
        let expiryMs = null;
        if (typeof expiryField.toMillis === 'function') {
          expiryMs = expiryField.toMillis();
        } else if (typeof expiryField === 'number') {
          expiryMs = expiryField < 100000000000 ? expiryField * 1000 : expiryField;
        } else if (typeof expiryField === 'string') {
          expiryMs = Date.parse(expiryField);
        }
        if (expiryMs && !isNaN(expiryMs) && nowMs > expiryMs) {
          isExpired = true;
        }
      }

      if (isExpired) {
        return { status: 403, body: { valid: false, message: 'This access token has expired.' } };
      }

      // Single-device binding policy enforcement
      const existingDevice = data.bound_device_id;
      if (!existingDevice) {
        // First-time registration on this device
        transaction.update(tokenRef, {
          bound_device_id: deviceId,
          bound_at: admin.firestore.FieldValue.serverTimestamp(),
          last_used_at: admin.firestore.FieldValue.serverTimestamp(),
          usage_count: admin.firestore.FieldValue.increment(1)
        });
        return {
          status: 200,
          body: {
            valid: true,
            status: 'ACTIVE',
            message: 'Token registered successfully to this device.'
          }
        };
      }

      if (existingDevice === deviceId) {
        // Authorized device
        transaction.update(tokenRef, {
          last_used_at: admin.firestore.FieldValue.serverTimestamp(),
          usage_count: admin.firestore.FieldValue.increment(1)
        });
        return {
          status: 200,
          body: {
            valid: true,
            status: 'ACTIVE',
            message: 'Token authorized for this device.'
          }
        };
      }

      // Conflict: Token already bound to a different device
      return {
        status: 409,
        body: {
          valid: false,
          message: 'This token is already registered to another device. Single-device license policy enforced.'
        }
      };
    });

    return res.status(result.status).json(result.body);
  } catch (err) {
    console.error('Firestore transaction error:', err);
    return res.status(500).json({
      valid: false,
      message: 'Internal verification service error.'
    });
  }
});
