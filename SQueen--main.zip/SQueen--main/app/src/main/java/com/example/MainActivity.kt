package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.service.QueenVoiceForegroundService
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.ApiKeyScreen
import com.example.ui.screens.CameraVisionScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LearnMoreScreen
import com.example.ui.screens.PermissionsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StorageMemoryScreen
import com.example.ui.screens.UserNameScreen
import com.example.ui.screens.VoiceSelectionScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.QueenBackground
import com.example.ui.viewmodel.AarohiViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: AarohiViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = QueenBackground
                ) {
                    QueenAppNavHost(viewModel = viewModel, activity = this)
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // Allow active voice session to continue in the background using QueenVoiceForegroundService.
        // Only stop if neither the foreground service nor an active session is running.
        if (!QueenVoiceForegroundService.isServiceRunning && !viewModel.assistantState.value.isActive) {
            viewModel.stopSession()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) {
            // Stop voice session if MainActivity is explicitly finishing
            viewModel.stopSession()
        }
    }
}

object QueenDestinations {
    const val HOME = "home"
    const val SETTINGS = "settings"
    const val USER_NAME = "user_name"
    const val VOICE_SELECTION = "voice_selection"
    const val API_KEY = "api_key"
    const val PERMISSIONS = "permissions"
    const val STORAGE_MEMORY = "storage_memory"
    const val CAMERA_VISION = "camera_vision"
    const val ABOUT = "about"
    const val LEARN_MORE = "learn_more"
}

@Composable
fun QueenAppNavHost(
    viewModel: AarohiViewModel,
    activity: ComponentActivity
) {
    val navController = rememberNavController()

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startSession()
        } else {
            Toast.makeText(
                activity,
                "Microphone permission is required for voice conversation with Queen.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    var activeRequestedPermission by remember { mutableStateOf<String?>(null) }
    val dynamicPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        activeRequestedPermission?.let { perm ->
            viewModel.onPermissionResult(perm, isGranted)
        }
        activeRequestedPermission = null
    }

    LaunchedEffect(Unit) {
        viewModel.permissionRequestEvent.collect { permission ->
            val hasIt = ContextCompat.checkSelfPermission(activity, permission) == PackageManager.PERMISSION_GRANTED
            if (hasIt) {
                viewModel.onPermissionResult(permission, true)
            } else {
                activeRequestedPermission = permission
                dynamicPermissionLauncher.launch(permission)
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = QueenDestinations.HOME
    ) {
        composable(QueenDestinations.HOME) {
            HomeScreen(
                viewModel = viewModel,
                onNavigateToSettings = {
                    navController.navigate(QueenDestinations.SETTINGS)
                },
                onNavigateToApiKey = {
                    navController.navigate(QueenDestinations.API_KEY)
                },
                onNavigateToCameraVision = {
                    navController.navigate(QueenDestinations.CAMERA_VISION)
                },
                onRequestMicAndStart = {
                    val hasPermission = ContextCompat.checkSelfPermission(
                        activity,
                        Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED

                    if (!hasPermission) {
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    } else {
                        viewModel.startSession()
                    }
                }
            )
        }

        composable(QueenDestinations.CAMERA_VISION) {
            CameraVisionScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(QueenDestinations.SETTINGS) {
            SettingsScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToUserName = { navController.navigate(QueenDestinations.USER_NAME) },
                onNavigateToVoiceSelection = { navController.navigate(QueenDestinations.VOICE_SELECTION) },
                onNavigateToApiKey = { navController.navigate(QueenDestinations.API_KEY) },
                onNavigateToPermissions = { navController.navigate(QueenDestinations.PERMISSIONS) },
                onNavigateToStorageMemory = { navController.navigate(QueenDestinations.STORAGE_MEMORY) },
                onNavigateToAbout = { navController.navigate(QueenDestinations.ABOUT) },
                onNavigateToLearnMore = { navController.navigate(QueenDestinations.LEARN_MORE) }
            )
        }

        composable(QueenDestinations.PERMISSIONS) {
            PermissionsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(QueenDestinations.STORAGE_MEMORY) {
            StorageMemoryScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(QueenDestinations.USER_NAME) {
            UserNameScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(QueenDestinations.VOICE_SELECTION) {
            VoiceSelectionScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(QueenDestinations.API_KEY) {
            ApiKeyScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToLearnMore = { navController.navigate(QueenDestinations.LEARN_MORE) }
            )
        }

        composable(QueenDestinations.ABOUT) {
            AboutScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(QueenDestinations.LEARN_MORE) {
            LearnMoreScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
