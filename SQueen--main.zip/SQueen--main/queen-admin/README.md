# Queen AI — Token Administration & Firebase Verification Service

Created for Developer **Shyam Kadam**.

## 1. Overview
The Queen Android app enforces a dual-credential policy:
1. **Google AI Studio Gemini API Key**: Entered directly and persisted securely in the app via Android KeyStore (AES-256 GCM).
2. **Queen App Access Token**: 10-character cryptographically formatted token (`Q[2-9A-HJ-NP-Z]{9}`) validated by this Firebase backend.

## 2. Single-Device License Enforcement
Each Access Token can only be bound to **one unique device**:
- On initial verification, the server records the device ID (`bound_device_id`).
- Subsequent requests from the same device succeed.
- Any attempt to use the same token on a different device is rejected with HTTP 409:
  `"This token is already registered to another device. Single-device license policy enforced."`
- Revoked tokens (`status: "REVOKED"`) are rejected with HTTP 403.
- Plaintext tokens are **never** stored in Firestore; all records are identified by their SHA-256 hash.

## 3. Configuration & Environment Variables Required

### For the Android App:
Provide this variable in AI Studio Secrets panel or in `.env`:
- **`FIREBASE_AUTH_ENDPOINT`**: The HTTPS URL of your deployed verification endpoint (Cloud Function or self-hosted server).
  * Example Cloud Function: `https://us-central1-YOUR_PROJECT_ID.cloudfunctions.net/verifyQueenToken`
  * Example Standalone Server: `https://your-server.onrender.com/v1/token/verify`
  * (Optional) **`GEMINI_API_KEY`**: If injected via build environment. Users can also enter and update their API Key directly in the app's Settings -> API & Key screen.

### For the Firebase Project / Backend:
- **Firebase Project ID**: Your Firebase project identifier.
- **Firestore Database**: Firestore in Native mode.
- **Service Account / Admin SDK**: Automatically available inside Firebase Cloud Functions (no credential file needed). For standalone server or seeding scripts, use standard `GOOGLE_APPLICATION_CREDENTIALS`.

## 4. Hosting & Deployment Options (Spark Free vs. Blaze Plan)

> **IMPORTANT PLAN NOTICE:**
> Google Cloud / Firebase requires the **Blaze (Pay-as-you-go)** plan to deploy Firebase Cloud Functions.
> If your project is on the **Spark Free Plan**, Firebase will disallow `firebase deploy --only functions`.
> **Do not enable billing or change plans if you wish to stay on the free tier!**
> Queen provides two deployment options:

### Option A: Spark Free Plan Friendly (Zero Billing Required)
Deploy the included **`queen-admin/server.js`** Node.js server on any free hosting platform (e.g., Render, Railway, Fly.io, or your local machine / VPS):
1. Install dependencies:
   ```bash
   cd queen-admin
   npm install express
   ```
2. Start the server with `GOOGLE_APPLICATION_CREDENTIALS` pointing to your Firebase Service Account JSON (or run standalone using the local `tokens_registry.json`):
   ```bash
   node server.js
   ```
3. Set `FIREBASE_AUTH_ENDPOINT` in the Android app to: `https://<YOUR_DEPLOYED_URL>/v1/token/verify`

### Option B: Firebase Cloud Functions (Requires Blaze Plan with Free Quota)
If your Firebase project has the Blaze plan enabled:
1. Deploy Firestore Security Rules:
   ```bash
   firebase deploy --only firestore:rules
   ```
2. Seed the 100 Initial Hashed Tokens into Firestore:
   ```bash
   GOOGLE_APPLICATION_CREDENTIALS=path/to/serviceAccountKey.json node queen-admin/seed_firestore.js
   ```
3. Deploy the Cloud Function:
   ```bash
   cd queen-admin/firebase_functions
   npm install
   firebase deploy --only functions:verifyQueenToken
   ```
4. Set `FIREBASE_AUTH_ENDPOINT` in the Android app to:
   `https://<REGION>-<PROJECT_ID>.cloudfunctions.net/verifyQueenToken`
