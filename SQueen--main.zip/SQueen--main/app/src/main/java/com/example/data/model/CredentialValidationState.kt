package com.example.data.model

sealed interface CredentialValidationState {
    data object Unchecked : CredentialValidationState
    data object Validating : CredentialValidationState
    data object Valid : CredentialValidationState
    data class Invalid(val message: String) : CredentialValidationState

    val isValid: Boolean get() = this is Valid
}
