#!/usr/bin/env node
/**
 * Queen AI — Seed Firestore Registry Script
 * Developed for Shyam Kadam
 *
 * Populates your Firebase Firestore `queen_access_tokens` collection
 * using the hashed records from `tokens_registry.json`.
 *
 * Usage:
 *   GOOGLE_APPLICATION_CREDENTIALS=path/to/serviceAccountKey.json node seed_firestore.js
 */

const admin = require('firebase-admin');
const fs = require('fs');
const path = require('path');

const registryPath = path.join(__dirname, 'tokens_registry.json');
if (!fs.existsSync(registryPath)) {
  console.error('Error: tokens_registry.json not found!');
  process.exit(1);
}

const registry = JSON.parse(fs.readFileSync(registryPath, 'utf8'));

// Initialize Firebase Admin with ambient credentials
admin.initializeApp();
const db = admin.firestore();
const TOKENS_COLLECTION = 'queen_access_tokens';

async function seed() {
  console.log(`Starting Firestore import of ${registry.records.length} hashed tokens...`);
  const batchSize = 100;
  let batch = db.batch();
  let count = 0;

  for (const record of registry.records) {
    const docRef = db.collection(TOKENS_COLLECTION).doc(record.sha256_hash);
    batch.set(docRef, {
      id: record.id,
      token_prefix: record.token_prefix,
      sha256_hash: record.sha256_hash,
      status: record.status || 'ACTIVE',
      expires_at: record.expires_at ? admin.firestore.Timestamp.fromMillis(record.expires_at * 1000) : null,
      bound_device_id: null,
      bound_at: null,
      created_at: admin.firestore.Timestamp.fromMillis((record.created_at || Date.now() / 1000) * 1000),
      last_used_at: null,
      usage_count: 0
    }, { merge: true });

    count++;
    if (count % batchSize === 0) {
      await batch.commit();
      console.log(`Committed ${count} records.`);
      batch = db.batch();
    }
  }

  if (count % batchSize !== 0) {
    await batch.commit();
  }

  console.log(`Successfully seeded all ${count} hashed Queen tokens into Firestore collection '${TOKENS_COLLECTION}'!`);
}

seed().catch(err => {
  console.error('Firestore seeding failed:', err);
  process.exit(1);
});
