package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.ConversationMessageEntity
import com.example.data.model.ImportantMemoryEntity

@Database(
    entities = [
        ConversationMessageEntity::class,
        ImportantMemoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class QueenDatabase : RoomDatabase() {

    abstract fun conversationHistoryDao(): ConversationHistoryDao
    abstract fun importantMemoryDao(): ImportantMemoryDao

    companion object {
        const val DATABASE_NAME = "queen_memory.db"

        @Volatile
        private var INSTANCE: QueenDatabase? = null

        fun getInstance(context: Context): QueenDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    QueenDatabase::class.java,
                    DATABASE_NAME
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
