package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.AssistantState
import com.example.ui.theme.QueenBorderGold
import com.example.ui.theme.QueenError
import com.example.ui.theme.QueenGold
import com.example.ui.theme.QueenGoldBright
import com.example.ui.theme.QueenGoldGlow
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun StarPlayButton(
    assistantState: AssistantState,
    amplitude: Float,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val isRotating = assistantState is AssistantState.Connecting ||
            assistantState is AssistantState.Listening ||
            assistantState is AssistantState.Speaking ||
            assistantState is AssistantState.Reconnecting

    val infiniteTransition = rememberInfiniteTransition(label = "star_rotation")

    // Smooth, slow, restrained rotation (14s per revolution)
    val rotationAngle by if (isRotating) {
        infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = tween(14000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "rotation"
        )
    } else {
        remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
    }

    val primaryGold = when (assistantState) {
        is AssistantState.Error -> QueenError
        else -> QueenGold
    }

    val glowColor = when (assistantState) {
        is AssistantState.Error -> QueenError.copy(alpha = 0.35f)
        is AssistantState.Speaking -> QueenGoldBright.copy(alpha = 0.35f + amplitude * 0.3f)
        is AssistantState.Listening -> QueenGold.copy(alpha = 0.3f + amplitude * 0.3f)
        else -> QueenGoldGlow
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(84.dp)
            .shadow(
                elevation = if (assistantState.isActive) 16.dp else 8.dp,
                shape = CircleShape,
                spotColor = primaryGold
            )
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF634D1C),
                        Color(0xFF3B2D0E),
                        Color(0xFF201807),
                        Color(0xFF100C03)
                    )
                )
            )
            .border(2.dp, QueenGold, CircleShape)
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("star_play_button")
    ) {
        // Rotating Star Outline
        Canvas(
            modifier = Modifier
                .size(62.dp)
                .rotate(rotationAngle)
        ) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val outerRadius = size.width * 0.46f
            val innerRadius = size.width * 0.22f
            val points = 8 // Elegant 8-pointed star emblem
            val angleStep = (2 * PI / points).toFloat()

            val starPath = Path()
            for (i in 0 until points) {
                // Outer tip
                val outerAngle = i * angleStep - (PI / 2).toFloat()
                val x1 = center.x + outerRadius * cos(outerAngle)
                val y1 = center.y + outerRadius * sin(outerAngle)

                // Inner corner
                val innerAngle = outerAngle + angleStep / 2f
                val x2 = center.x + innerRadius * cos(innerAngle)
                val y2 = center.y + innerRadius * sin(innerAngle)

                if (i == 0) {
                    starPath.moveTo(x1, y1)
                } else {
                    starPath.lineTo(x1, y1)
                }
                starPath.lineTo(x2, y2)
            }
            starPath.close()

            // Subtle outer glow
            drawPath(
                path = starPath,
                color = glowColor,
                style = Stroke(
                    width = 4.5f,
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )

            // Crisp metallic gold star line
            drawPath(
                path = starPath,
                color = primaryGold,
                style = Stroke(
                    width = 1.6f,
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )
        }

        // Center Play / Stop Indicator
        Canvas(modifier = Modifier.size(22.dp)) {
            val center = Offset(size.width / 2f, size.height / 2f)

            if (assistantState.isActive) {
                // Sleek golden stop square
                val side = size.width * 0.44f
                val left = center.x - side / 2f
                val top = center.y - side / 2f
                drawRect(
                    color = QueenGoldBright,
                    topLeft = Offset(left, top),
                    size = androidx.compose.ui.geometry.Size(side, side)
                )
            } else {
                // Elegant golden Play triangle
                val trianglePath = Path().apply {
                    val halfHeight = size.height * 0.35f
                    val halfWidth = size.width * 0.32f
                    moveTo(center.x - halfWidth * 0.7f, center.y - halfHeight)
                    lineTo(center.x + halfWidth * 1.0f, center.y)
                    lineTo(center.x - halfWidth * 0.7f, center.y + halfHeight)
                    close()
                }
                drawPath(
                    path = trianglePath,
                    color = primaryGold
                )
            }
        }
    }
}
