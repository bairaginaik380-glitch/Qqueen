package com.example.ui.screens

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.TextUtils
import android.view.accessibility.AccessibilityManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationManagerCompat
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.theme.QueenBackground
import com.example.ui.theme.QueenBorder
import com.example.ui.theme.QueenBorderGold
import com.example.ui.theme.QueenError
import com.example.ui.theme.QueenGold
import com.example.ui.theme.QueenGoldBright
import com.example.ui.theme.QueenGoldSoft
import com.example.ui.theme.QueenSuccess
import com.example.ui.theme.QueenSurface
import com.example.ui.theme.QueenSurfaceVariant
import com.example.ui.theme.QueenTextMuted
import com.example.ui.theme.QueenTextPrimary
import com.example.ui.theme.QueenTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionsScreen(
    onNavigateBack: () -> Unit
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var isMicGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    var isCameraGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    var isAccessibilityEnabled by remember {
        mutableStateOf(checkAccessibilityServiceEnabled(context))
    }

    var isContactsGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_CONTACTS
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    var isPhoneCallsGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CALL_PHONE
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    var isNotificationsGranted by remember {
        mutableStateOf(checkNotificationsEnabled(context))
    }

    val refreshStatuses = {
        isMicGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        isCameraGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        isAccessibilityEnabled = checkAccessibilityServiceEnabled(context)

        isContactsGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED

        isPhoneCallsGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        isNotificationsGranted = checkNotificationsEnabled(context)
    }

    // Refresh automatically whenever the user returns from system settings or dialogs
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                refreshStatuses()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Permission launchers
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        isMicGranted = isGranted
        refreshStatuses()
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        isCameraGranted = isGranted
        refreshStatuses()
    }

    val contactsPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        isContactsGranted = isGranted
        refreshStatuses()
    }

    val phoneCallsPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        isPhoneCallsGranted = isGranted
        refreshStatuses()
    }

    val notificationsPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        isNotificationsGranted = isGranted
        refreshStatuses()
    }

    Scaffold(
        containerColor = QueenBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Permissions",
                        fontWeight = FontWeight.Bold,
                        color = QueenTextPrimary,
                        fontSize = 20.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("permissions_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = QueenTextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = QueenBackground
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header summary card
            Surface(
                color = QueenSurfaceVariant,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, QueenBorderGold),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Surface(
                        color = QueenGold.copy(alpha = 0.15f),
                        shape = CircleShape,
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = QueenGold,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Access & Privacy Controls",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = QueenGoldBright
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Queen AI uses device permissions strictly when needed for live features. You have complete control to grant or revoke access anytime.",
                            fontSize = 12.sp,
                            color = QueenTextSecondary,
                            lineHeight = 17.sp
                        )
                    }
                }
            }

            Text(
                text = "ACTIVE PERMISSIONS & ACCESS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = QueenGoldSoft,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(top = 4.dp)
            )

            // 1. Microphone Row (RECORD_AUDIO)
            PermissionItemCard(
                icon = Icons.Default.Mic,
                title = "Microphone",
                explanation = "Required for continuous real-time spoken conversation with Queen in Gemini Live audio sessions.",
                statusText = if (isMicGranted) "Granted" else "Not granted",
                isGranted = isMicGranted,
                actionButtonText = if (isMicGranted) "Open App Settings" else "Grant Permission",
                testTag = "permission_item_microphone",
                actionTestTag = if (isMicGranted) "manage_mic_permission_button" else "grant_mic_permission_button",
                onActionClick = {
                    if (isMicGranted) {
                        openAppSettings(context)
                    } else {
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                }
            )

            // 2. Camera Row (CAMERA)
            PermissionItemCard(
                icon = Icons.Default.CameraAlt,
                title = "Camera",
                explanation = "Required by Camera Vision to capture live environment frames and analyze visual queries with Queen.",
                statusText = if (isCameraGranted) "Granted" else "Not granted",
                isGranted = isCameraGranted,
                actionButtonText = if (isCameraGranted) "Open App Settings" else "Grant Permission",
                testTag = "permission_item_camera",
                actionTestTag = if (isCameraGranted) "manage_camera_permission_button" else "grant_camera_permission_button",
                onActionClick = {
                    if (isCameraGranted) {
                        openAppSettings(context)
                    } else {
                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                }
            )

            // 3. Accessibility Service (Special Access)
            PermissionItemCard(
                icon = Icons.Default.AccessibilityNew,
                title = "Accessibility Service",
                explanation = "Special system access for device navigation. Queen AI cannot enable this automatically; you must manually toggle it in Android Accessibility Settings.",
                statusText = if (isAccessibilityEnabled) "Enabled" else "Disabled",
                isGranted = isAccessibilityEnabled,
                actionButtonText = "Open Accessibility Settings",
                testTag = "permission_item_accessibility",
                actionTestTag = "open_accessibility_settings_button",
                onActionClick = {
                    openAccessibilitySettings(context)
                }
            )

            // 4. Contacts Row (READ_CONTACTS)
            PermissionItemCard(
                icon = Icons.Default.Contacts,
                title = "Contacts",
                explanation = "Required to search and match contact names from your phone when you request Queen AI to place a call.",
                statusText = if (isContactsGranted) "Granted" else "Not granted",
                isGranted = isContactsGranted,
                actionButtonText = if (isContactsGranted) "Open App Settings" else "Grant Permission",
                testTag = "permission_item_contacts",
                actionTestTag = if (isContactsGranted) "manage_contacts_permission_button" else "grant_contacts_permission_button",
                onActionClick = {
                    if (isContactsGranted) {
                        openAppSettings(context)
                    } else {
                        contactsPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
                    }
                }
            )

            // 5. Phone Calls Row (CALL_PHONE)
            PermissionItemCard(
                icon = Icons.Default.Call,
                title = "Phone Calls",
                explanation = "Required to place direct outgoing phone calls after you verbally confirm a call request with Queen AI.",
                statusText = if (isPhoneCallsGranted) "Granted" else "Not granted",
                isGranted = isPhoneCallsGranted,
                actionButtonText = if (isPhoneCallsGranted) "Open App Settings" else "Grant Permission",
                testTag = "permission_item_calls",
                actionTestTag = if (isPhoneCallsGranted) "manage_calls_permission_button" else "grant_calls_permission_button",
                onActionClick = {
                    if (isPhoneCallsGranted) {
                        openAppSettings(context)
                    } else {
                        phoneCallsPermissionLauncher.launch(Manifest.permission.CALL_PHONE)
                    }
                }
            )

            // 6. Notifications Row (POST_NOTIFICATIONS on Android 13+)
            val isTiramisuOrHigher = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
            PermissionItemCard(
                icon = Icons.Default.Notifications,
                title = "Notifications",
                explanation = if (isTiramisuOrHigher) {
                    "Allows Queen AI to deliver timely background alerts, reminders, and updates. Required on Android 13+."
                } else {
                    "Allows Queen AI to deliver timely background alerts, reminders, and updates."
                },
                statusText = if (isNotificationsGranted) {
                    if (isTiramisuOrHigher) "Granted" else "Enabled"
                } else {
                    if (isTiramisuOrHigher) "Not granted" else "Disabled"
                },
                isGranted = isNotificationsGranted,
                actionButtonText = when {
                    !isNotificationsGranted && isTiramisuOrHigher -> "Grant Permission"
                    else -> "Open Notification Settings"
                },
                testTag = "permission_item_notifications",
                actionTestTag = if (isNotificationsGranted) "manage_notifications_permission_button" else "grant_notifications_permission_button",
                onActionClick = {
                    if (!isNotificationsGranted && isTiramisuOrHigher) {
                        notificationsPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        openNotificationSettings(context)
                    }
                }
            )

            // 7. Background Voice Operation & Battery Optimization
            PermissionItemCard(
                icon = Icons.Default.BatteryChargingFull,
                title = "Background Voice & Battery",
                explanation = "Queen AI maintains active conversations when backgrounded using a foreground voice service with a persistent notification. On devices with aggressive battery savers (e.g. Samsung, Xiaomi, OnePlus), setting battery usage to Unrestricted helps prevent premature termination of ongoing conversations.",
                statusText = "Managed by Android OS",
                isGranted = true,
                actionButtonText = "Open Battery Settings",
                testTag = "permission_item_battery",
                actionTestTag = "manage_battery_settings_button",
                onActionClick = {
                    openBatteryOptimizationSettings(context)
                }
            )

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun PermissionItemCard(
    icon: ImageVector,
    title: String,
    explanation: String,
    statusText: String,
    isGranted: Boolean,
    actionButtonText: String,
    testTag: String,
    actionTestTag: String,
    onActionClick: () -> Unit
) {
    Surface(
        color = QueenSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, if (isGranted) QueenBorderGold else QueenBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        color = QueenSurfaceVariant,
                        shape = CircleShape,
                        border = BorderStroke(1.dp, QueenBorderGold),
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = QueenGoldSoft,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Text(
                        text = title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = QueenTextPrimary
                    )
                }

                // Status Badge with dot indicator
                val badgeColor = if (isGranted) QueenSuccess else QueenError
                Surface(
                    color = badgeColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Surface(
                            color = badgeColor,
                            shape = CircleShape,
                            modifier = Modifier.size(6.dp)
                        ) {}
                        Text(
                            text = statusText,
                            color = badgeColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Text(
                text = explanation,
                fontSize = 13.sp,
                color = QueenTextSecondary,
                lineHeight = 18.sp
            )

            // Action Button
            if (isGranted) {
                OutlinedButton(
                    onClick = onActionClick,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, QueenBorderGold),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag(actionTestTag)
                ) {
                    Text(
                        text = actionButtonText,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = QueenGoldSoft
                    )
                }
            } else {
                Button(
                    onClick = onActionClick,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = QueenGold,
                        contentColor = Color.Black
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag(actionTestTag)
                ) {
                    Text(
                        text = actionButtonText,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun UnimplementedPermissionCard(
    icon: ImageVector,
    title: String,
    explanation: String,
    statusText: String,
    testTag: String
) {
    Surface(
        color = QueenSurface.copy(alpha = 0.6f),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, QueenBorder.copy(alpha = 0.6f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        color = QueenSurfaceVariant.copy(alpha = 0.5f),
                        shape = CircleShape,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = QueenTextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Text(
                        text = title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = QueenTextSecondary
                    )
                }

                Surface(
                    color = Color.White.copy(alpha = 0.05f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f))
                ) {
                    Text(
                        text = statusText,
                        color = QueenTextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Text(
                text = explanation,
                fontSize = 12.sp,
                color = QueenTextMuted,
                lineHeight = 17.sp
            )
        }
    }
}

/**
 * Checks whether an Accessibility Service registered by Queen AI's package is currently enabled in system settings.
 */
internal fun checkAccessibilityServiceEnabled(context: Context): Boolean {
    if (com.example.service.JarvisAccessibilityService.isServiceRunning) return true
    return try {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager ?: return false

        // 1. Check via Settings.Secure ENABLED_ACCESSIBILITY_SERVICES string
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )
        if (!enabledServices.isNullOrBlank()) {
            val colonSplitter = TextUtils.SimpleStringSplitter(':')
            colonSplitter.setString(enabledServices)
            val targetClass = "com.example.service.JarvisAccessibilityService"
            while (colonSplitter.hasNext()) {
                val componentName = colonSplitter.next()
                if (componentName.contains(context.packageName, ignoreCase = true) ||
                    componentName.contains(targetClass, ignoreCase = true) ||
                    componentName.contains("com.example", ignoreCase = true)
                ) {
                    return true
                }
            }
        }

        // 2. Check via AccessibilityManager enabled list
        val enabledList = am.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        for (info in enabledList) {
            val serviceInfo = info.resolveInfo?.serviceInfo
            val pkg = serviceInfo?.packageName
            val cls = serviceInfo?.name
            if (pkg != null && (pkg.equals(context.packageName, ignoreCase = true) || pkg.contains("com.example", ignoreCase = true))) {
                return true
            }
            if (cls != null && cls.contains("JarvisAccessibilityService", ignoreCase = true)) {
                return true
            }
        }

        false
    } catch (e: Exception) {
        false
    }
}

/**
 * Opens system application details settings page so the user can review or manage granted permissions.
 */
internal fun openAppSettings(context: Context) {
    try {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", context.packageName, null)
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        // Fallback to general settings
        try {
            val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(fallback)
        } catch (_: Exception) {}
    }
}

/**
 * Opens system Accessibility settings so the user can manually enable or disable accessibility services.
 */
internal fun openAccessibilitySettings(context: Context) {
    try {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        // Fallback to general settings
        try {
            val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(fallback)
        } catch (_: Exception) {}
    }
}

/**
 * Opens system notification settings specifically for this app.
 */
internal fun openNotificationSettings(context: Context) {
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } else {
            openAppSettings(context)
        }
    } catch (e: Exception) {
        openAppSettings(context)
    }
}

/**
 * Checks whether notifications are enabled for the app.
 */
internal fun checkNotificationsEnabled(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    } else {
        NotificationManagerCompat.from(context).areNotificationsEnabled()
    }
}

/**
 * Opens system battery optimization settings so the user can optionally exempt Queen AI.
 */
internal fun openBatteryOptimizationSettings(context: Context) {
    try {
        val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (_: Exception) {
        openAppSettings(context)
    }
}


