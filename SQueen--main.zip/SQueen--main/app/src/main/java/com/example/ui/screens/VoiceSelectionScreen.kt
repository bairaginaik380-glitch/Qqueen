package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AssistantState
import com.example.data.model.VoiceOption
import com.example.ui.theme.QueenBackground
import com.example.ui.theme.QueenBorder
import com.example.ui.theme.QueenBorderGold
import com.example.ui.theme.QueenGold
import com.example.ui.theme.QueenGoldBright
import com.example.ui.theme.QueenGoldSoft
import com.example.ui.theme.QueenSurface
import com.example.ui.theme.QueenSurfaceVariant
import com.example.ui.theme.QueenTextMuted
import com.example.ui.theme.QueenTextPrimary
import com.example.ui.theme.QueenTextSecondary
import com.example.ui.viewmodel.AarohiViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceSelectionScreen(
    viewModel: AarohiViewModel,
    onNavigateBack: () -> Unit
) {
    val currentSavedVoiceId by viewModel.selectedVoiceId.collectAsState()
    var selectedId by remember(currentSavedVoiceId) { mutableStateOf(currentSavedVoiceId) }
    val assistantState by viewModel.assistantState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(assistantState) {
        if (assistantState is AssistantState.Error) {
            snackbarHostState.showSnackbar((assistantState as AssistantState.Error).message)
        }
    }

    Scaffold(
        containerColor = QueenBackground,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Select Voice",
                        fontWeight = FontWeight.Bold,
                        color = QueenTextPrimary,
                        fontSize = 20.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("voice_selection_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = QueenTextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = QueenBackground
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Text(
                text = "Choose Queen's Speaking Voice",
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = QueenTextPrimary
            )

            Text(
                text = "These 4 verified voice tones are natively supported by the Gemini Live engine for real-time conversation.",
                fontSize = 14.sp,
                color = QueenTextSecondary,
                lineHeight = 20.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(VoiceOption.ALL_VOICES) { voice ->
                    val isSelected = (voice.id == selectedId)

                    Surface(
                        color = if (isSelected) QueenSurfaceVariant else QueenSurface,
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            if (isSelected) 1.5.dp else 1.dp,
                            if (isSelected) QueenBorderGold else QueenBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { selectedId = voice.id }
                            .testTag("voice_option_${voice.id.lowercase()}")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isSelected) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                                        contentDescription = null,
                                        tint = if (isSelected) QueenGold else QueenTextMuted,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = voice.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = if (isSelected) QueenGoldBright else QueenTextPrimary
                                    )
                                }

                                if (isSelected) {
                                    Surface(
                                        color = QueenGold.copy(alpha = 0.18f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "Selected",
                                            color = QueenGold,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }
                            }

                            Text(
                                text = voice.description,
                                fontSize = 13.sp,
                                color = QueenTextMuted,
                                modifier = Modifier.padding(start = 30.dp, top = 4.dp, bottom = 8.dp)
                            )

                            OutlinedButton(
                                onClick = {
                                    viewModel.previewVoice(voice.id)
                                },
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorderGold),
                                modifier = Modifier
                                    .padding(start = 30.dp)
                                    .testTag("preview_voice_${voice.id.lowercase()}")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = null,
                                    tint = QueenGoldSoft,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.size(6.dp))
                                Text(
                                    text = "Preview Voice",
                                    fontSize = 12.sp,
                                    color = QueenGoldSoft
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {
                    viewModel.selectVoice(selectedId)
                    scope.launch {
                        snackbarHostState.showSnackbar("Voice updated to $selectedId!")
                    }
                },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = QueenGold,
                    contentColor = Color.Black
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_voice_selection_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Text(
                    text = "Save Voice Selection",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
    }
}
