package com.example.command

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.ContextCompat

import com.example.accessibility.ToolDispatcher
import com.example.accessibility.model.ErrorCode

data class PendingCall(
    val contactName: String,
    val phoneNumber: String
)

sealed class ExecutionResult {
    data class ConfirmationRequested(
        val contactName: String,
        val phoneNumber: String,
        val promptMessageEn: String,
        val promptMessageHi: String
    ) : ExecutionResult()

    data class CallInitiated(
        val contactName: String,
        val phoneNumber: String,
        val messageEn: String,
        val messageHi: String
    ) : ExecutionResult()

    data class CallCancelled(
        val messageEn: String,
        val messageHi: String
    ) : ExecutionResult()

    data class ContactNotFound(
        val query: String,
        val messageEn: String,
        val messageHi: String
    ) : ExecutionResult()

    data class AmbiguousContacts(
        val query: String,
        val matches: List<ContactMatch>,
        val messageEn: String,
        val messageHi: String
    ) : ExecutionResult()

    data class PermissionRequired(
        val permission: String,
        val messageEn: String,
        val messageHi: String
    ) : ExecutionResult()

    data class ActionExecuted(
        val actionName: String,
        val messageEn: String,
        val messageHi: String,
        val details: String? = null
    ) : ExecutionResult()

    data class ActionFailed(
        val actionName: String,
        val reason: String,
        val messageEn: String,
        val messageHi: String
    ) : ExecutionResult()

    data class Error(val message: String) : ExecutionResult()

    object Ignored : ExecutionResult()
}

class CommandExecutor(
    private val context: Context,
    private val contactsHelper: ContactsHelper = ContactsHelper(),
    private val toolDispatcher: ToolDispatcher = ToolDispatcher()
) {
    @Volatile
    private var pendingCall: PendingCall? = null

    fun hasPendingCall(): Boolean = pendingCall != null

    fun getPendingCall(): PendingCall? = pendingCall

    fun clearPendingCall() {
        pendingCall = null
    }

    fun hasCallPhonePermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasContactsPermission(): Boolean {
        return contactsHelper.hasContactsPermission(context)
    }

    /**
     * Processes user speech or text input.
     * Evaluates call commands, handles confirmation if a call is pending,
     * dispatches accessibility & app actions, and performs real contact lookup.
     */
    fun processInput(input: String): ExecutionResult {
        val isPending = hasPendingCall()
        val command = AssistantCommand.parse(input, isPendingConfirmation = isPending)

        return when (command) {
            is AssistantCommand.ConfirmCall -> {
                if (isPending) {
                    if (command.confirmed) {
                        confirmAndExecuteCall()
                    } else {
                        cancelCall()
                    }
                } else {
                    ExecutionResult.Ignored
                }
            }
            is AssistantCommand.CallContact -> {
                // If a previous call was pending, clear it and start the new call request
                pendingCall = null
                initiateContactLookup(command.contactName)
            }
            is AssistantCommand.OpenApp -> {
                val res = toolDispatcher.openApp(context, command.appName)
                if (res.isSuccess) {
                    ExecutionResult.ActionExecuted(
                        actionName = "Open ${command.appName}",
                        messageEn = res.message,
                        messageHi = "${command.appName} खोल दिया।"
                    )
                } else {
                    ExecutionResult.ActionFailed(
                        actionName = "Open ${command.appName}",
                        reason = res.message,
                        messageEn = "Could not open ${command.appName}: ${res.message}",
                        messageHi = "${command.appName} नहीं खोला जा सका: ${res.message}"
                    )
                }
            }
            is AssistantCommand.ClickElement -> {
                val res = toolDispatcher.click(command.target)
                if (res.isSuccess) {
                    ExecutionResult.ActionExecuted(
                        actionName = "Click ${command.target}",
                        messageEn = res.message,
                        messageHi = "'${command.target}' पर क्लिक कर दिया।"
                    )
                } else {
                    ExecutionResult.ActionFailed(
                        actionName = "Click ${command.target}",
                        reason = res.message,
                        messageEn = res.message,
                        messageHi = "'${command.target}' पर क्लिक नहीं हो सका: ${res.message}"
                    )
                }
            }
            is AssistantCommand.TypeText -> {
                val res = toolDispatcher.typeText(command.text, command.target)
                if (res.isSuccess) {
                    ExecutionResult.ActionExecuted(
                        actionName = "Type text",
                        messageEn = res.message,
                        messageHi = "'${command.text}' लिख दिया।"
                    )
                } else {
                    ExecutionResult.ActionFailed(
                        actionName = "Type text",
                        reason = res.message,
                        messageEn = res.message,
                        messageHi = "टेक्स्ट नहीं लिखा जा सका: ${res.message}"
                    )
                }
            }
            is AssistantCommand.ScrollScreen -> {
                val res = toolDispatcher.scroll(command.direction)
                if (res.isSuccess) {
                    ExecutionResult.ActionExecuted(
                        actionName = "Scroll ${command.direction}",
                        messageEn = res.message,
                        messageHi = "स्क्रीन स्क्रॉल कर दी।"
                    )
                } else {
                    ExecutionResult.ActionFailed(
                        actionName = "Scroll",
                        reason = res.message,
                        messageEn = res.message,
                        messageHi = "स्क्रीन स्क्रॉल नहीं हो सकी: ${res.message}"
                    )
                }
            }
            is AssistantCommand.GoBack -> {
                val res = toolDispatcher.goBack()
                if (res.isSuccess) {
                    ExecutionResult.ActionExecuted(
                        actionName = "Go Back",
                        messageEn = "Navigated back.",
                        messageHi = "पीछे आ गई।"
                    )
                } else {
                    ExecutionResult.ActionFailed(
                        actionName = "Go Back",
                        reason = res.message,
                        messageEn = res.message,
                        messageHi = "वापस नहीं जा सकी: ${res.message}"
                    )
                }
            }
            is AssistantCommand.GoHome -> {
                val res = toolDispatcher.goHome()
                if (res.isSuccess) {
                    ExecutionResult.ActionExecuted(
                        actionName = "Go Home",
                        messageEn = "Returned to Home screen.",
                        messageHi = "होम स्क्रीन पर आ गई।"
                    )
                } else {
                    ExecutionResult.ActionFailed(
                        actionName = "Go Home",
                        reason = res.message,
                        messageEn = res.message,
                        messageHi = "होम स्क्रीन पर नहीं जा सकी: ${res.message}"
                    )
                }
            }
            is AssistantCommand.ReadScreen -> {
                val res = toolDispatcher.readScreen()
                android.util.Log.d(
                    "CommandExecutor",
                    "ReadScreen command executed: isSuccess=${res.isSuccess}, errorCode=${res.errorCode}"
                )
                if (res.isSuccess) {
                    val summary = res.data?.toString() ?: res.message
                    ExecutionResult.ActionExecuted(
                        actionName = "Read Screen",
                        messageEn = "Screen content:\n$summary",
                        messageHi = "स्क्रीन पर यह दिख रहा है:\n$summary",
                        details = summary
                    )
                } else {
                    val messageHi = when (res.errorCode) {
                        ErrorCode.SERVICE_NOT_CONNECTED ->
                            "Queen AI की एक्सेसिबिलिटी सर्विस चालू नहीं है। कृपया सेटिंग्स में जाकर एक्सेसिबिलिटी चालू करें।"
                        ErrorCode.NODE_NOT_FOUND ->
                            "स्क्रीन पर कोई पढ़ने योग्य टेक्स्ट या टाइटल नहीं मिला।"
                        else ->
                            "स्क्रीन नहीं पढ़ी जा सकी: ${res.message}"
                    }
                    ExecutionResult.ActionFailed(
                        actionName = "Read Screen",
                        reason = res.message,
                        messageEn = res.message,
                        messageHi = messageHi
                    )
                }
            }
            AssistantCommand.None -> {
                ExecutionResult.Ignored
            }
        }
    }

    /**
     * Looks up the contact by name.
     * If exactly one match is found, stores pendingCall and requests user confirmation.
     */
    fun initiateContactLookup(contactName: String): ExecutionResult {
        val cleanedQuery = contactName.trim()
        val cleanedNumber = ContactsHelper.cleanPhoneNumber(cleanedQuery)
        val isDirectPhoneNumber = cleanedNumber.length >= 5 && cleanedQuery.all { ch ->
            ch.isDigit() || ch == '+' || ch == '-' || ch == ' ' || ch == '(' || ch == ')'
        }

        if (isDirectPhoneNumber) {
            pendingCall = PendingCall(
                contactName = cleanedQuery,
                phoneNumber = cleanedNumber
            )
            return ExecutionResult.ConfirmationRequested(
                contactName = cleanedQuery,
                phoneNumber = cleanedNumber,
                promptMessageEn = "Do you want me to call $cleanedQuery?",
                promptMessageHi = "क्या आप $cleanedQuery पर कॉल करना चाहते हैं?"
            )
        }

        if (!hasContactsPermission()) {
            return ExecutionResult.PermissionRequired(
                permission = Manifest.permission.READ_CONTACTS,
                messageEn = "Contacts permission is required to look up $contactName. Please grant it in Settings -> Permissions.",
                messageHi = "$contactName का नंबर खोजने के लिए सेटिंग्स में जाकर कॉन्टैक्ट्स की अनुमति दें।"
            )
        }

        return when (val lookup = contactsHelper.searchContact(context, contactName)) {
            is ContactLookupResult.PermissionDenied -> {
                ExecutionResult.PermissionRequired(
                    permission = Manifest.permission.READ_CONTACTS,
                    messageEn = "Contacts permission is required to look up $contactName. Please grant it in Settings -> Permissions.",
                    messageHi = "$contactName का नंबर खोजने के लिए सेटिंग्स में जाकर कॉन्टैक्ट्स की अनुमति दें।"
                )
            }
            is ContactLookupResult.NotFound -> {
                ExecutionResult.ContactNotFound(
                    query = contactName,
                    messageEn = "I couldn't find anyone named '$contactName' in your phone contacts.",
                    messageHi = "मुझे आपके संपर्कों में '$contactName' नाम का कोई नंबर नहीं मिला।"
                )
            }
            is ContactLookupResult.Ambiguous -> {
                val names = lookup.matches.joinToString(", ") { it.name }
                ExecutionResult.AmbiguousContacts(
                    query = contactName,
                    matches = lookup.matches,
                    messageEn = "Found multiple contacts matching '$contactName': $names. Which one would you like to call?",
                    messageHi = "मुझे '$contactName' के लिए कई संपर्क मिले: $names। आप किसे कॉल करना चाहते हैं?"
                )
            }
            is ContactLookupResult.Found -> {
                val matched = lookup.contact
                pendingCall = PendingCall(
                    contactName = matched.name,
                    phoneNumber = matched.phoneNumber
                )
                ExecutionResult.ConfirmationRequested(
                    contactName = matched.name,
                    phoneNumber = matched.phoneNumber,
                    promptMessageEn = "Do you want me to call ${matched.name}?",
                    promptMessageHi = "क्या आप ${matched.name} को कॉल करना चाहते हैं?"
                )
            }
            is ContactLookupResult.Error -> {
                ExecutionResult.Error(lookup.message)
            }
        }
    }

    /**
     * Creates an Intent for placing a phone call with valid tel: URI.
     */
    fun createCallIntent(phoneNumber: String): Intent {
        val cleaned = ContactsHelper.cleanPhoneNumber(phoneNumber)
        val uri = Uri.fromParts("tel", cleaned, null)
        return Intent(Intent.ACTION_CALL, uri).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
    }

    /**
     * Executes the pending call if user confirmed and CALL_PHONE permission is granted.
     * Only returns CallInitiated if startActivity succeeds.
     */
    fun confirmAndExecuteCall(): ExecutionResult {
        val currentPending = pendingCall ?: return ExecutionResult.Ignored

        if (!hasCallPhonePermission()) {
            return ExecutionResult.PermissionRequired(
                permission = Manifest.permission.CALL_PHONE,
                messageEn = "Phone call permission is required to place calls. Please grant it in Settings -> Permissions.",
                messageHi = "कॉल लगाने के लिए फ़ोन कॉल की अनुमति आवश्यक है। कृपया अनुमति दें।"
            )
        }

        val cleanedNumber = ContactsHelper.cleanPhoneNumber(currentPending.phoneNumber)
        if (cleanedNumber.isEmpty()) {
            return ExecutionResult.Error("No valid phone number found for ${currentPending.contactName}.")
        }

        val callIntent = createCallIntent(cleanedNumber)

        return try {
            // First attempt direct ACTION_CALL to place the phone call
            context.startActivity(callIntent)

            val confirmedName = currentPending.contactName
            val confirmedNumber = currentPending.phoneNumber
            pendingCall = null

            ExecutionResult.CallInitiated(
                contactName = confirmedName,
                phoneNumber = confirmedNumber,
                messageEn = "Calling $confirmedName now.",
                messageHi = "$confirmedName को कॉल मिला रही हूँ।"
            )
        } catch (e: SecurityException) {
            ExecutionResult.PermissionRequired(
                permission = Manifest.permission.CALL_PHONE,
                messageEn = "Phone call permission was denied. Please grant it in Settings -> Permissions.",
                messageHi = "फ़ोन कॉल की अनुमति नहीं मिली। कृपया सेटिंग्स में जाकर अनुमति दें।"
            )
        } catch (e: android.content.ActivityNotFoundException) {
            // If direct ACTION_CALL is not supported or not installed, attempt ACTION_DIAL fallback
            try {
                val dialUri = Uri.fromParts("tel", cleanedNumber, null)
                val dialIntent = Intent(Intent.ACTION_DIAL, dialUri).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(dialIntent)

                val confirmedName = currentPending.contactName
                val confirmedNumber = currentPending.phoneNumber
                pendingCall = null

                ExecutionResult.CallInitiated(
                    contactName = confirmedName,
                    phoneNumber = confirmedNumber,
                    messageEn = "Opening dialer for $confirmedName.",
                    messageHi = "$confirmedName के लिए डायलर खोल रही हूँ।"
                )
            } catch (dialEx: Exception) {
                ExecutionResult.Error("No telephony or dialer application available on this device to place calls.")
            }
        } catch (e: Exception) {
            ExecutionResult.Error("Failed to launch phone call: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    /**
     * Cancels the currently pending call.
     */
    fun cancelCall(): ExecutionResult {
        pendingCall = null
        return ExecutionResult.CallCancelled(
            messageEn = "Call cancelled.",
            messageHi = "ठीक है, कॉल रद्द कर दी गई।"
        )
    }
}
