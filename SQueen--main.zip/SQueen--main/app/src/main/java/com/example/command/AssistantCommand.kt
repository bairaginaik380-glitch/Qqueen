package com.example.command

sealed class AssistantCommand {
    data class CallContact(val contactName: String) : AssistantCommand()
    data class ConfirmCall(val confirmed: Boolean) : AssistantCommand()
    data class OpenApp(val appName: String) : AssistantCommand()
    data class ClickElement(val target: String) : AssistantCommand()
    data class TypeText(val text: String, val target: String? = null) : AssistantCommand()
    data class ScrollScreen(val direction: String) : AssistantCommand()
    object GoBack : AssistantCommand()
    object GoHome : AssistantCommand()
    object ReadScreen : AssistantCommand()
    object None : AssistantCommand()

    companion object {
        // Explicit Assistant Tag formats
        private val CALL_REQUEST_TAG_REGEX = Regex("""\[CALL_REQUEST:\s*([^\]]+)\]""", RegexOption.IGNORE_CASE)
        private val CALL_CONFIRM_TAG_REGEX = Regex("""\[CALL_CONFIRM(?::\s*([^\]]+))?\]""", RegexOption.IGNORE_CASE)
        private val CALL_CANCEL_TAG_REGEX = Regex("""\[CALL_CANCEL\]""", RegexOption.IGNORE_CASE)

        private val OPEN_APP_TAG_REGEX = Regex("""\[OPEN_APP:\s*([^\]]+)\]""", RegexOption.IGNORE_CASE)
        private val CLICK_ELEMENT_TAG_REGEX = Regex("""\[CLICK_ELEMENT:\s*([^\]]+)\]""", RegexOption.IGNORE_CASE)
        private val TYPE_TEXT_TAG_REGEX = Regex("""\[TYPE_TEXT:\s*([^\]]+)\]""", RegexOption.IGNORE_CASE)
        private val SCROLL_TAG_REGEX = Regex("""\[SCROLL:\s*([^\]]+)\]""", RegexOption.IGNORE_CASE)
        private val GO_BACK_TAG_REGEX = Regex("""\[GO_BACK\]""", RegexOption.IGNORE_CASE)
        private val GO_HOME_TAG_REGEX = Regex("""\[GO_HOME\]""", RegexOption.IGNORE_CASE)
        private val READ_SCREEN_TAG_REGEX = Regex("""\[READ_SCREEN\]""", RegexOption.IGNORE_CASE)

        // English Call regex patterns
        private val EN_CALL_REGEX = Regex(
            """^(?:please\s+|can\s+you\s+|queen\s+|rani\s+)?(?:make\s+a\s+call\s+to|call\s+to|call|phone|dial)\s+([^,?.!]+)""",
            RegexOption.IGNORE_CASE
        )

        // Hindi / Hinglish: "<name> ko call/phone karo/lagao"
        private val HI_NAME_FIRST_REGEX = Regex(
            """^(?:please\s+|जरा\s+|कृपया\s+|रानी\s+|queen\s+)?(.+?)\s*(?:ko|को)\s*(?:call|phone|कॉल|फोन)\s*(?:karo|lagao|kijiye|laga\s*do|milao|करो|लगाओ|कीजिए|लगा\s*दो|मिलाओ)""",
            RegexOption.IGNORE_CASE
        )

        // Hindi / Hinglish: "call/phone karo/lagao <name> (ko)"
        private val HI_ACTION_FIRST_REGEX = Regex(
            """^(?:please\s+|जरा\s+|कृपया\s+|रानी\s+|queen\s+)?(?:call|phone|कॉल|फोन)\s*(?:karo|lagao|kijiye|laga\s*do|milao|करो|लगाओ|कीजिए|लगा\s*दो|मिलाओ)\s+(.+?)(?:\s*(?:ko|को))?$""",
            RegexOption.IGNORE_CASE
        )

        // App Launch: "open <app>", "<app> kholo", "<app> open karo"
        private val OPEN_APP_EN_REGEX = Regex(
            """^(?:please\s+|can\s+you\s+|queen\s+|rani\s+)?(?:open|launch|start)\s+(?:the\s+)?([a-zA-Z0-9\s._]+?)(?:\s+app)?$""",
            RegexOption.IGNORE_CASE
        )
        private val OPEN_APP_HI_REGEX = Regex(
            """^(?:please\s+|कृपया\s+|जरा\s+|रानी\s+|queen\s+)?([a-zA-Z0-9\s._]+?)(?:\s+(?:app|ऐप))?\s*(?:open\s*karo|kholo|chalao|khol\s*do|start\s*karo|खोलिए|खोलो|खोल\s*दो|चलाओ)$""",
            RegexOption.IGNORE_CASE
        )

        // Screen Navigation & Actions
        private val SCROLL_DOWN_REGEX = Regex("""^(?:please\s+)?(?:scroll\s*down|scroll\s*neeche|neeche\s*scroll|नीचे\s*स्क्रॉल)$""", RegexOption.IGNORE_CASE)
        private val SCROLL_UP_REGEX = Regex("""^(?:please\s+)?(?:scroll\s*up|scroll\s*upar|upar\s*scroll|ऊपर\s*स्क्रॉल)$""", RegexOption.IGNORE_CASE)
        private val BACK_NAV_REGEX = Regex("""^(?:please\s+)?(?:go\s*back|back|back\s*jao|piche\s*jao|पीछे\s*जाओ|वापस\s*जाओ)$""", RegexOption.IGNORE_CASE)
        private val HOME_NAV_REGEX = Regex("""^(?:please\s+)?(?:go\s*home|home\s*screen|home|home\s*jao|होम\s*स्क्रीन|होम)$""", RegexOption.IGNORE_CASE)

        // Screen Reading inquiries in English (expanded for natural speech)
        private val READ_SCREEN_EN_REGEX = Regex(
            """^(?:read\s+(?:the\s+|my\s+)?screen|check\s+(?:the\s+|my\s+)?screen|see\s+what(?:'s|\s+is)\s+(?:on\s+)?(?:my\s+|the\s+)?screen|what(?:'s|\s+is)\s+(?:on|visible\s+on)\s+(?:the\s+|my\s+)?screen|what\s+(?:am\s+i|are\s+we)\s+watching(?:\s+(?:right\s+now|on\s+my\s+phone|on\s+screen))?|what\s+(?:page|app|screen)\s+am\s+i\s+on|which\s+(?:page|app|screen)\s+am\s+i\s+on|what\s+app\s+is\s+(?:open|this|running)|which\s+app\s+is\s+(?:open|this|running)|what\s+video(?:\s+title)?\s+(?:is\s+playing|is\s+on\s+screen|is\s+this|is\s+visible)(?:\s+(?:right\s+now|now))?|(?:which|what)\s+video\s+is\s+this|what(?:'s|\s+is)\s+(?:the\s+)?(?:video\s+)?title(?:\s+of\s+this\s+video|\s+on\s+(?:my\s+|the\s+)?screen)?|what(?:'s|\s+is)\s+the\s+title\s+of\s+the\s+video(?:\s+on\s+(?:my\s+|the\s+)?screen)?|what\s+is\s+visible(?:\s+on\s+(?:my\s+|the\s+)?screen)?|what\s+do\s+you\s+see(?:\s+on\s+(?:my\s+|the\s+)?screen)?)$""",
            RegexOption.IGNORE_CASE
        )

        // Screen Reading inquiries in Hindi / Hinglish (supports both हूँ and हूं, रहा and रही, natural variations)
        private val READ_SCREEN_HI_REGEX = Regex(
            """^(?:स्क्रीन\s*(?:पर|में|पे)\s*क्या\s*(?:दिख\s*रहा\s*है|दिख\s*रही\s*है|है|चल\s*रहा\s*है)|स्क्रीन\s*(?:पढ़ो|पढ़कर\s*बताओ|पढ़\s*के\s*बताओ|रीड\s*करो)|मेरी\s*स्क्रीन\s*(?:पढ़ो|पढ़कर\s*बताओ|पढ़\s*के\s*बताओ|रीड\s*करो)|मैं\s*(?:अभी\s*)?क्या\s*देख\s*(?:रहा|रही)\s*[हूँहूं]|मैं\s*किस\s*(?:पेज|स्क्रीन|ऐप)\s*पर\s*[हूँहूं]|मैं\s*कौन\s*[-–]?\s*सा\s*वीडियो\s*देख\s*(?:रहा|रही)\s*[हूँहूं]|(?:इस\s*)?वीडियो\s*का\s*(?:क्या\s*)?(?:नाम|टाइटल|शीर्षक)\s*क्या\s*है|(?:इस\s*)?वीडियो\s*का\s*(?:नाम|टाइटल|शीर्षक)\s*क्या\s*है|(?:कौन\s*[-–]?\s*सा|क्या)\s*वीडियो\s*(?:चल|लगा)\s*रहा\s*है|screen\s*(?:padho|padh\s*(?:ke|kar)\s*batao|read\s*karo|par\s*kya\s*(?:hai|dikh\s*raha\s*hai|chal\s*raha\s*hai)|pe\s*kya\s*(?:hai|dikh\s*raha\s*hai|chal\s*raha\s*hai))|mai[n]?\s*(?:abhi\s*)?kya\s*dekh\s*rah[ai]\s*(?:hoon|hu|hun)|mai[n]?\s*kis\s*(?:page|screen|app)\s*(?:par|pe)\s*(?:hoon|hu|hun)|(?:is\s+)?video\s*ka\s*(?:naam|title)\s*kya\s*hai|mai[n]?\s*(?:kaun|kon)\s*[-–]?\s*sa\s*video\s*dekh\s*rah[ai]\s*(?:hoon|hu|hun)|(?:kaun|kon)\s*[-–]?\s*sa\s*video\s*chal\s*raha\s*hai|kya\s*chal\s*raha\s*hai\s*screen\s*(?:par|pe))$""",
            RegexOption.IGNORE_CASE
        )

        // Conversational polite prefixes to strip before query matching
        private val SCREEN_READ_PREFIX_REGEX = Regex(
            """^(?:please\s+|can\s+you\s+(?:please\s+)?|could\s+you\s+(?:please\s+)?|queen\s+|rani\s+|tell\s+me\s+|can\s+you\s+tell\s+me\s+|could\s+you\s+tell\s+me\s+|hey\s+queen\s+|hey\s+rani\s+|कृपया\s+|जरा\s+|रानी\s+|queen\s+|बताओ\s+|जरा\s*बताओ\s+|मुझे\s*बताओ\s+|सुनो\s+|सुनो\s*रानी\s+|batao\s+|mujhe\s*batao\s+|zara\s*batao\s+)+""",
            RegexOption.IGNORE_CASE
        )

        // Conversational polite suffixes to strip before query matching
        private val SCREEN_READ_SUFFIX_REGEX = Regex(
            """(?:\s+(?:please|right\s+now|now|zara|batao|dekh\s+ke\s+batao|padh\s+ke\s+batao|बताओ|जरा|देखकर\s*बताओ|पढ़कर\s*बताओ|पढ़\s*के\s*बताओ))+$""",
            RegexOption.IGNORE_CASE
        )

        private val CLICK_EN_REGEX = Regex("""^(?:please\s+)?(?:click|tap|press)\s+(?:on\s+)?(?:the\s+)?([a-zA-Z0-9\s._-]+)$""", RegexOption.IGNORE_CASE)
        private val CLICK_HI_REGEX = Regex("""^(.+?)\s*(?:par|pe|पर|पे)\s*(?:click|tap|दबाओ|क्लिक)\s*(?:karo|kar\s*do|करो|कर\s*दो)$""", RegexOption.IGNORE_CASE)

        // Confirmation keywords
        private val AFFIRMATIVE_WORDS = setOf(
            "yes", "yeah", "yep", "sure", "ok", "okay", "proceed", "do it",
            "please", "please call", "call him", "call her", "call them", "go ahead", "confirm", "yup", "yes please", "yes do it", "yes call",
            "haan", "ha", "haa", "haanji", "laga do", "karo", "call karo", "kar do", "bilkul", "jarur", "jaroor",
            "sahi hai", "theek hai", "thik hai", "laga", "milao", "call milao", "haan laga do", "haan call karo",
            "haanji bilkul", "haan ji", "ji haan", "bhai call karo", "laga do call", "phone karo", "phone lagao", "call lagao",
            "lagao call", "karo call", "dial karo", "call kar do", "kar dijiye", "haan kardo", "ha kardo",
            "हाँ", "हाँ लगा दो", "कॉल करो", "लगाओ", "कर दो", "श्योर", "हाँजी", "बिल्कुल", "ज़रूर", "जरूर",
            "मिलाओ", "कॉल मिलाओ", "हाँ मिला दो", "लगा दीजिये", "लगा दीजिए", "जी हाँ", "जी बिल्कुल", "हाँ जी", "फोन लगाओ", "फोन करो"
        )

        private val NEGATIVE_WORDS = setOf(
            "no", "nope", "cancel", "don't", "stop", "never mind", "don't call", "no don't", "abort", "not now", "deny",
            "nahi", "nahin", "na", "mat karo", "rehne do", "mat lagao", "cancel karo", "radd karo", "roko", "nhi", "na mat karo", "ruk jao", "mat call karo",
            "नहीं", "मत करो", "रहने दो", "कैंसिल", "रद्द करो", "नहीं लगाओ", "मत लगाओ", "ना", "रोक दो", "रुक जाओ", "मत बुलाओ"
        )

        /**
         * Checks whether an input utterance is a screen reading query.
         */
        fun isScreenReadingQuery(input: String): Boolean {
            val trimmed = input.trim()
            if (trimmed.isEmpty()) return false

            if (READ_SCREEN_TAG_REGEX.containsMatchIn(trimmed)) {
                return true
            }

            val cleaned = trimmed.trim(' ', '.', '!', '?', ',', '"', '\'', ':', '-', ';')
            val stripped = cleaned
                .replace(SCREEN_READ_PREFIX_REGEX, "")
                .replace(SCREEN_READ_SUFFIX_REGEX, "")
                .trim(' ', '.', '!', '?', ',', '"', '\'', ':', '-', ';')

            return READ_SCREEN_EN_REGEX.containsMatchIn(stripped) ||
                READ_SCREEN_HI_REGEX.containsMatchIn(stripped) ||
                READ_SCREEN_EN_REGEX.containsMatchIn(cleaned) ||
                READ_SCREEN_HI_REGEX.containsMatchIn(cleaned) ||
                READ_SCREEN_EN_REGEX.containsMatchIn(trimmed) ||
                READ_SCREEN_HI_REGEX.containsMatchIn(trimmed)
        }

        /**
         * Parses speech transcript or text input into an AssistantCommand.
         * If a call confirmation is currently pending, checks affirmative/negative responses first.
         */
        fun parse(input: String, isPendingConfirmation: Boolean = false): AssistantCommand {
            val trimmed = input.trim()
            if (trimmed.isEmpty()) return None

            // 1. Check explicit assistant action tags if present in text
            CALL_CANCEL_TAG_REGEX.find(trimmed)?.let {
                return ConfirmCall(confirmed = false)
            }
            CALL_CONFIRM_TAG_REGEX.find(trimmed)?.let {
                return ConfirmCall(confirmed = true)
            }
            CALL_REQUEST_TAG_REGEX.find(trimmed)?.let { match ->
                val name = match.groupValues[1].trim(' ', ':', '-', ',', '.', '!', '"', '\'')
                if (name.isNotEmpty()) {
                    return CallContact(cleanContactQuery(name))
                }
            }

            OPEN_APP_TAG_REGEX.find(trimmed)?.let { match ->
                val app = match.groupValues[1].trim(' ', ':', '-', ',', '.', '!', '"', '\'')
                if (app.isNotEmpty()) return OpenApp(app)
            }
            CLICK_ELEMENT_TAG_REGEX.find(trimmed)?.let { match ->
                val target = match.groupValues[1].trim(' ', ':', '-', ',', '.', '!', '"', '\'')
                if (target.isNotEmpty()) return ClickElement(target)
            }
            TYPE_TEXT_TAG_REGEX.find(trimmed)?.let { match ->
                val text = match.groupValues[1].trim(' ', ':', '-', ',', '.', '!', '"', '\'')
                if (text.isNotEmpty()) return TypeText(text)
            }
            SCROLL_TAG_REGEX.find(trimmed)?.let { match ->
                val dir = match.groupValues[1].trim(' ', ':', '-', ',', '.', '!', '"', '\'')
                if (dir.isNotEmpty()) return ScrollScreen(dir)
            }
            if (GO_BACK_TAG_REGEX.containsMatchIn(trimmed)) return GoBack
            if (GO_HOME_TAG_REGEX.containsMatchIn(trimmed)) return GoHome
            if (READ_SCREEN_TAG_REGEX.containsMatchIn(trimmed)) {
                android.util.Log.d("AssistantCommand", "Matched command: ReadScreen (viaTag=true)")
                return ReadScreen
            }

            // 2. If a call is pending confirmation, prioritize checking user's confirm/cancel answer
            if (isPendingConfirmation) {
                val lower = trimmed.lowercase().trim(' ', '.', '!', '?', ',', '"', '\'')

                // Check negative words FIRST
                if (NEGATIVE_WORDS.any { neg ->
                    lower == neg || lower.startsWith("$neg ") || lower.endsWith(" $neg") || lower.contains(" $neg ")
                }) {
                    return ConfirmCall(confirmed = false)
                }

                // Check specific direct call affirmations: "call", "dial", "call now", "please call"
                val isDirectCallConfirm = lower == "call" || lower == "dial" ||
                        lower == "call now" || lower == "dial now" ||
                        lower == "call please" || lower == "please call"

                // Check affirmative words
                if (isDirectCallConfirm || AFFIRMATIVE_WORDS.any { aff ->
                    lower == aff || lower.startsWith("$aff ") || lower.endsWith(" $aff") || lower.contains(" $aff ") || (aff.length >= 3 && lower.contains(aff))
                }) {
                    return ConfirmCall(confirmed = true)
                }
            }

            // 3. Check App Launch requests: "open youtube", "whatsapp kholo"
            OPEN_APP_EN_REGEX.find(trimmed)?.let { match ->
                val app = match.groupValues[1].trim()
                if (app.isNotBlank() && !isNonAppUtterance(app)) {
                    return OpenApp(app)
                }
            }
            OPEN_APP_HI_REGEX.find(trimmed)?.let { match ->
                val app = match.groupValues[1].trim()
                if (app.isNotBlank() && !isNonAppUtterance(app)) {
                    return OpenApp(app)
                }
            }

            // 4. Screen Navigation & Actions
            if (SCROLL_DOWN_REGEX.containsMatchIn(trimmed)) return ScrollScreen("down")
            if (SCROLL_UP_REGEX.containsMatchIn(trimmed)) return ScrollScreen("up")
            if (BACK_NAV_REGEX.containsMatchIn(trimmed)) return GoBack
            if (HOME_NAV_REGEX.containsMatchIn(trimmed)) return GoHome

            if (isScreenReadingQuery(trimmed)) {
                android.util.Log.d("AssistantCommand", "Matched command: ReadScreen (query='$trimmed')")
                return ReadScreen
            }

            CLICK_EN_REGEX.find(trimmed)?.let { match ->
                val target = match.groupValues[1].trim()
                if (target.isNotBlank()) return ClickElement(target)
            }
            CLICK_HI_REGEX.find(trimmed)?.let { match ->
                val target = match.groupValues[1].trim()
                if (target.isNotBlank()) return ClickElement(target)
            }

            // 5. Check Hindi/Hinglish patterns: "<name> ko call/phone karo/lagao"
            HI_NAME_FIRST_REGEX.find(trimmed)?.let { match ->
                val candidateName = match.groupValues[1].trim(' ', '.', '!', '?', ',')
                if (candidateName.isNotBlank() && !isNonCallUtterance(candidateName)) {
                    return CallContact(cleanContactQuery(candidateName))
                }
            }

            // 6. Check Hindi/Hinglish: "call karo <name>"
            HI_ACTION_FIRST_REGEX.find(trimmed)?.let { match ->
                val candidateName = match.groupValues[1].trim(' ', '.', '!', '?', ',')
                if (candidateName.isNotBlank() && !isNonCallUtterance(candidateName)) {
                    return CallContact(cleanContactQuery(candidateName))
                }
            }

            // 7. Check English: "call <name>" / "make a call to <name>"
            EN_CALL_REGEX.find(trimmed)?.let { match ->
                val candidateName = match.groupValues[1].trim(' ', '.', '!', '?', ',')
                if (candidateName.isNotBlank() && !isNonCallUtterance(candidateName)) {
                    return CallContact(cleanContactQuery(candidateName))
                }
            }

            return None
        }

        private fun cleanContactQuery(query: String): String {
            return query
                .replace(Regex("""^(?:please\s+|कृपया\s+|जरा\s+|रानी\s+|queen\s+)""", RegexOption.IGNORE_CASE), "")
                .replace(Regex("""\s*(?:ko|को|ji|जी)$""", RegexOption.IGNORE_CASE), "")
                .trim(' ', '.', '!', '?', ',', '"', '\'')
        }

        private fun isNonCallUtterance(candidate: String): Boolean {
            val lower = candidate.lowercase().trim()
            if (lower == "me" || lower == "this" || lower == "that" || lower == "it" || lower == "you") return true
            if (lower.contains("what") || lower.contains("how") || lower.contains("why")) return true
            return false
        }

        private fun isNonAppUtterance(candidate: String): Boolean {
            val lower = candidate.lowercase().trim()
            if (lower == "me" || lower == "this" || lower == "that" || lower == "it" || lower == "door" || lower == "window") return true
            return false
        }
    }
}
