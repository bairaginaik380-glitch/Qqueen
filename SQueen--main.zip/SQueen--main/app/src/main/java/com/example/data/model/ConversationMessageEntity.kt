package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a saved voice conversation turn transcript stored strictly on-device.
 */
@Entity(tableName = "conversation_history")
data class ConversationMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val role: String, // "user" or "queen"
    val content: String,
    val sessionId: String = ""
)
