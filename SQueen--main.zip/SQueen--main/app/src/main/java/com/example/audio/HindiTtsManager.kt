package com.example.audio

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import java.util.Locale

class HindiTtsManager(context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var isInitialized = false
    private var pendingSpeak = false
    private var lastSpeakTimestamp = 0L

    companion object {
        const val PHRASE = "जी बोलिए"
        private const val UTTERANCE_ID = "queen_hindi_greeting"
        private const val MIN_TAP_INTERVAL_MS = 350L
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val engine = tts ?: return
            val hindi = Locale.forLanguageTag("hi-IN")
            val langResult = engine.setLanguage(hindi)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                engine.setLanguage(Locale.forLanguageTag("hi"))
            }

            // Attempt to select a natural female voice if available in system TTS engines
            try {
                val voices = engine.voices
                if (!voices.isNullOrEmpty()) {
                    val femaleVoice = voices.firstOrNull { voice ->
                        voice.locale.language.equals("hi", ignoreCase = true) &&
                                (voice.name.contains("female", ignoreCase = true) ||
                                        voice.name.contains("f0", ignoreCase = true) ||
                                        voice.name.contains("hi-in-x-hie", ignoreCase = true) ||
                                        voice.name.contains("hi-in-x-hia", ignoreCase = true) ||
                                        voice.features?.any { it.contains("female", ignoreCase = true) } == true)
                    } ?: voices.firstOrNull { voice ->
                        voice.locale.language.equals("hi", ignoreCase = true)
                    }

                    if (femaleVoice != null) {
                        engine.voice = femaleVoice
                    }
                }
            } catch (e: Exception) {
                // Fallback to default engine voice
            }

            engine.setPitch(1.15f) // Warm, sweet female tone
            engine.setSpeechRate(1.0f)
            isInitialized = true

            if (pendingSpeak) {
                pendingSpeak = false
                speakPhraseInternal(engine)
            }
        }
    }

    /**
     * Speaks "जी बोलिए" immediately.
     * Prevents overlapping speech on repeated rapid taps by stopping any active speech,
     * applying a debounce threshold, and using TextToSpeech.QUEUE_FLUSH.
     */
    fun speakJiBoliye() {
        val now = System.currentTimeMillis()
        if (now - lastSpeakTimestamp < MIN_TAP_INTERVAL_MS) {
            return
        }
        lastSpeakTimestamp = now

        val engine = tts ?: return
        if (isInitialized) {
            speakPhraseInternal(engine)
        } else {
            pendingSpeak = true
        }
    }

    private fun speakPhraseInternal(engine: TextToSpeech) {
        try {
            engine.stop()
            val params = Bundle()
            engine.speak(PHRASE, TextToSpeech.QUEUE_FLUSH, params, UTTERANCE_ID)
        } catch (e: Exception) {
            // Ignore speech errors
        }
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            // Ignore
        }
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
            // Ignore
        } finally {
            tts = null
            isInitialized = false
            pendingSpeak = false
        }
    }
}
