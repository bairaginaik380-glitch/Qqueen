#!/usr/bin/env node
/**
 * Queen AI — Admin Token Management CLI
 * Developed for Shyam Kadam
 *
 * Safe admin-only utility to create, revoke, inspect, and set expiry on tokens in Firestore.
 * Requires: GOOGLE_APPLICATION_CREDENTIALS pointing to service account key, or ambient credentials.
 *
 * Commands:
 *   node manage_tokens.js create [--days <number>] [--desc <description>]
 *   node manage_tokens.js revoke <token_or_hash>
 *   node manage_tokens.js expire <token_or_hash> [--days <number>]
 *   node manage_tokens.js unbind <token_or_hash>
 *   node manage_tokens.js status <token_or_hash>
 *   node manage_tokens.js list [--limit <number>]
 */

const admin = require('firebase-admin');
const crypto = require('crypto');

// Initialize Firebase Admin SDK
if (!admin.apps.length) {
  try {
    admin.initializeApp();
  } catch (err) {
    console.error('Failed to initialize Firebase Admin SDK. Ensure GOOGLE_APPLICATION_CREDENTIALS is set.');
    process.exit(1);
  }
}

const db = admin.firestore();
const TOKENS_COLLECTION = 'queen_access_tokens';
const ALPHABET = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';

function generateQueenToken() {
  let result = 'Q';
  const randomBytes = crypto.randomBytes(9);
  for (let i = 0; i < 9; i++) {
    result += ALPHABET[randomBytes[i] % ALPHABET.length];
  }
  return result;
}

function resolveHash(tokenOrHash) {
  const clean = String(tokenOrHash).trim().toUpperCase();
  if (clean.length === 64 && /^[0-9A-F]+$/i.test(clean)) {
    return clean.toLowerCase();
  }
  return crypto.createHash('sha256').update(clean).digest('hex');
}

async function createToken(options) {
  const token = generateQueenToken();
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const now = new Date();

  let expiresAtTimestamp = null;
  if (options.days && !isNaN(options.days)) {
    const expireDate = new Date(now.getTime() + options.days * 86400 * 1000);
    expiresAtTimestamp = admin.firestore.Timestamp.fromDate(expireDate);
  }

  const docRef = db.collection(TOKENS_COLLECTION).doc(tokenHash);
  const data = {
    token_prefix: token.substring(0, 3),
    sha256_hash: tokenHash,
    status: 'ACTIVE',
    description: options.desc || 'Admin generated token',
    expires_at: expiresAtTimestamp,
    bound_device_id: null,
    bound_at: null,
    created_at: admin.firestore.FieldValue.serverTimestamp(),
    last_used_at: null,
    usage_count: 0
  };

  await docRef.set(data);

  console.log('====================================================');
  console.log('✅ NEW QUEEN ACCESS TOKEN CREATED SUCCESSFULLY');
  console.log('====================================================');
  console.log(`Plaintext Token (Give to user) : ${token}`);
  console.log(`SHA-256 Hash (Firestore doc ID): ${tokenHash}`);
  console.log(`Status                          : ACTIVE`);
  console.log(`Expires                         : ${expiresAtTimestamp ? expiresAtTimestamp.toDate().toISOString() : 'Never'}`);
  console.log('====================================================');
  console.log('NOTE: Plaintext token is NOT stored in Firestore.');
}

async function revokeToken(tokenOrHash) {
  const hash = resolveHash(tokenOrHash);
  const docRef = db.collection(TOKENS_COLLECTION).doc(hash);
  const doc = await docRef.get();

  if (!doc.exists) {
    console.error(`❌ Token hash ${hash} not found in Firestore.`);
    process.exit(1);
  }

  await docRef.update({
    status: 'REVOKED',
    revoked_at: admin.firestore.FieldValue.serverTimestamp()
  });

  console.log(`✅ Token ${hash} successfully marked as REVOKED.`);
}

async function expireToken(tokenOrHash, options) {
  const hash = resolveHash(tokenOrHash);
  const docRef = db.collection(TOKENS_COLLECTION).doc(hash);
  const doc = await docRef.get();

  if (!doc.exists) {
    console.error(`❌ Token hash ${hash} not found in Firestore.`);
    process.exit(1);
  }

  let expiresAtTimestamp;
  if (options.days && !isNaN(options.days)) {
    const expireDate = new Date(Date.now() + options.days * 86400 * 1000);
    expiresAtTimestamp = admin.firestore.Timestamp.fromDate(expireDate);
  } else {
    // Expire immediately
    expiresAtTimestamp = admin.firestore.Timestamp.fromMillis(Date.now() - 1000);
  }

  await docRef.update({
    expires_at: expiresAtTimestamp,
    status: expiresAtTimestamp.toMillis() < Date.now() ? 'EXPIRED' : 'ACTIVE'
  });

  console.log(`✅ Expiration updated for token ${hash}. Expiry: ${expiresAtTimestamp.toDate().toISOString()}`);
}

async function unbindToken(tokenOrHash) {
  const hash = resolveHash(tokenOrHash);
  const docRef = db.collection(TOKENS_COLLECTION).doc(hash);
  const doc = await docRef.get();

  if (!doc.exists) {
    console.error(`❌ Token hash ${hash} not found in Firestore.`);
    process.exit(1);
  }

  await docRef.update({
    bound_device_id: null,
    bound_at: null
  });

  console.log(`✅ Device unbinding complete for token ${hash}. Can now be bound to a new device.`);
}

async function showStatus(tokenOrHash) {
  const hash = resolveHash(tokenOrHash);
  const docRef = db.collection(TOKENS_COLLECTION).doc(hash);
  const doc = await docRef.get();

  if (!doc.exists) {
    console.error(`❌ Token hash ${hash} not found in Firestore.`);
    process.exit(1);
  }

  const data = doc.data();
  console.log('----------------------------------------------------');
  console.log(`Token Prefix    : ${data.token_prefix || 'N/A'}`);
  console.log(`SHA-256 Hash    : ${hash}`);
  console.log(`Status          : ${data.status}`);
  console.log(`Bound Device ID : ${data.bound_device_id || 'None (Unused)'}`);
  console.log(`Bound At        : ${data.bound_at ? data.bound_at.toDate().toISOString() : 'Never'}`);
  console.log(`Expires At      : ${data.expires_at ? data.expires_at.toDate().toISOString() : 'Never'}`);
  console.log(`Created At      : ${data.created_at ? data.created_at.toDate().toISOString() : 'N/A'}`);
  console.log(`Usage Count     : ${data.usage_count || 0}`);
  console.log('----------------------------------------------------');
}

async function listTokens(limit = 20) {
  const snapshot = await db.collection(TOKENS_COLLECTION).limit(limit).get();
  console.log(`Found ${snapshot.docs.length} tokens (limit ${limit}):`);
  snapshot.docs.forEach((doc, idx) => {
    const d = doc.data();
    console.log(`[${idx + 1}] Hash: ${doc.id.substring(0, 12)}... | Status: ${d.status} | Device: ${d.bound_device_id ? d.bound_device_id.substring(0, 15) : 'Unbound'}`);
  });
}

async function main() {
  const args = process.argv.slice(2);
  const command = args[0];

  if (!command) {
    console.log('Usage:');
    console.log('  node manage_tokens.js create [--days N] [--desc "..."]');
    console.log('  node manage_tokens.js revoke <token_or_hash>');
    console.log('  node manage_tokens.js expire <token_or_hash> [--days N]');
    console.log('  node manage_tokens.js unbind <token_or_hash>');
    console.log('  node manage_tokens.js status <token_or_hash>');
    console.log('  node manage_tokens.js list [--limit N]');
    process.exit(0);
  }

  function getArg(flag) {
    const idx = args.indexOf(flag);
    return idx !== -1 && idx + 1 < args.length ? args[idx + 1] : null;
  }

  switch (command) {
    case 'create': {
      const days = parseInt(getArg('--days'), 10);
      const desc = getArg('--desc');
      await createToken({ days: isNaN(days) ? null : days, desc });
      break;
    }
    case 'revoke': {
      const token = args[1];
      if (!token) {
        console.error('Error: specify token or SHA-256 hash to revoke.');
        process.exit(1);
      }
      await revokeToken(token);
      break;
    }
    case 'expire': {
      const token = args[1];
      if (!token) {
        console.error('Error: specify token or SHA-256 hash.');
        process.exit(1);
      }
      const days = parseInt(getArg('--days'), 10);
      await expireToken(token, { days: isNaN(days) ? null : days });
      break;
    }
    case 'unbind': {
      const token = args[1];
      if (!token) {
        console.error('Error: specify token or SHA-256 hash to unbind.');
        process.exit(1);
      }
      await unbindToken(token);
      break;
    }
    case 'status': {
      const token = args[1];
      if (!token) {
        console.error('Error: specify token or SHA-256 hash.');
        process.exit(1);
      }
      await showStatus(token);
      break;
    }
    case 'list': {
      const limit = parseInt(getArg('--limit') || '20', 10);
      await listTokens(limit);
      break;
    }
    default:
      console.error(`Unknown command: ${command}`);
      process.exit(1);
  }
}

main().catch(err => {
  console.error('Command failed:', err);
  process.exit(1);
});
