package com.example.data.repository

import android.content.Context
import androidx.room.withTransaction
import com.example.data.db.QueenDatabase
import com.example.data.model.ConversationMessageEntity
import com.example.data.model.ImportantMemoryEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class StorageStats(
    val totalStorageMb: Double,
    val databaseSizeMb: Double,
    val cacheSizeMb: Double,
    val historyCount: Int,
    val memoryCount: Int
) {
    val formattedTotalMb: String
        get() = String.format(Locale.US, "%.2f MB", totalStorageMb)

    val formattedDbMb: String
        get() = String.format(Locale.US, "%.2f MB", databaseSizeMb)

    val formattedCacheMb: String
        get() = String.format(Locale.US, "%.2f MB", cacheSizeMb)
}

data class BackupExportResult(
    val success: Boolean,
    val filePath: String = "",
    val message: String,
    val historyCount: Int = 0,
    val memoryCount: Int = 0
)

data class BackupRestoreResult(
    val success: Boolean,
    val message: String,
    val restoredHistoryCount: Int = 0,
    val restoredMemoryCount: Int = 0
)

class MemoryRepository(
    private val context: Context,
    private val database: QueenDatabase = QueenDatabase.getInstance(context)
) {
    private val historyDao = database.conversationHistoryDao()
    private val memoryDao = database.importantMemoryDao()

    val conversationHistory: Flow<List<ConversationMessageEntity>> = historyDao.getAllMessages()
    val importantMemories: Flow<List<ImportantMemoryEntity>> = memoryDao.getAllMemories()

    /**
     * Saves an actual available transcript from a voice turn to local on-device history.
     * Rejects empty or whitespace-only content.
     */
    suspend fun saveConversationMessage(
        role: String,
        content: String,
        sessionId: String = ""
    ): Boolean = withContext(Dispatchers.IO) {
        val trimmed = content.trim()
        if (trimmed.isEmpty()) return@withContext false

        try {
            val entity = ConversationMessageEntity(
                timestamp = System.currentTimeMillis(),
                role = role.lowercase().trim(),
                content = trimmed,
                sessionId = sessionId
            )
            val id = historyDao.insertMessage(entity)

            // Extract and persist long-term memories from both user speech/text and explicit directives
            val isUser = role.equals("user", ignoreCase = true)
            extractAndSaveMemory(trimmed, isUser)

            id > 0
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Explicitly saves an important fact, task, or plan to separate long-term memory.
     * Prevents empty entries, ignores case-insensitive exact duplicates, and resolves contradictions.
     */
    suspend fun saveImportantMemory(
        content: String,
        category: String = "FACT"
    ): Boolean = withContext(Dispatchers.IO) {
        val trimmed = content.trim()
        if (trimmed.isEmpty() || isSensitiveOrSecret(trimmed)) return@withContext false

        try {
            val existing = memoryDao.getAllMemoriesList()
            if (existing.any { it.content.equals(trimmed, ignoreCase = true) }) {
                return@withContext true // Already saved, handle duplicate safely
            }

            // Resolve contradictions by updating existing superseded facts
            resolveContradictions(trimmed, existing)

            val entity = ImportantMemoryEntity(
                timestamp = System.currentTimeMillis(),
                category = category.uppercase().trim(),
                content = trimmed
            )
            val id = memoryDao.insertMemory(entity)
            id > 0
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Retrieves all active memories formatted for injection into Queen's Gemini Live prompt.
     */
    suspend fun getActiveMemoriesForPrompt(): List<String> = withContext(Dispatchers.IO) {
        try {
            memoryDao.getAllMemoriesList().map { it.content }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Deletes a specific important memory by ID.
     */
    suspend fun deleteMemory(id: Long): Boolean = withContext(Dispatchers.IO) {
        try {
            memoryDao.deleteById(id) > 0
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Clears regular conversation history only.
     * IMPORTANT: Important long-term memories are strictly preserved and NOT cleared.
     */
    suspend fun clearConversationHistory(): Int = withContext(Dispatchers.IO) {
        try {
            historyDao.clearAll()
        } catch (e: Exception) {
            0
        }
    }

    /**
     * Clears separate important long-term memories.
     */
    suspend fun clearImportantMemories(): Int = withContext(Dispatchers.IO) {
        try {
            memoryDao.clearAll()
        } catch (e: Exception) {
            0
        }
    }

    /**
     * Calculates storage space used in MB across database and temporary cache.
     */
    suspend fun getStorageStats(): StorageStats = withContext(Dispatchers.IO) {
        var dbBytes = 0L
        try {
            val dbFile = context.getDatabasePath(QueenDatabase.DATABASE_NAME)
            if (dbFile.exists()) dbBytes += dbFile.length()
            val walFile = File(dbFile.path + "-wal")
            if (walFile.exists()) dbBytes += walFile.length()
            val shmFile = File(dbFile.path + "-shm")
            if (shmFile.exists()) dbBytes += shmFile.length()
        } catch (_: Exception) {}

        var cacheBytes = 0L
        try {
            val cacheDir = context.cacheDir
            if (cacheDir.exists()) {
                cacheDir.walkTopDown().forEach { file ->
                    if (file.isFile) cacheBytes += file.length()
                }
            }
        } catch (_: Exception) {}

        val historyCount = try { historyDao.getCount() } catch (_: Exception) { 0 }
        val memoryCount = try { memoryDao.getCount() } catch (_: Exception) { 0 }

        val bytesInMb = 1024.0 * 1024.0
        val dbMb = dbBytes / bytesInMb
        val cacheMb = cacheBytes / bytesInMb

        StorageStats(
            totalStorageMb = dbMb + cacheMb,
            databaseSizeMb = dbMb,
            cacheSizeMb = cacheMb,
            historyCount = historyCount,
            memoryCount = memoryCount
        )
    }

    /**
     * Clears cache directory safely.
     */
    suspend fun clearCache(): Boolean = withContext(Dispatchers.IO) {
        try {
            val cacheDir = context.cacheDir
            if (cacheDir.exists()) {
                cacheDir.listFiles()?.forEach { file ->
                    file.deleteRecursively()
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Creates a local on-device backup of both Conversation History and Important Memories.
     */
    suspend fun exportBackup(): BackupExportResult = withContext(Dispatchers.IO) {
        try {
            val history = historyDao.getAllMessagesList()
            val memories = memoryDao.getAllMemoriesList()

            val root = JSONObject().apply {
                put("app", "Queen AI")
                put("schema_version", 1)
                put("exported_at", System.currentTimeMillis())
                put("history_count", history.size)
                put("memory_count", memories.size)

                val historyArray = JSONArray()
                history.forEach { item ->
                    historyArray.put(JSONObject().apply {
                        put("timestamp", item.timestamp)
                        put("role", item.role)
                        put("content", item.content)
                        put("sessionId", item.sessionId)
                    })
                }
                put("conversation_history", historyArray)

                val memoryArray = JSONArray()
                memories.forEach { mem ->
                    memoryArray.put(JSONObject().apply {
                        put("timestamp", mem.timestamp)
                        put("category", mem.category)
                        put("content", mem.content)
                    })
                }
                put("important_memories", memoryArray)
            }

            val backupDir = File(context.filesDir, "backups")
            if (!backupDir.exists()) backupDir.mkdirs()

            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val backupFile = File(backupDir, "queen_backup_$timestamp.json")
            backupFile.writeText(root.toString(2), Charsets.UTF_8)

            BackupExportResult(
                success = true,
                filePath = backupFile.absolutePath,
                message = "Backup created successfully with ${history.size} transcripts and ${memories.size} memories.",
                historyCount = history.size,
                memoryCount = memories.size
            )
        } catch (e: Exception) {
            BackupExportResult(
                success = false,
                message = "Backup failed: ${e.localizedMessage ?: "Unknown I/O error"}"
            )
        }
    }

    /**
     * Validates and restores a backup file safely.
     * Does not report success unless items are actually validated and committed.
     */
    suspend fun restoreBackup(jsonString: String): BackupRestoreResult = withContext(Dispatchers.IO) {
        val trimmed = jsonString.trim()
        if (trimmed.isEmpty()) {
            return@withContext BackupRestoreResult(
                success = false,
                message = "Cannot restore empty backup data."
            )
        }

        try {
            val root = JSONObject(trimmed)

            // Validate header schema
            if (!root.has("app") && !root.has("schema_version") && !root.has("conversation_history") && !root.has("important_memories")) {
                return@withContext BackupRestoreResult(
                    success = false,
                    message = "Invalid backup file: Unrecognized Queen AI backup format."
                )
            }

            val historyArray = root.optJSONArray("conversation_history")
            val memoryArray = root.optJSONArray("important_memories")

            val historyEntities = mutableListOf<ConversationMessageEntity>()
            if (historyArray != null) {
                for (i in 0 until historyArray.length()) {
                    val obj = historyArray.optJSONObject(i) ?: continue
                    val content = obj.optString("content").trim()
                    if (content.isNotEmpty()) {
                        historyEntities.add(
                            ConversationMessageEntity(
                                timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                                role = obj.optString("role", "queen"),
                                content = content,
                                sessionId = obj.optString("sessionId", "")
                            )
                        )
                    }
                }
            }

            val memoryEntities = mutableListOf<ImportantMemoryEntity>()
            if (memoryArray != null) {
                for (i in 0 until memoryArray.length()) {
                    val obj = memoryArray.optJSONObject(i) ?: continue
                    val content = obj.optString("content").trim()
                    if (content.isNotEmpty()) {
                        memoryEntities.add(
                            ImportantMemoryEntity(
                                timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                                category = obj.optString("category", "FACT"),
                                content = content
                            )
                        )
                    }
                }
            }

            if (historyEntities.isEmpty() && memoryEntities.isEmpty()) {
                return@withContext BackupRestoreResult(
                    success = false,
                    message = "Backup file contains no valid conversation history or memory records."
                )
            }

            // Perform atomic restore transaction
            database.withTransaction {
                if (historyEntities.isNotEmpty()) {
                    historyDao.insertAll(historyEntities)
                }
                if (memoryEntities.isNotEmpty()) {
                    memoryDao.insertAll(memoryEntities)
                }
            }

            BackupRestoreResult(
                success = true,
                message = "Restore complete: Restored ${historyEntities.size} history transcripts and ${memoryEntities.size} memories.",
                restoredHistoryCount = historyEntities.size,
                restoredMemoryCount = memoryEntities.size
            )
        } catch (e: Exception) {
            BackupRestoreResult(
                success = false,
                message = "Failed to parse or restore backup: ${e.localizedMessage ?: "Invalid JSON"}"
            )
        }
    }

    /**
     * Checks if a phrase explicitly requests Rani/Queen to remember a fact, task, or plan,
     * or contains an assistant acknowledgment of an explicit memory directive.
     */
    /**
     * Checks if a phrase explicitly requests Rani/Queen to remember a fact, task, or plan,
     * or contains an assistant acknowledgment of an explicit memory directive.
     */
    suspend fun extractAndSaveExplicitMemory(text: String): Boolean {
        return extractAndSaveMemory(text, isUser = true)
    }

    /**
     * Extracts and persists long-term memories from both user speech/text and explicit directives.
     * High priority is given to explicit memory directives.
     * Automatically extracts user names, relationships, preferences, hobbies, events, and work/plans.
     * Strictly filters out greetings, filler, secrets, and questions.
     * Resolves contradictions by updating superseded facts.
     */
    private fun extractAssistantConfirmationFact(trimmedText: String): Pair<String, String>? {
        // Tag format [REMEMBER: ...] or [MEMORY: ...]
        val tagRegex = Regex("""\[(?:REMEMBER|MEMORY):\s*([^\]]+)\]""", RegexOption.IGNORE_CASE)
        val tagMatch = tagRegex.find(trimmedText)
        if (tagMatch != null) {
            val fact = tagMatch.groupValues[1].trim(' ', ':', '-', ',', '.', '!', '"', '\'', '।')
            return fact to determineCategory(fact)
        }

        // Assistant confirmation regex: "मैंने याद रख लिया कि..."
        val ackRegex = Regex(
            """(?:ज़रूर|ज़रूर!|बिल्कुल|बिल्कुल!)?\s*मैंने\s+याद\s+रख\s+लिया\s+कि\s*(.+)$""",
            RegexOption.IGNORE_CASE
        )
        val ackMatch = ackRegex.find(trimmedText)
        if (ackMatch != null) {
            val rawFact = ackMatch.groupValues[1].trim(' ', ':', '-', ',', '.', '!', '"', '\'', '।')
            val lower = rawFact.lowercase()
            // Exclude conversational acknowledgments about user's name or simple preferences
            if (rawFact.contains("आपका नाम") || rawFact.contains("तुम्हारा नाम") || lower.contains("your name") || lower.contains("you love") || lower.contains("you like")) {
                return null
            }
            return rawFact to determineCategory(rawFact)
        }
        return null
    }

    suspend fun extractAndSaveMemory(text: String, isUser: Boolean = true): Boolean {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return false

        // Rule 7: Privacy Guard - never automatically store passwords, secrets, tokens, or API keys
        if (isSensitiveOrSecret(trimmed)) {
            return false
        }

        if (!isUser) {
            // Only extract explicit assistant tags [REMEMBER: ...] or scheduled task confirmations
            val assistantResult = extractAssistantConfirmationFact(trimmed) ?: return false
            val (fact, category) = assistantResult
            if (fact.length >= 3 && !isSensitiveOrSecret(fact) && !isGreetingOrFiller(fact)) {
                return saveImportantMemory(fact, category)
            }
            return false
        }

        // 1. Explicit remember requests have HIGHEST priority
        val explicitResult = extractExplicitDirectiveFact(trimmed)
        if (explicitResult != null) {
            val (fact, category) = explicitResult
            if (fact.length >= 3 && !isSensitiveOrSecret(fact) && !isGreetingOrFiller(fact)) {
                return saveImportantMemory(fact, category)
            }
        }

        // Rule 4: Do not save every sentence. Ignore greetings, filler, temporary trivial details, and uncertain guesses
        if (isGreetingOrFiller(trimmed)) {
            return false
        }

        // 2. Automatic Memory Extraction from the user's actual words
        val autoMemories = extractAutomaticMemories(trimmed)
        var anySaved = false
        for ((fact, category) in autoMemories) {
            if (fact.length >= 3 && !isSensitiveOrSecret(fact) && !isGreetingOrFiller(fact)) {
                val saved = saveImportantMemory(fact, category)
                if (saved) anySaved = true
            }
        }
        return anySaved
    }

    private fun extractExplicitDirectiveFact(trimmedText: String): Pair<String, String>? {
        // Tag format [REMEMBER: ...] or [MEMORY: ...]
        val tagRegex = Regex("""\[(?:REMEMBER|MEMORY):\s*([^\]]+)\]""", RegexOption.IGNORE_CASE)
        val tagMatch = tagRegex.find(trimmedText)
        if (tagMatch != null) {
            val fact = tagMatch.groupValues[1].trim(' ', ':', '-', ',', '.', '!', '"', '\'')
            return fact to determineCategory(fact)
        }

        // Leading directive regex: "remember this: ...", "save a fact: ...", "save this fact that ...", etc.
        val leadingDirectiveRegex = Regex(
            """^(?:hey\s+|hello\s+)?(?:queen\s*,?\s*|rani\s*,?\s*)?(?:can\s+you\s+|could\s+you\s+|please\s+|i\s+want\s+you\s+to\s+)?(?:remember\s+this|save\s+(?:a\s+|this\s+)?fact|save\s+(?:this\s+)?to\s+memory|save\s+this|keep\s+in\s+mind|note\s+this|don't\s+forget)\s*(?:that|for\s+me\s+that|for\s+me|about\s+this)?\s*[:,\-–—]?\s*(.+)$""",
            RegexOption.IGNORE_CASE
        )
        val leadingMatch = leadingDirectiveRegex.find(trimmedText)
        if (leadingMatch != null) {
            val rawFact = leadingMatch.groupValues[1].trim(' ', ':', '-', ',', '.', '!', '"', '\'')
            return rawFact to determineCategory(rawFact)
        }

        // Trailing directive regex: "<fact>, remember this", etc.
        val trailingDirectiveRegex = Regex(
            """^(.+?)\s*[:,\-–—.]\s*(?:please\s+)?(?:queen\s*,?\s*|rani\s*,?\s*)?(?:remember\s+this|save\s+(?:a\s+|this\s+)?fact|save\s+this|याद\s+रखना|यह\s+याद\s+रखना)\.?$""",
            RegexOption.IGNORE_CASE
        )
        val trailingMatch = trailingDirectiveRegex.find(trimmedText)
        if (trailingMatch != null) {
            val rawFact = trailingMatch.groupValues[1].trim(' ', ':', '-', ',', '.', '!', '"', '\'')
            return rawFact to determineCategory(rawFact)
        }

        // Hindi leading directive regex
        val hindiDirectiveRegex = Regex(
            """^(?:रानी\s*,?\s*|queen\s*,?\s*)?(?:कृपया\s+)?(?:यह\s+)?(?:याद\s+(?:रखना|रखो|रख)|नोट\s+कर\s+(?:लो|लेना))\s*(?:कि|यह\s+कि|यह)?\s*[:,\-–—]?\s*(.+)$""",
            RegexOption.IGNORE_CASE
        )
        val hindiMatch = hindiDirectiveRegex.find(trimmedText)
        if (hindiMatch != null) {
            val rawFact = hindiMatch.groupValues[1].trim(' ', ':', '-', ',', '.', '!', '"', '\'')
            return rawFact to determineCategory(rawFact)
        }

        // Prefix list check
        val lower = trimmedText.lowercase()
        val prefixes = listOf(
            "remember this that", "remember this:", "remember this -", "remember this,", "remember this",
            "save a fact that", "save a fact:", "save a fact", "save this fact that", "save this fact:", "save this fact",
            "save to memory:", "save to memory that", "save to memory", "save this to memory",
            "rani remember that", "rani remember this", "rani remember", "rani please remember",
            "queen remember that", "queen remember this", "queen remember", "rani note that",
            "रानी याद रखना कि", "रानी, यह याद रखना कि", "रानी यह याद रखना कि", "रानी, यह याद रखना",
            "रानी यह याद रखना", "यह याद रखना कि", "यह याद रखना", "रानी याद रखना", "रानी याद रखो कि",
            "रानी याद रखो", "रानी नोट कर लो कि", "रानी नोट कर लो", "रानी याद रख", "please remember this",
            "please remember that", "please remember", "remember that", "remember:", "remind me that",
            "remind me:", "keep in mind that", "keep in mind:", "keep in mind", "note that",
            "याद रखना कि", "याद रखो", "याद रखना:", "याद रख",
            "remember ", "please remember ", "rani remember ", "queen remember "
        )
        for (prefix in prefixes) {
            val idx = lower.indexOf(prefix)
            if (idx != -1) {
                val rawFact = trimmedText.substring(idx + prefix.length).trim(' ', ':', '-', ',', '.', '!', '"', '\'')
                if (rawFact.length >= 3) {
                    return rawFact to determineCategory(rawFact)
                }
            }
        }

        return null
    }

    private fun extractAutomaticMemories(text: String): List<Pair<String, String>> {
        val memories = mutableListOf<Pair<String, String>>()
        val clean = text.trim()

        // 1. User Name
        val nameRegex = Regex(
            """(?:^|\b)(?:my\s+(?:full\s+)?name(?:'s|\s+is)|call me|you can call me|i am|i'm|myself)\s+([A-Za-z\u0900-\u097F]+(?:\s+[A-Za-z\u0900-\u097F]+)?)\b""",
            RegexOption.IGNORE_CASE
        )
        val nameMatch = nameRegex.find(clean)
        if (nameMatch != null) {
            var rawName = nameMatch.groupValues[1].trim(' ', '.', '!', ',')
            val parts = rawName.split(Regex("""\s+"""))
            val stopWords = setOf("and", "or", "from", "in", "who", "with", "the", "a", "an", "living", "working", "here", "to", "at", "for")
            if (parts.size > 1 && stopWords.contains(parts[1].lowercase())) {
                rawName = parts[0]
            }
            val lowerFirst = parts[0].lowercase()
            val nonNameWords = setOf(
                "good", "fine", "busy", "ready", "happy", "tired", "sad", "here", "sorry",
                "back", "learning", "trying", "working", "talking", "listening", "ok", "okay",
                "a", "an", "the", "queen", "rani", "not", "just", "so", "very", "feeling",
                "going", "doing", "having", "waiting", "sitting", "standing", "looking",
                "watching", "eating", "drinking", "sleeping", "travelling", "traveling",
                "leaving", "coming", "excited", "glad", "bored", "interested", "afraid", "scared"
            )
            if (!nonNameWords.contains(lowerFirst) && rawName.length in 2..30) {
                memories.add("User's name is $rawName" to "FACT")
            }
        }
        val hindiNameRegex = Regex("""(?:(?:मेरा नाम(?: है)?|मुझे)\s+([A-Za-z\u0900-\u097F]+)(?:\s+(?:है|बुलाओ|कहते हैं))?)""", RegexOption.IGNORE_CASE)
        val hindiNameMatch = hindiNameRegex.find(clean)
        if (hindiNameMatch != null) {
            val name = hindiNameMatch.groupValues[1].trim(' ', '.', '!', ',')
            if (name.length in 2..30 && name != "रानी" && name != "queen") {
                memories.add("User's name is $name" to "FACT")
            }
        }

        // 2. Friends & Relationships
        val friendRegex = Regex(
            """(?:^|\b)(?:my\s+(?:best\s+|close\s+)?friend(?:'s\s+name)?\s+is|meet\s+my\s+friend)\s+([A-Za-z\u0900-\u097F]+(?:\s+[A-Za-z\u0900-\u097F]+)?)\b""",
            RegexOption.IGNORE_CASE
        )
        val friendMatch = friendRegex.find(clean)
        if (friendMatch != null) {
            val friendName = friendMatch.groupValues[1].trim(' ', '.', '!')
            if (friendName.length in 2..40) {
                memories.add("User's friend is $friendName" to "FACT")
            }
        }

        val namedFriendRegex = Regex(
            """(?:^|\b)(?:(?:i\s+have\s+a\s+|there\s+is\s+a\s+)?friend(?:\s+of\s+mine)?\s+(?:named|called))\s+([A-Za-z\u0900-\u097F]+)\b""",
            RegexOption.IGNORE_CASE
        )
        val namedFriendMatch = namedFriendRegex.find(clean)
        if (namedFriendMatch != null) {
            val friendName = namedFriendMatch.groupValues[1].trim(' ', '.', '!')
            if (friendName.length in 2..40) {
                memories.add("User's friend is $friendName" to "FACT")
            }
        }

        val reverseFriendRegex = Regex(
            """(?:^|\b)([A-Za-z\u0900-\u097F]+)\s+is\s+my\s+(?:best\s+|close\s+)?friend\b""",
            RegexOption.IGNORE_CASE
        )
        val reverseFriendMatch = reverseFriendRegex.find(clean)
        if (reverseFriendMatch != null) {
            val friendName = reverseFriendMatch.groupValues[1].trim(' ', '.', '!')
            val nonNames = setOf("he", "she", "that", "this", "who", "it", "someone")
            if (!nonNames.contains(friendName.lowercase()) && friendName.length in 2..40) {
                memories.add("User's friend is $friendName" to "FACT")
            }
        }

        val relationRegex = Regex(
            """(?:^|\b)(?:my\s+(brother|sister|wife|husband|mother|father|mom|dad|son|daughter|partner|colleague|cousin|roommate)(?:'s\s+name)?\s+is|i\s+have\s+a\s+(brother|sister|son|daughter)\s+(?:named|called))\s+([A-Za-z\u0900-\u097F]+(?:\s+[A-Za-z\u0900-\u097F]+)?)\b""",
            RegexOption.IGNORE_CASE
        )
        val relationMatch = relationRegex.find(clean)
        if (relationMatch != null) {
            val rel = relationMatch.groupValues[1].ifEmpty { relationMatch.groupValues[2] }.lowercase()
            val name = relationMatch.groupValues[3].trim(' ', '.', '!')
            if (name.length in 2..40) {
                memories.add("User's $rel is $name" to "FACT")
            }
        }

        val hindiFriendRegex = Regex("""(?:मेरा दोस्त|मेरी सहेली|मेरा भाई|मेरी बहन|मेरी पत्नी|मेरे पति)\s+([A-Za-z\u0900-\u097F]+)(?:\s+है)?""", RegexOption.IGNORE_CASE)
        val hindiFriendMatch = hindiFriendRegex.find(clean)
        if (hindiFriendMatch != null) {
            val friendName = hindiFriendMatch.groupValues[1].trim(' ', '.', '!')
            if (friendName.length in 2..40) {
                memories.add("User's friend/relation is $friendName" to "FACT")
            }
        }

        // 3. Preferences & Likes/Dislikes
        val favoriteRegex = Regex(
            """(?:^|\b)my\s+(?:favorite|favourite)\s+([a-zA-Z\s]+?)\s+is\s+([^,.;!?]+)""",
            RegexOption.IGNORE_CASE
        )
        val favoriteMatch = favoriteRegex.find(clean)
        if (favoriteMatch != null) {
            val item = favoriteMatch.groupValues[1].trim()
            val value = favoriteMatch.groupValues[2].trim()
            if (item.isNotEmpty() && value.isNotEmpty()) {
                memories.add("User's favorite $item is $value" to "FACT")
            }
        }

        val loveLikeRegex = Regex(
            """(?:^|\b)i\s+(?:really\s+|truly\s+)?(don't\s+like|do\s+not\s+like|dislike|hate|love|like|enjoy|prefer|adore)\s+([^,.;!?]+)""",
            RegexOption.IGNORE_CASE
        )
        val loveLikeMatch = loveLikeRegex.find(clean)
        if (loveLikeMatch != null) {
            val verb = loveLikeMatch.groupValues[1].lowercase()
            val target = loveLikeMatch.groupValues[2].trim()
            val lowerTarget = target.lowercase()
            val ignoredTargets = setOf("you", "it", "this", "that", "talking to you", "chatting", "being here", "her", "him", "them")
            if (!ignoredTargets.contains(lowerTarget) && target.length in 3..60) {
                val statement = when {
                    verb.contains("don't like") || verb.contains("do not like") || verb == "dislike" || verb == "hate" ->
                        "User dislikes $target"
                    verb == "love" || verb == "adore" -> "User loves $target"
                    verb == "like" -> "User likes $target"
                    verb == "enjoy" -> "User enjoys $target"
                    verb == "prefer" -> "User prefers $target"
                    else -> "User $verb $target"
                }
                memories.add(statement to "FACT")
            }
        }

        val hindiPrefRegex = Regex("""(?:मुझे|मेरा पसंदीदा)\s+([^,.;!?]+?)\s+(?:बहुत\s+)?(?:पसंद है|अच्छा लगता है)""", RegexOption.IGNORE_CASE)
        val hindiPrefMatch = hindiPrefRegex.find(clean)
        if (hindiPrefMatch != null) {
            val target = hindiPrefMatch.groupValues[1].trim()
            if (target.length in 2..50) {
                memories.add("User prefers $target" to "FACT")
            }
        }

        // Birthdays & Anniversaries
        val birthdayRegex = Regex(
            """(?:^|\b)(?:my\s+birthday\s+(?:is\s+(?:on\s+)?|falls\s+on\s+)|i\s+was\s+born\s+on\s+)([^,.;!?]+)""",
            RegexOption.IGNORE_CASE
        )
        val birthdayMatch = birthdayRegex.find(clean)
        if (birthdayMatch != null) {
            val date = birthdayMatch.groupValues[1].trim()
            if (date.isNotEmpty()) {
                memories.add("User's birthday is on $date" to "FACT")
            }
        }

        val hindiBirthdayRegex = Regex("""(?:(?:मेरा\s+जन्मदिन|मेरा\s+बर्थडे)\s+([^,.;!?]+?)\s+(?:को\s+है|है))""", RegexOption.IGNORE_CASE)
        val hindiBirthdayMatch = hindiBirthdayRegex.find(clean)
        if (hindiBirthdayMatch != null) {
            val date = hindiBirthdayMatch.groupValues[1].trim()
            if (date.isNotEmpty()) {
                memories.add("User's birthday is on $date" to "FACT")
            }
        }

        val anniversaryRegex = Regex(
            """(?:^|\b)(?:my\s+anniversary\s+(?:is\s+(?:on\s+)?|falls\s+on\s+)|our\s+anniversary\s+(?:is\s+(?:on\s+)?|falls\s+on\s+))([^,.;!?]+)""",
            RegexOption.IGNORE_CASE
        )
        val anniversaryMatch = anniversaryRegex.find(clean)
        if (anniversaryMatch != null) {
            val date = anniversaryMatch.groupValues[1].trim()
            if (date.isNotEmpty()) {
                memories.add("User's anniversary is on $date" to "FACT")
            }
        }

        // 4. Hobbies
        val hobbyRegex = Regex(
            """(?:^|\b)my\s+hobb(?:y\s+is|ies\s+are|ies\s+include)\s+([^,.;!?]+)""",
            RegexOption.IGNORE_CASE
        )
        val hobbyMatch = hobbyRegex.find(clean)
        if (hobbyMatch != null) {
            val hobby = hobbyMatch.groupValues[1].trim()
            if (hobby.isNotEmpty()) {
                memories.add("User's hobby is $hobby" to "FACT")
            }
        }

        val freeTimeRegex = Regex(
            """(?:^|\b)in\s+my\s+(?:free|spare)\s+time\s*,?\s*i\s+(?:like\s+to|love\s+to|enjoy)\s+([^,.;!?]+)""",
            RegexOption.IGNORE_CASE
        )
        val freeTimeMatch = freeTimeRegex.find(clean)
        if (freeTimeMatch != null) {
            val hobby = freeTimeMatch.groupValues[1].trim()
            if (hobby.isNotEmpty()) {
                memories.add("User's hobby is $hobby" to "FACT")
            }
        }

        // 5. Important Events & Past Events
        val eventPastRegex = Regex(
            """(?:^|\b)i\s+(visited|traveled to|travelled to|went to|flew to|moved to|graduated in|graduated from|got married in|got married to|married|celebrated|attended|completed|finished|won|adopted|bought a|bought an|built|worked at|lived in)\s+([^,.;!?]+)""",
            RegexOption.IGNORE_CASE
        )
        val eventPastMatch = eventPastRegex.find(clean)
        if (eventPastMatch != null) {
            val action = eventPastMatch.groupValues[1].trim()
            val details = eventPastMatch.groupValues[2].trim()
            if (details.isNotEmpty()) {
                memories.add("User $action $details" to "FACT")
            }
        }

        val timeEventRegex = Regex(
            """(?:^|\b)(?:last\s+(?:year|summer|winter|spring|fall|autumn|month|week)|in\s+\d{4}|yesterday)\s*,?\s*i\s+([^,.;!?]+)""",
            RegexOption.IGNORE_CASE
        )
        val timeEventMatch = timeEventRegex.find(clean)
        if (timeEventMatch != null) {
            val rest = timeEventMatch.groupValues[1].trim()
            if (rest.isNotEmpty() && !rest.startsWith("am ") && !rest.startsWith("was ")) {
                memories.add("User $rest" to "FACT")
            }
        }

        val hindiPastEventRegex = Regex("""(?:पिछले\s+(?:साल|महीने|हफ्ते)|कल)\s+मैंने\s+([^,.;!?]+)""", RegexOption.IGNORE_CASE)
        val hindiPastMatch = hindiPastEventRegex.find(clean)
        if (hindiPastMatch != null) {
            val details = hindiPastMatch.groupValues[1].trim()
            if (details.isNotEmpty()) {
                memories.add("User past event: $details" to "FACT")
            }
        }

        // 6. Work, Projects, Career, Plans
        val workRegex = Regex(
            """(?:^|\b)i\s+(?:work as|work at|am working as|am working at)\s+([^,.;!?]+)""",
            RegexOption.IGNORE_CASE
        )
        val workMatch = workRegex.find(clean)
        if (workMatch != null) {
            val job = workMatch.groupValues[1].trim()
            if (job.length in 3..60) {
                memories.add("User works as/at $job" to "FACT")
            }
        }

        val projectRegex = Regex(
            """(?:^|\b)i\s+am\s+(?:building|developing|creating|working on)\s+([^,.;!?]+)""",
            RegexOption.IGNORE_CASE
        )
        val projectMatch = projectRegex.find(clean)
        if (projectMatch != null) {
            val proj = projectMatch.groupValues[1].trim()
            if (proj.length in 3..60) {
                memories.add("User is building $proj" to "FACT")
            }
        }

        val planRegex = Regex(
            """(?:^|\b)(?:my plan is\s+(?:to\s+)?|i plan to\s+|i am planning to\s+|i will\s+)([^,.;!?]+)""",
            RegexOption.IGNORE_CASE
        )
        val planMatch = planRegex.find(clean)
        if (planMatch != null) {
            val plan = planMatch.groupValues[1].trim()
            if (plan.length in 3..60) {
                memories.add("User's plan is to $plan" to "PLAN")
            }
        }

        // 7. Recurring Facts (residence, pets, allergies)
        val liveInRegex = Regex("""(?:^|\b)i\s+live\s+in\s+([^,.;!?]+)""", RegexOption.IGNORE_CASE)
        val liveMatch = liveInRegex.find(clean)
        if (liveMatch != null) {
            val place = liveMatch.groupValues[1].trim()
            if (place.length in 2..40) {
                memories.add("User lives in $place" to "FACT")
            }
        }

        val petRegex = Regex("""(?:^|\b)i\s+have\s+a\s+(dog|cat|pet)\s+(?:named|called)\s+([A-Za-z\u0900-\u097F]+)""", RegexOption.IGNORE_CASE)
        val petMatch = petRegex.find(clean)
        if (petMatch != null) {
            val petType = petMatch.groupValues[1].lowercase()
            val petName = petMatch.groupValues[2].trim()
            if (petName.length in 2..30) {
                memories.add("User has a $petType named $petName" to "FACT")
            }
        }

        val allergyRegex = Regex("""(?:^|\b)i\s+am\s+allergic\s+to\s+([^,.;!?]+)""", RegexOption.IGNORE_CASE)
        val allergyMatch = allergyRegex.find(clean)
        if (allergyMatch != null) {
            val allergy = allergyMatch.groupValues[1].trim()
            if (allergy.length in 2..40) {
                memories.add("User is allergic to $allergy" to "FACT")
            }
        }

        return memories
    }

    private suspend fun resolveContradictions(
        newContent: String,
        existing: List<ImportantMemoryEntity>
    ) {
        val lowerNew = newContent.lowercase()

        // 1. User Name contradiction: "User's name is John" / "My name is John"
        if (lowerNew.startsWith("user's name is ") || lowerNew.startsWith("my name is ") || lowerNew.startsWith("my name's ")) {
            val nameEntities = existing.filter {
                it.content.startsWith("User's name is ", ignoreCase = true) ||
                it.content.startsWith("My name is ", ignoreCase = true) ||
                it.content.startsWith("My name's ", ignoreCase = true) ||
                it.content.startsWith("Name: ", ignoreCase = true)
            }
            for (old in nameEntities) {
                memoryDao.deleteById(old.id)
            }
            return
        }

        // 2. Favorite item contradiction: "User's favorite color is green" vs "User's favorite color is blue" OR "my favorite color is..."
        val favMatch = Regex("""(?:user's|my)\s+favorite\s+([a-z]+)\s+is""", RegexOption.IGNORE_CASE).find(newContent)
        if (favMatch != null) {
            val itemType = favMatch.groupValues[1].lowercase()
            val oldFavs = existing.filter {
                it.content.lowercase().contains("favorite $itemType is")
            }
            for (old in oldFavs) {
                memoryDao.deleteById(old.id)
            }
            return
        }

        // 3. Birthday & Anniversary updates
        if (lowerNew.contains("birthday is on ") || lowerNew.contains("anniversary is on ")) {
            val type = if (lowerNew.contains("birthday")) "birthday" else "anniversary"
            val oldEntries = existing.filter { it.content.lowercase().contains(type) }
            for (old in oldEntries) {
                memoryDao.deleteById(old.id)
            }
            return
        }

        // 4. Work/Company contradiction: "User works as/at Google" vs older employer
        if (lowerNew.startsWith("user works as/at ") || lowerNew.startsWith("user works at ") || lowerNew.startsWith("i work at ") || lowerNew.startsWith("i work as ")) {
            val workEntities = existing.filter {
                it.content.startsWith("User works as/at ", ignoreCase = true) ||
                it.content.startsWith("User works at ", ignoreCase = true) ||
                it.content.startsWith("User works as ", ignoreCase = true) ||
                it.content.startsWith("I work at ", ignoreCase = true) ||
                it.content.startsWith("I work as ", ignoreCase = true)
            }
            for (old in workEntities) {
                memoryDao.deleteById(old.id)
            }
            return
        }

        // 5. Friend contradiction for best friend
        if (lowerNew.contains("best friend is ")) {
            val oldBest = existing.filter { it.content.lowercase().contains("best friend is ") }
            for (old in oldBest) {
                memoryDao.deleteById(old.id)
            }
            return
        }

        // 6. Residence contradiction: "User lives in New York" vs older "User lives in Chicago"
        if (lowerNew.startsWith("user lives in ") || lowerNew.startsWith("i live in ")) {
            val oldRes = existing.filter {
                it.content.startsWith("User lives in ", ignoreCase = true) ||
                it.content.startsWith("I live in ", ignoreCase = true)
            }
            for (old in oldRes) {
                memoryDao.deleteById(old.id)
            }
            return
        }
    }

    private fun isSensitiveOrSecret(text: String): Boolean {
        val lower = text.lowercase()
        if (lower.contains("aiza") || lower.contains("sk-") || lower.contains("ghp_") || lower.contains("bearer ")) return true
        if (lower.contains("password") || lower.contains("passcode") || lower.contains("pin code") || lower.contains("credentials")) return true
        if (lower.contains("secret key") || lower.contains("api key") || lower.contains("access token") || lower.contains("private key") || lower.contains("auth token")) return true
        if (lower.contains("credit card") || lower.contains("cvv") || lower.contains("otp") || lower.contains("ssn")) return true
        return false
    }

    private fun isGreetingOrFiller(text: String): Boolean {
        val lower = text.lowercase().trim(' ', '!', '.', ',', '?', ';', ':', '-', '—')
        val greetings = setOf(
            "hi", "hello", "hey", "good morning", "good afternoon", "good evening", "good night",
            "how are you", "how are you doing", "what's up", "what are you doing", "who are you",
            "bye", "goodbye", "see you", "see you later", "take care",
            "thank you", "thanks", "thanks a lot", "thank you so much",
            "ok", "okay", "yes", "no", "yeah", "yup", "nope", "sure", "alright", "fine",
            "cool", "nice", "awesome", "great", "wow", "haha", "lol",
            "can you hear me", "are you there", "testing", "test", "testing 1 2 3",
            "hello queen", "hi queen", "hey queen", "good morning queen", "how are you queen",
            "hello rani", "hi rani", "hey rani", "good morning rani", "how are you rani",
            "nice to meet you", "pleased to meet you", "nice talking to you",
            "tell me a joke", "what can you do", "help me",
            "नमस्ते", "नमस्ते रानी", "नमस्कार", "कैसी हो", "कैसी हो रानी", "कैसी हैं आप",
            "क्या हाल है", "धन्यवाद", "अलविदा", "बाय", "ठीक है", "हाँ", "नहीं", "सुनो रानी", "बोलो रानी"
        )
        if (greetings.contains(lower)) return true

        val greetingPattern = Regex(
            """^(?:hi|hello|hey|good\s+(?:morning|afternoon|evening|night)|namaste|नमस्ते|नमस्कार)\s*(?:queen|rani|there|ss)?$""",
            RegexOption.IGNORE_CASE
        )
        if (greetingPattern.matches(lower)) return true

        val conversationalSmallTalk = Regex(
            """^(?:how\s+are\s+you|how\s+are\s+you\s+doing|how's\s+it\s+going|what's\s+up|what\s+are\s+you\s+doing)\s*(?:today|queen|rani)?\??$""",
            RegexOption.IGNORE_CASE
        )
        if (conversationalSmallTalk.matches(lower)) return true

        // Question without personal information (e.g. "What is the capital of France?", "What time is it?")
        if (text.trim().endsWith("?") && !hasPersonalIndicators(lower)) {
            return true
        }

        // Uncertain statements
        if (lower.startsWith("maybe ") || lower.startsWith("perhaps ") || lower.startsWith("i guess ") || lower.startsWith("probably ") || lower.startsWith("शायद ")) {
            return true
        }

        return false
    }

    private fun hasPersonalIndicators(lower: String): Boolean {
        return lower.contains("my ") || lower.contains("i am ") || lower.contains("i'm ") ||
               lower.contains("i have ") || lower.contains("i love ") || lower.contains("i like ") ||
               lower.contains("i don't like") || lower.contains("i dislike") || lower.contains("i hate") ||
               lower.contains("i prefer ") || lower.contains("i visited ") || lower.contains("i went ") ||
               lower.contains("मेरा ") || lower.contains("मेरी ") || lower.contains("मुझे ") || lower.contains("मैंने ")
    }

    private fun determineCategory(text: String): String {
        val lower = text.lowercase()
        return when {
            lower.contains("plan") || lower.contains("प्लान") -> "PLAN"
            lower.contains("task") || lower.contains("काम") || lower.contains("remind") -> "TASK"
            else -> "FACT"
        }
    }
}
