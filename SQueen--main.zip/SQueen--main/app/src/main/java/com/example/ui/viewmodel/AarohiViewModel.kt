package com.example.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.camera.core.CameraSelector
import com.example.BuildConfig
import com.example.audio.HindiTtsManager
import com.example.data.model.AssistantState
import com.example.data.model.CredentialValidationState
import com.example.data.model.VoiceOption
import com.example.data.model.ConversationMessageEntity
import com.example.data.model.ImportantMemoryEntity
import com.example.data.repository.AccessTokenRepository
import com.example.data.repository.BackupExportResult
import com.example.data.repository.BackupRestoreResult
import com.example.data.repository.GeminiValidationRepository
import com.example.data.repository.MemoryRepository
import com.example.data.repository.StorageStats
import com.example.command.CommandExecutor
import com.example.command.ExecutionResult
import com.example.command.PendingCall
import com.example.data.storage.CredentialStorage
import com.example.live.GeminiLiveSessionManager
import com.example.security.AppIntegrityManager
import com.example.service.QueenVoiceForegroundService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AarohiViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        const val TESTING_WINDOW_DURATION_MS = CredentialStorage.TESTING_WINDOW_DURATION_MS

        @Volatile
        private var sharedStorage: CredentialStorage? = null

        /**
         * Checks if the 2-hour temporary testing window is active for DEBUG builds.
         * Enforces server-verified tokens for RELEASE builds.
         */
        fun isTemporaryTestingAccessActive(): Boolean {
            if (!BuildConfig.DEBUG) return false
            return sharedStorage?.isTemporaryTestingAccessActive() ?: true
        }
    }

    private val storage = CredentialStorage(application)
    private val tokenRepo = AccessTokenRepository()
    private val geminiRepo = GeminiValidationRepository()
    private val liveManager = GeminiLiveSessionManager()
    private val hindiTtsManager = HindiTtsManager(application)
    private val memoryRepo = MemoryRepository(application)
    private val commandExecutor = CommandExecutor(application)

    private val _pendingCall = MutableStateFlow<PendingCall?>(null)
    val pendingCall: StateFlow<PendingCall?> = _pendingCall.asStateFlow()

    private val _permissionRequestEvent = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val permissionRequestEvent: SharedFlow<String> = _permissionRequestEvent.asSharedFlow()

    val conversationHistory: Flow<List<ConversationMessageEntity>> = memoryRepo.conversationHistory
    val importantMemories: Flow<List<ImportantMemoryEntity>> = memoryRepo.importantMemories

    private val _storageStats = MutableStateFlow(StorageStats(0.0, 0.0, 0.0, 0, 0))
    val storageStats: StateFlow<StorageStats> = _storageStats.asStateFlow()

    val assistantState: StateFlow<AssistantState> = liveManager.assistantState
    val amplitude: StateFlow<Float> = liveManager.amplitude

    private val _tamperAlert = MutableStateFlow<String?>(null)
    val tamperAlert: StateFlow<String?> = _tamperAlert.asStateFlow()

    private val _geminiValidationState =
        MutableStateFlow<CredentialValidationState>(CredentialValidationState.Unchecked)
    val geminiValidationState: StateFlow<CredentialValidationState> =
        _geminiValidationState.asStateFlow()

    private val _tokenValidationState =
        MutableStateFlow<CredentialValidationState>(CredentialValidationState.Unchecked)
    val tokenValidationState: StateFlow<CredentialValidationState> =
        _tokenValidationState.asStateFlow()

    private val _userName = MutableStateFlow(storage.getUserName())
    val userName: StateFlow<String> = _userName.asStateFlow()

    private val _selectedVoiceId = MutableStateFlow(storage.getVoice())
    val selectedVoiceId: StateFlow<String> = _selectedVoiceId.asStateFlow()

    private val _rawGeminiApiKey = MutableStateFlow(storage.getGeminiApiKey())
    val rawGeminiApiKey: StateFlow<String> = _rawGeminiApiKey.asStateFlow()

    private val _rawAppAccessToken = MutableStateFlow(storage.getAppAccessToken())
    val rawAppAccessToken: StateFlow<String> = _rawAppAccessToken.asStateFlow()

    private val _savedGeminiKeyMasked = MutableStateFlow(
        CredentialStorage.maskSecret(storage.getGeminiApiKey())
    )
    val savedGeminiKeyMasked: StateFlow<String> = _savedGeminiKeyMasked.asStateFlow()

    private val _savedTokenMasked = MutableStateFlow(
        CredentialStorage.maskSecret(storage.getAppAccessToken())
    )
    val savedTokenMasked: StateFlow<String> = _savedTokenMasked.asStateFlow()

    // Both Gemini API Key and Queen App Access Token must be verified to start
    val isSetupComplete: StateFlow<Boolean> = combine(
        _geminiValidationState,
        _tokenValidationState
    ) { gemini, token ->
        gemini is CredentialValidationState.Valid &&
            (token is CredentialValidationState.Valid || isTemporaryTestingAccessActive())
    }.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    private val _isCameraVisionActive = MutableStateFlow(false)
    val isCameraVisionActive: StateFlow<Boolean> = _isCameraVisionActive.asStateFlow()

    private val _isVisionTransmitting = MutableStateFlow(false)
    val isVisionTransmitting: StateFlow<Boolean> = _isVisionTransmitting.asStateFlow()

    private val _cameraLensFacing = MutableStateFlow(CameraSelector.LENS_FACING_BACK)
    val cameraLensFacing: StateFlow<Int> = _cameraLensFacing.asStateFlow()

    fun setCameraVisionActive(active: Boolean) {
        _isCameraVisionActive.value = active
        if (!active) {
            _isVisionTransmitting.value = false
        } else {
            // If live voice session is not active yet, start it seamlessly if credentials are ready
            if (!liveManager.isSessionActive() && !assistantState.value.isActive && isSetupComplete.value) {
                startSession()
            }
        }
    }

    fun isLiveSessionReadyForVision(): Boolean {
        val state = assistantState.value
        return liveManager.isSessionActive() && (state is AssistantState.Listening || state is AssistantState.Speaking)
    }

    fun toggleCameraLens() {
        _cameraLensFacing.value = if (_cameraLensFacing.value == CameraSelector.LENS_FACING_BACK) {
            CameraSelector.LENS_FACING_FRONT
        } else {
            CameraSelector.LENS_FACING_BACK
        }
    }

    fun sendCameraVisionFrame(jpegBytes: ByteArray): Boolean {
        if (!_isCameraVisionActive.value || !isLiveSessionReadyForVision()) return false
        val sent = liveManager.sendRealtimeImage(jpegBytes)
        if (sent) {
            _isVisionTransmitting.value = true
        }
        return sent
    }

    init {
        sharedStorage = storage
        checkSecurityIntegrity()
        validateExistingCredentials()
        refreshStorageStats()

        QueenVoiceForegroundService.onStopRequested = {
            stopSession()
        }
        viewModelScope.launch {
            assistantState.collect { state ->
                if (!state.isActive && QueenVoiceForegroundService.isServiceRunning) {
                    QueenVoiceForegroundService.stop(storage.appContext)
                }
            }
        }
    }

    fun hasGeminiKeyConfigured(): Boolean = storage.hasGeminiApiKey()

    fun hasTokenConfigured(): Boolean = storage.hasAppAccessToken()

    fun getRawGeminiApiKey(): String = _rawGeminiApiKey.value

    fun getRawAppAccessToken(): String = _rawAppAccessToken.value

    fun validateExistingCredentials() {
        val apiKey = storage.getGeminiApiKey()
        val token = storage.getAppAccessToken()

        if (apiKey.isNotBlank()) {
            validateGeminiKey(apiKey)
        } else {
            _geminiValidationState.value = CredentialValidationState.Invalid("Gemini API Key is not configured.")
        }

        if (isTemporaryTestingAccessActive()) {
            _tokenValidationState.value = CredentialValidationState.Valid
        } else if (token.isNotBlank()) {
            validateToken(token)
        } else {
            _tokenValidationState.value = CredentialValidationState.Unchecked
        }
    }

    fun saveAndValidateGeminiKey(key: String) {
        val trimmed = key.trim()
        if (trimmed.isEmpty()) {
            _geminiValidationState.value = CredentialValidationState.Invalid("API Key cannot be empty.")
            return
        }
        storage.saveGeminiApiKey(trimmed)
        _rawGeminiApiKey.value = trimmed
        _savedGeminiKeyMasked.value = CredentialStorage.maskSecret(trimmed)
        validateGeminiKey(trimmed)
    }

    fun deleteGeminiKey() {
        storage.deleteGeminiApiKey()
        _rawGeminiApiKey.value = ""
        _savedGeminiKeyMasked.value = "Not Configured"
        _geminiValidationState.value = CredentialValidationState.Invalid("Gemini API Key is not configured.")
    }

    private fun validateGeminiKey(apiKey: String) {
        viewModelScope.launch {
            _geminiValidationState.value = CredentialValidationState.Validating
            val result = geminiRepo.validateKey(apiKey)
            _geminiValidationState.value = result
        }
    }

    fun saveAndValidateToken(token: String) {
        val normalized = token.trim().uppercase()
        if (normalized.isEmpty()) {
            _tokenValidationState.value = CredentialValidationState.Invalid("Token cannot be empty.")
            return
        }
        storage.saveAppAccessToken(normalized)
        _rawAppAccessToken.value = normalized
        _savedTokenMasked.value = CredentialStorage.maskSecret(normalized)
        validateToken(normalized)
    }

    fun deleteToken() {
        storage.deleteAppAccessToken()
        _rawAppAccessToken.value = ""
        _savedTokenMasked.value = "Not Configured"
        _tokenValidationState.value = CredentialValidationState.Unchecked
    }

    private fun validateToken(token: String) {
        val normalized = token.trim().uppercase()
        viewModelScope.launch {
            _tokenValidationState.value = CredentialValidationState.Validating
            val deviceId = storage.getOrCreateDeviceId()
            val endpoint = storage.getFirebaseAuthEndpoint()
            val result = tokenRepo.verifyToken(normalized, deviceId, endpoint, storage.appContext)
            _tokenValidationState.value = result
        }
    }

    fun saveUserName(name: String) {
        val trimmed = name.trim()
        storage.saveUserName(trimmed)
        _userName.value = trimmed
    }

    fun selectVoice(voiceId: String) {
        val trimmed = voiceId.trim()
        if (trimmed.isNotEmpty()) {
            storage.saveVoice(trimmed)
            _selectedVoiceId.value = trimmed
        }
    }

    fun dismissTamperAlert() {
        _tamperAlert.value = null
    }

    /**
     * Practical Android defense-in-depth integrity check.
     * Blocks protected features on rooted, hooked, or debugged environments.
     */
    fun checkSecurityIntegrity(): Boolean {
        val status = AppIntegrityManager.checkIntegrity(storage.appContext)
        if (status.isTampered) {
            _tamperAlert.value = status.reason
            liveManager.reportError("Security Integrity Alert: ${status.reason}")
            return false
        }
        return true
    }

    /**
     * Start or stop the Gemini Live voice session.
     * Returns true if session was started or stopped successfully,
     * or false if credentials are not configured, not valid, or integrity checks fail.
     */
    fun onStartTapped(): Boolean {
        if (assistantState.value.isActive) {
            stopSession()
            return true
        }

        if (!checkSecurityIntegrity()) {
            return false
        }

        val key = storage.getGeminiApiKey()
        val token = storage.getAppAccessToken().trim().uppercase()
        val isTokenSatisfied = _tokenValidationState.value is CredentialValidationState.Valid || isTemporaryTestingAccessActive()

        if (key.isBlank() || _geminiValidationState.value !is CredentialValidationState.Valid || !isTokenSatisfied) {
            val errorMsg = if (key.isBlank() || _geminiValidationState.value !is CredentialValidationState.Valid) {
                "Verified Gemini API Key is required. Configure in Settings -> API & Key."
            } else {
                "Verified Access Token is required. Configure in Settings -> API & Key."
            }
            liveManager.reportError(errorMsg)
            validateExistingCredentials()
            return false
        }

        val savedVoiceId = storage.getVoice().ifBlank { _selectedVoiceId.value }
        val voice = VoiceOption.getGeminiVoiceName(savedVoiceId)
        val user = _userName.value
        QueenVoiceForegroundService.start(storage.appContext)
        viewModelScope.launch {
            val memories = memoryRepo.getActiveMemoriesForPrompt()
            liveManager.startSession(
                scope = viewModelScope,
                apiKey = key,
                voiceName = voice,
                userName = user,
                accessToken = token,
                activeMemories = memories,
                allowTemporaryTesting = isTemporaryTestingAccessActive(),
                context = storage.appContext,
                onTranscriptReceived = { role, text ->
                    viewModelScope.launch {
                        memoryRepo.saveConversationMessage(role, text)
                        refreshStorageStats()
                        if (role == "user") {
                            handleVoiceOrTextCommand(text)
                        } else if (role == "queen") {
                            handleQueenResponse(text)
                        }
                    }
                }
            )
        }
        return true
    }

    /**
     * Protected startSession call. Requires verified access token, valid API key,
     * and passing security integrity checks.
     */
    fun startSession(): Boolean {
        if (assistantState.value.isActive) return true

        if (!checkSecurityIntegrity()) {
            return false
        }

        val key = storage.getGeminiApiKey()
        val token = storage.getAppAccessToken().trim().uppercase()
        val isTokenSatisfied = _tokenValidationState.value is CredentialValidationState.Valid || isTemporaryTestingAccessActive()

        if (key.isBlank() || _geminiValidationState.value !is CredentialValidationState.Valid || !isTokenSatisfied) {
            val errorMsg = if (key.isBlank() || _geminiValidationState.value !is CredentialValidationState.Valid) {
                "Verified Gemini API Key is required. Configure in Settings -> API & Key."
            } else {
                "Verified Access Token is required. Configure in Settings -> API & Key."
            }
            liveManager.reportError(errorMsg)
            validateExistingCredentials()
            return false
        }

        val savedVoiceId = storage.getVoice().ifBlank { _selectedVoiceId.value }
        val voice = VoiceOption.getGeminiVoiceName(savedVoiceId)
        val user = _userName.value
        QueenVoiceForegroundService.start(storage.appContext)
        viewModelScope.launch {
            val memories = memoryRepo.getActiveMemoriesForPrompt()
            liveManager.startSession(
                scope = viewModelScope,
                apiKey = key,
                voiceName = voice,
                userName = user,
                accessToken = token,
                activeMemories = memories,
                allowTemporaryTesting = isTemporaryTestingAccessActive(),
                context = storage.appContext,
                onTranscriptReceived = { role, text ->
                    viewModelScope.launch {
                        memoryRepo.saveConversationMessage(role, text)
                        refreshStorageStats()
                        if (role == "user") {
                            handleVoiceOrTextCommand(text)
                        } else if (role == "queen") {
                            handleQueenResponse(text)
                        }
                    }
                }
            )
        }
        return true
    }

    fun sendUserTextMessage(text: String): Boolean {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return false
        val sent = liveManager.sendTextPrompt(trimmed)
        viewModelScope.launch {
            memoryRepo.saveConversationMessage("user", trimmed)
            refreshStorageStats()
            handleVoiceOrTextCommand(trimmed)
        }
        return sent
    }

    // --- Outgoing Call & Command Execution ---

    fun getPendingCall(): PendingCall? = commandExecutor.getPendingCall()

    fun processCommand(input: String): ExecutionResult {
        val result = commandExecutor.processInput(input)
        _pendingCall.value = commandExecutor.getPendingCall()
        return result
    }

    fun executePendingCall(): ExecutionResult {
        val result = commandExecutor.confirmAndExecuteCall()
        _pendingCall.value = commandExecutor.getPendingCall()
        when (result) {
            is ExecutionResult.CallInitiated -> {
                val prompt = "[System: Outgoing call to ${result.contactName} (${result.phoneNumber}) has been launched via system dialer. Tell the user warmly: '${result.contactName} को कॉल मिला रही हूँ।']"
                liveManager.sendTextPrompt(prompt)
            }
            is ExecutionResult.PermissionRequired -> {
                requestRuntimePermission(result.permission)
                val permName = if (result.permission.contains("CONTACTS")) "Contacts" else "Phone Calls"
                val prompt = "[System: $permName permission is required to place the call. A permission prompt has been displayed. Tell the user to allow $permName permission.]"
                liveManager.sendTextPrompt(prompt)
            }
            is ExecutionResult.Error -> {
                liveManager.reportError(result.message)
                val prompt = "[System: Call failed: ${result.message}. Honestly tell the user that the call could not be placed.]"
                liveManager.sendTextPrompt(prompt)
            }
            else -> {}
        }
        return result
    }

    fun cancelPendingCall(): ExecutionResult {
        val result = commandExecutor.cancelCall()
        _pendingCall.value = commandExecutor.getPendingCall()
        return result
    }

    fun requestCallContact(name: String): ExecutionResult {
        val result = commandExecutor.initiateContactLookup(name)
        _pendingCall.value = commandExecutor.getPendingCall()
        return result
    }

    fun requestRuntimePermission(permission: String) {
        _permissionRequestEvent.tryEmit(permission)
    }

    fun onPermissionResult(permission: String, isGranted: Boolean) {
        if (isGranted) {
            if (permission == android.Manifest.permission.CALL_PHONE && commandExecutor.hasPendingCall()) {
                executePendingCall()
            }
        } else {
            if (permission == android.Manifest.permission.CALL_PHONE && commandExecutor.hasPendingCall()) {
                val prompt = "[System: Phone call permission was denied by user. Tell the user clearly: 'फ़ोन कॉल की अनुमति नहीं दी गई, इसलिए कॉल नहीं लगाई जा सकी।']"
                liveManager.sendTextPrompt(prompt)
            }
        }
    }

    private fun handleQueenResponse(text: String) {
        val trimmed = text.trim()
        if (commandExecutor.hasPendingCall()) {
            val lower = trimmed.lowercase()
            val isConfirmTag = trimmed.contains("[CALL_CONFIRM]", ignoreCase = true)
            val isVerbalConfirm = lower.contains("calling") || lower.contains("कॉल मिला रही हूँ") ||
                    lower.contains("कॉल लगा रही हूँ") || lower.contains("कॉल कर रही हूँ") ||
                    lower.contains("dialing")
            val isCancelTag = trimmed.contains("[CALL_CANCEL]", ignoreCase = true)
            val isVerbalCancel = lower.contains("कॉल रद्द") || lower.contains("cancelled") || lower.contains("not calling")

            if (isConfirmTag || isVerbalConfirm) {
                executePendingCall()
                return
            } else if (isCancelTag || isVerbalCancel) {
                cancelPendingCall()
                val prompt = "[System: The phone call was cancelled. Acknowledge warmly: 'ठीक है, कॉल रद्द कर दी गई।']"
                liveManager.sendTextPrompt(prompt)
                return
            }
        }

        // Check if Queen requested a contact call: [CALL_REQUEST: <name>]
        val callRequestRegex = Regex("""\[CALL_REQUEST:\s*([^\]]+)\]""", RegexOption.IGNORE_CASE)
        val match = callRequestRegex.find(trimmed)
        if (match != null) {
            val contactName = match.groupValues[1].trim()
            if (contactName.isNotEmpty()) {
                requestCallContact(contactName)
                return
            }
        }

        // Check if Queen issued an accessibility or app control tag
        if (trimmed.contains("[OPEN_APP:", ignoreCase = true) ||
            trimmed.contains("[CLICK_ELEMENT:", ignoreCase = true) ||
            trimmed.contains("[TYPE_TEXT:", ignoreCase = true) ||
            trimmed.contains("[SCROLL:", ignoreCase = true) ||
            trimmed.contains("[GO_BACK]", ignoreCase = true) ||
            trimmed.contains("[GO_HOME]", ignoreCase = true) ||
            trimmed.contains("[READ_SCREEN]", ignoreCase = true)
        ) {
            val result = commandExecutor.processInput(trimmed)
            when (result) {
                is ExecutionResult.ActionExecuted -> {
                    if (result.actionName == "Read Screen") {
                        liveManager.interruptPlayback()
                    }
                    val prompt = if (result.actionName == "Read Screen") {
                        "[System: The user asked what they are watching or what is on their screen. The device accessibility service successfully inspected the active screen and extracted the following verified visible content:\n${result.details ?: result.messageEn}\nUsing ONLY this verified content, tell the user directly, warmly, and concisely what video or content is playing/visible (speak the actual video title and channel/app name). Never invent a different title. If in Hindi, speak natural Hindi.]"
                    } else {
                        "[System: Action '${result.actionName}' succeeded on device: ${result.messageEn}. Let the user know warmly that it is completed.]"
                    }
                    val sent = liveManager.sendTextPrompt(prompt)
                    Log.d("AarohiViewModel", "Queen tag action '${result.actionName}' executed. DeliveredToLive=$sent")
                }
                is ExecutionResult.ActionFailed -> {
                    if (result.actionName == "Read Screen") {
                        liveManager.interruptPlayback()
                    }
                    val prompt = if (result.actionName == "Read Screen") {
                        "[System: Screen reading could not retrieve text: ${result.messageHi} (${result.reason}). Tell the user honestly and warmly: '${result.messageHi}' and do NOT guess or make up any video title or screen content.]"
                    } else {
                        "[System: Action '${result.actionName}' failed on device: ${result.messageEn}. Inform the user honestly without pretending it succeeded.]"
                    }
                    val sent = liveManager.sendTextPrompt(prompt)
                    Log.w("AarohiViewModel", "Queen tag action '${result.actionName}' failed: ${result.reason}. DeliveredWarning=$sent")
                }
                else -> {}
            }
        }
    }

    private fun handleVoiceOrTextCommand(text: String) {
        val result = processCommand(text)
        when (result) {
            is ExecutionResult.ConfirmationRequested -> {
                val prompt = "[System: The user asked to call '${result.contactName}'. Before placing any call, speak the matched contact name clearly and ask the user for confirmation: 'क्या आप ${result.contactName} को कॉल करना चाहते हैं?' or 'Do you want me to call ${result.contactName}?']"
                liveManager.sendTextPrompt(prompt)
            }
            is ExecutionResult.CallInitiated -> {
                val prompt = "[System: Outgoing call to ${result.contactName} (${result.phoneNumber}) has been launched via system dialer. Tell the user warmly: '${result.contactName} को कॉल मिला रही हूँ।']"
                liveManager.sendTextPrompt(prompt)
            }
            is ExecutionResult.CallCancelled -> {
                val prompt = "[System: The phone call was cancelled by user. Acknowledge warmly: 'ठीक है, कॉल रद्द कर दी गई।']"
                liveManager.sendTextPrompt(prompt)
            }
            is ExecutionResult.ContactNotFound -> {
                val prompt = "[System: No contact named '${result.query}' was found in user's contacts. Tell the user gently: 'मुझे आपके संपर्कों में ${result.query} नाम का कोई नंबर नहीं मिला।']"
                liveManager.sendTextPrompt(prompt)
            }
            is ExecutionResult.AmbiguousContacts -> {
                val names = result.matches.joinToString(", ") { it.name }
                val prompt = "[System: Found multiple contacts for '${result.query}': $names. Ask the user which one they would like to call.]"
                liveManager.sendTextPrompt(prompt)
            }
            is ExecutionResult.PermissionRequired -> {
                requestRuntimePermission(result.permission)
                val permName = if (result.permission.contains("CONTACTS")) "Contacts" else "Phone Calls"
                val prompt = "[System: $permName permission is required to proceed. A system permission dialog has been requested. Tell the user warmly: 'कॉल करने के लिए $permName की अनुमति दें।']"
                liveManager.sendTextPrompt(prompt)
            }
            is ExecutionResult.ActionExecuted -> {
                if (result.actionName == "Read Screen") {
                    liveManager.interruptPlayback()
                }
                val prompt = if (result.actionName == "Read Screen") {
                    "[System: The user asked what they are watching or what is on their screen. The device accessibility service successfully inspected the active screen and extracted the following verified visible content:\n${result.details ?: result.messageEn}\nUsing ONLY this verified content, tell the user directly, warmly, and concisely what video or content is playing/visible (speak the actual video title and channel/app name). Never invent a different title. If in Hindi, speak natural Hindi.]"
                } else {
                    "[System: Action '${result.actionName}' succeeded on device: ${result.messageEn}. Let the user know warmly that it is completed.]"
                }
                val sent = liveManager.sendTextPrompt(prompt)
                Log.d("AarohiViewModel", "User voice action '${result.actionName}' executed. DeliveredToLive=$sent")
            }
            is ExecutionResult.ActionFailed -> {
                if (result.actionName == "Read Screen") {
                    liveManager.interruptPlayback()
                }
                val prompt = if (result.actionName == "Read Screen") {
                    "[System: Screen reading could not retrieve text: ${result.messageHi} (${result.reason}). Tell the user honestly and warmly: '${result.messageHi}' and do NOT guess or make up any video title or screen content.]"
                } else {
                    "[System: Action '${result.actionName}' failed on device: ${result.messageEn}. Inform the user honestly without pretending it succeeded.]"
                }
                val sent = liveManager.sendTextPrompt(prompt)
                Log.w("AarohiViewModel", "User voice action '${result.actionName}' failed: ${result.reason}. DeliveredWarning=$sent")
            }
            is ExecutionResult.Error -> {
                liveManager.reportError(result.message)
                val prompt = "[System: Operation failed: ${result.message}. Honestly tell the user that the action could not be performed.]"
                liveManager.sendTextPrompt(prompt)
            }
            ExecutionResult.Ignored -> {
                // Not a command, handled normally
            }
        }
    }

    // --- Storage & Memory Management Functions ---

    fun refreshStorageStats() {
        viewModelScope.launch {
            _storageStats.value = memoryRepo.getStorageStats()
        }
    }

    fun clearConversationHistory(onCompleted: (Int) -> Unit = {}) {
        viewModelScope.launch {
            val count = memoryRepo.clearConversationHistory()
            refreshStorageStats()
            onCompleted(count)
        }
    }

    fun deleteImportantMemories(onCompleted: (Int) -> Unit = {}) {
        viewModelScope.launch {
            val count = memoryRepo.clearImportantMemories()
            refreshStorageStats()
            onCompleted(count)
        }
    }

    fun deleteSingleMemory(id: Long) {
        viewModelScope.launch {
            memoryRepo.deleteMemory(id)
            refreshStorageStats()
        }
    }

    fun clearCache(onCompleted: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            val success = memoryRepo.clearCache()
            refreshStorageStats()
            onCompleted(success)
        }
    }

    fun createBackup(onResult: (BackupExportResult) -> Unit) {
        viewModelScope.launch {
            val result = memoryRepo.exportBackup()
            refreshStorageStats()
            onResult(result)
        }
    }

    fun restoreBackup(jsonString: String, onResult: (BackupRestoreResult) -> Unit) {
        viewModelScope.launch {
            val result = memoryRepo.restoreBackup(jsonString)
            refreshStorageStats()
            onResult(result)
        }
    }

    fun saveManualMemory(content: String, category: String = "FACT", onResult: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            val success = memoryRepo.saveImportantMemory(content, category)
            refreshStorageStats()
            onResult(success)
        }
    }

    /**
     * One-shot Gemini voice test (Queen Hindi phrase).
     * Strictly requires verified access token, valid API key, and passing security integrity checks.
     */
    fun testGeminiVoice() {
        if (liveManager.isVoiceTestRunning()) return

        if (!checkSecurityIntegrity()) {
            return
        }

        val key = storage.getGeminiApiKey()
        val token = storage.getAppAccessToken()

        if (key.isBlank() || _geminiValidationState.value !is CredentialValidationState.Valid) {
            _geminiValidationState.value =
                CredentialValidationState.Invalid("Gemini API Key is missing or unverified.")
            liveManager.reportError("Gemini API Key is missing or unverified. Please configure it in Settings -> API & Key.")
            return
        }

        val isTokenSatisfied = _tokenValidationState.value is CredentialValidationState.Valid || isTemporaryTestingAccessActive()
        if (!isTokenSatisfied) {
            _tokenValidationState.value =
                CredentialValidationState.Invalid("Queen Access Token is missing or unverified.")
            liveManager.reportError("Queen Access Token must be verified to test voice. Configure in Settings -> API & Key.")
            return
        }

        val savedVoiceId = storage.getVoice().ifBlank { _selectedVoiceId.value }
        val voice = VoiceOption.getGeminiVoiceName(savedVoiceId)
        liveManager.startVoiceTest(
            scope = viewModelScope,
            apiKey = key,
            voiceName = voice,
            accessToken = token,
            allowTemporaryTesting = isTemporaryTestingAccessActive(),
            context = storage.appContext
        )
    }

    /**
     * Preview a specific voice tone using Gemini Live.
     */
    fun previewVoice(voiceId: String) {
        if (liveManager.isVoiceTestRunning()) return

        if (!checkSecurityIntegrity()) {
            return
        }

        val key = storage.getGeminiApiKey()
        val token = storage.getAppAccessToken()

        if (key.isBlank() || _geminiValidationState.value !is CredentialValidationState.Valid) {
            _geminiValidationState.value =
                CredentialValidationState.Invalid("Gemini API Key is missing or unverified.")
            liveManager.reportError("Gemini API Key is missing or unverified. Please configure it in Settings -> API & Key.")
            return
        }

        val isTokenSatisfied = _tokenValidationState.value is CredentialValidationState.Valid || isTemporaryTestingAccessActive()
        if (!isTokenSatisfied) {
            _tokenValidationState.value =
                CredentialValidationState.Invalid("Queen Access Token is missing or unverified.")
            liveManager.reportError("Queen Access Token must be verified to test voice. Configure in Settings -> API & Key.")
            return
        }

        val voice = VoiceOption.getGeminiVoiceName(voiceId)
        liveManager.startVoiceTest(
            scope = viewModelScope,
            apiKey = key,
            voiceName = voice,
            accessToken = token,
            allowTemporaryTesting = isTemporaryTestingAccessActive(),
            context = storage.appContext
        )
    }

    fun speakHindiPhrase() {
        hindiTtsManager.speakJiBoliye()
    }

    fun stopSession() {
        QueenVoiceForegroundService.stop(storage.appContext)
        hindiTtsManager.stop()
        liveManager.stopSession()
        commandExecutor.clearPendingCall()
        _pendingCall.value = null
    }

    override fun onCleared() {
        super.onCleared()
        QueenVoiceForegroundService.stop(storage.appContext)
        hindiTtsManager.shutdown()
        liveManager.stopSession()
        commandExecutor.clearPendingCall()
        _pendingCall.value = null
    }
}
