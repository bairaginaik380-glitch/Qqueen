package com.example.service

import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.example.accessibility.OpenRingAccessibilityService

/**
 * Queen AI Accessibility Service (integrated with OpenRing framework).
 * Extends OpenRingAccessibilityService to provide unified screen automation and inspection.
 */
class JarvisAccessibilityService : OpenRingAccessibilityService() {

    companion object {
        private const val TAG = "JarvisAccessibility"

        @Volatile
        var isServiceRunning: Boolean = false
            internal set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceRunning = true
        Log.d(TAG, "JarvisAccessibilityService connected (OpenRing active)")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        super.onAccessibilityEvent(event)
        if (event == null) return
    }

    override fun onInterrupt() {
        super.onInterrupt()
        Log.d(TAG, "JarvisAccessibilityService interrupted")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        isServiceRunning = false
        Log.d(TAG, "JarvisAccessibilityService unbound")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        isServiceRunning = false
        Log.d(TAG, "JarvisAccessibilityService destroyed")
        super.onDestroy()
    }
}
