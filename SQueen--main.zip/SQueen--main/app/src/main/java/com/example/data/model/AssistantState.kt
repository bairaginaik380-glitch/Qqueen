package com.example.data.model

sealed interface AssistantState {
    data object Idle : AssistantState
    data object Connecting : AssistantState
    data object Listening : AssistantState
    data object Speaking : AssistantState
    data object Interrupted : AssistantState
    data object Reconnecting : AssistantState
    data class Error(val message: String) : AssistantState

    val label: String
        get() = when (this) {
            is Idle -> "Ready"
            is Connecting -> "Connecting..."
            is Listening -> "Listening to you..."
            is Speaking -> "Aarohi is speaking..."
            is Interrupted -> "Interrupted"
            is Reconnecting -> "Reconnecting..."
            is Error -> "Error: $message"
        }

    val isActive: Boolean
        get() = this is Connecting || this is Listening || this is Speaking || this is Interrupted || this is Reconnecting
}
