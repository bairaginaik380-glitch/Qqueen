package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.QueenBackground
import com.example.ui.theme.QueenBorder
import com.example.ui.theme.QueenBorderGold
import com.example.ui.theme.QueenError
import com.example.ui.theme.QueenGoldBright
import com.example.ui.theme.QueenGoldSoft
import com.example.ui.theme.QueenSurface
import com.example.ui.theme.QueenSurfaceVariant
import com.example.ui.theme.QueenTextMuted
import com.example.ui.theme.QueenTextPrimary
import com.example.ui.theme.QueenTextSecondary
import com.example.ui.viewmodel.AarohiViewModel
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StorageMemoryScreen(
    viewModel: AarohiViewModel,
    onNavigateBack: () -> Unit
) {
    BackHandler { onNavigateBack() }

    val storageStats by viewModel.storageStats.collectAsState()
    val importantMemoriesList by viewModel.importantMemories.collectAsState(initial = emptyList())
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val scrollState = rememberScrollState()

    var showClearHistoryDialog by remember { mutableStateOf(false) }
    var showDeleteMemoriesDialog by remember { mutableStateOf(false) }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var showAddMemoryDialog by remember { mutableStateOf(false) }
    var addMemoryContent by remember { mutableStateOf("") }
    var addMemoryCategory by remember { mutableStateOf("FACT") }
    var restoreInputText by remember { mutableStateOf("") }
    var restoreErrorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        viewModel.refreshStorageStats()
    }

    Scaffold(
        containerColor = QueenBackground,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Storage & Memory",
                        fontWeight = FontWeight.Bold,
                        color = QueenTextPrimary,
                        fontSize = 20.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("storage_memory_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Settings",
                            tint = QueenTextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = QueenBackground
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Main Card Container
            Surface(
                color = QueenSurface,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorderGold),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("storage_history_section")
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Header
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            color = QueenSurfaceVariant,
                            shape = CircleShape,
                            border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorderGold),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Storage,
                                    contentDescription = null,
                                    tint = QueenGoldBright,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Column {
                            Text(
                                text = "On-Device Storage",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = QueenTextPrimary
                            )
                            Text(
                                text = "Local conversation history and long-term memory",
                                fontSize = 12.sp,
                                color = QueenTextMuted
                            )
                        }
                    }

                    // Live Storage Used in MB Badge
                    Surface(
                        color = QueenSurfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "Storage Used",
                                    fontSize = 12.sp,
                                    color = QueenTextSecondary
                                )
                                Text(
                                    text = storageStats.formattedTotalMb,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = QueenGoldBright,
                                    modifier = Modifier.testTag("storage_used_text")
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "History: ${storageStats.historyCount} turns",
                                    fontSize = 12.sp,
                                    color = QueenTextMuted
                                )
                                Text(
                                    text = "Memories: ${storageStats.memoryCount} saved",
                                    fontSize = 12.sp,
                                    color = QueenGoldSoft
                                )
                                Text(
                                    text = "Cache: ${storageStats.formattedCacheMb}",
                                    fontSize = 11.sp,
                                    color = QueenTextMuted
                                )
                            }
                        }
                    }

                    // Privacy Note (Requirement 5)
                    Text(
                        text = "Privacy Notice: All conversation history and important memories are saved strictly on this device. No cloud syncing or private uploads. Note: Uninstalling the app or clearing app storage will erase local records.",
                        fontSize = 11.sp,
                        color = QueenTextMuted,
                        lineHeight = 15.sp
                    )

                    // Backup and Restore Controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.createBackup { result ->
                                    scope.launch {
                                        snackbarHostState.showSnackbar(result.message)
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = QueenGoldSoft,
                                contentColor = QueenBackground
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("backup_storage_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Backup,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Backup",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                restoreErrorMessage = null
                                val backupDir = File(context.filesDir, "backups")
                                val latest = backupDir.listFiles()
                                    ?.filter { it.extension == "json" }
                                    ?.maxByOrNull { it.lastModified() }
                                restoreInputText = latest?.readText() ?: ""
                                showRestoreDialog = true
                            },
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorderGold),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = QueenGoldBright),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("restore_storage_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Restore,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Restore",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    // Clear Conversation History & Clear Cache Controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showClearHistoryDialog = true },
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorder),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = QueenTextPrimary),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("clear_history_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = QueenTextSecondary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Clear History", fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.clearCache { success ->
                                    scope.launch {
                                        snackbarHostState.showSnackbar(
                                            if (success) "Cache cleared successfully."
                                            else "Cache is already empty."
                                        )
                                    }
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorder),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = QueenTextPrimary),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("clear_cache_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.CleaningServices,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = QueenTextSecondary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Clear Cache", fontSize = 12.sp)
                        }
                    }

                    // Separate, clearly labeled option to delete important memories
                    OutlinedButton(
                        onClick = { showDeleteMemoriesDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, QueenError.copy(alpha = 0.7f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = QueenError),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("delete_important_memories_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteForever,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = QueenError
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Delete Important Memories",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            // Saved Important Long-Term Memories Section
            Surface(
                color = QueenSurface,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorderGold),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("saved_memories_section")
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                color = QueenSurfaceVariant,
                                shape = CircleShape,
                                border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorderGold),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Bookmark,
                                        contentDescription = null,
                                        tint = QueenGoldBright,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Column {
                                Text(
                                    text = "Long-Term Memories",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = QueenTextPrimary
                                )
                                Text(
                                    text = "${importantMemoriesList.size} stored on device",
                                    fontSize = 11.sp,
                                    color = QueenTextMuted
                                )
                            }
                        }

                        Button(
                            onClick = {
                                addMemoryContent = ""
                                addMemoryCategory = "FACT"
                                showAddMemoryDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = QueenGoldSoft,
                                contentColor = QueenBackground
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("add_memory_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    if (importantMemoriesList.isEmpty()) {
                        Text(
                            text = "No long-term memories saved yet. Ask Rani 'याद रखना...' during voice chat, or tap Add above.",
                            fontSize = 12.sp,
                            color = QueenTextMuted,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            importantMemoriesList.forEach { memory ->
                                Surface(
                                    color = QueenSurfaceVariant,
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorder),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Surface(
                                                color = when (memory.category) {
                                                    "PLAN" -> Color(0x334CAF50)
                                                    "TASK" -> Color(0x332196F3)
                                                    else -> Color(0x33FFC107)
                                                },
                                                shape = RoundedCornerShape(4.dp),
                                                modifier = Modifier.padding(bottom = 4.dp)
                                            ) {
                                                Text(
                                                    text = memory.category,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = when (memory.category) {
                                                        "PLAN" -> Color(0xFF81C784)
                                                        "TASK" -> Color(0xFF64B5F6)
                                                        else -> QueenGoldBright
                                                    },
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                            Text(
                                                text = memory.content,
                                                fontSize = 13.sp,
                                                color = QueenTextPrimary,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }

                                        IconButton(
                                            onClick = {
                                                viewModel.deleteSingleMemory(memory.id)
                                                scope.launch {
                                                    snackbarHostState.showSnackbar("Deleted memory.")
                                                }
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.DeleteOutline,
                                                contentDescription = "Delete Memory",
                                                tint = QueenError.copy(alpha = 0.8f),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Dialog: Clear Conversation History Confirmation
    if (showClearHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showClearHistoryDialog = false },
            title = {
                Text(
                    text = "Clear Conversation History?",
                    color = QueenGoldBright,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "This will delete all saved regular voice conversation transcripts on this device.\n\nYour Important Long-Term Memories (facts, tasks, and plans) will NOT be deleted.",
                    color = QueenTextPrimary,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showClearHistoryDialog = false
                        viewModel.clearConversationHistory { deletedCount ->
                            scope.launch {
                                snackbarHostState.showSnackbar("Cleared $deletedCount conversation history records.")
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = QueenGoldSoft,
                        contentColor = QueenBackground
                    ),
                    modifier = Modifier.testTag("confirm_clear_history_button")
                ) {
                    Text("Clear History", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearHistoryDialog = false }) {
                    Text("Cancel", color = QueenTextMuted)
                }
            },
            containerColor = QueenSurface,
            tonalElevation = 6.dp
        )
    }

    // Dialog: Delete Important Memories Confirmation
    if (showDeleteMemoriesDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteMemoriesDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.WarningAmber, contentDescription = null, tint = QueenError)
                    Text(
                        text = "Delete Important Memories?",
                        color = QueenError,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Text(
                    text = "Warning: This will permanently delete all facts, tasks, and plans that Queen/Rani has saved.\n\nRani will forget all stored personal details. This action cannot be undone.",
                    color = QueenTextPrimary,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteMemoriesDialog = false
                        viewModel.deleteImportantMemories { count ->
                            scope.launch {
                                snackbarHostState.showSnackbar("Deleted $count important memories.")
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = QueenError,
                        contentColor = Color.White
                    ),
                    modifier = Modifier.testTag("confirm_delete_memories_button")
                ) {
                    Text("Delete Forever", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteMemoriesDialog = false }) {
                    Text("Cancel", color = QueenTextMuted)
                }
            },
            containerColor = QueenSurface,
            tonalElevation = 6.dp
        )
    }

    // Dialog: Restore Backup Confirmation & Input
    if (showRestoreDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = {
                Text(
                    text = "Restore Memory & History",
                    color = QueenGoldBright,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Paste or inspect your Queen AI JSON backup content below. Data will be validated safely before restoring.",
                        color = QueenTextSecondary,
                        fontSize = 12.sp
                    )

                    OutlinedTextField(
                        value = restoreInputText,
                        onValueChange = {
                            restoreInputText = it
                            restoreErrorMessage = null
                        },
                        label = { Text("Backup JSON Content") },
                        placeholder = { Text("{\"app\": \"Queen AI\", ...}") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .testTag("restore_json_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = QueenSurfaceVariant,
                            unfocusedContainerColor = QueenSurfaceVariant,
                            focusedBorderColor = QueenGoldSoft,
                            unfocusedBorderColor = QueenBorder,
                            focusedTextColor = QueenTextPrimary,
                            unfocusedTextColor = QueenTextPrimary
                        )
                    )

                    if (restoreErrorMessage != null) {
                        Text(
                            text = restoreErrorMessage ?: "",
                            color = QueenError,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.restoreBackup(restoreInputText) { result ->
                            if (result.success) {
                                showRestoreDialog = false
                                scope.launch {
                                    snackbarHostState.showSnackbar(result.message)
                                }
                            } else {
                                restoreErrorMessage = result.message
                            }
                        }
                    },
                    enabled = restoreInputText.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = QueenGoldSoft,
                        contentColor = QueenBackground
                    ),
                    modifier = Modifier.testTag("confirm_restore_button")
                ) {
                    Text("Validate & Restore", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreDialog = false }) {
                    Text("Cancel", color = QueenTextMuted)
                }
            },
            containerColor = QueenSurface,
            tonalElevation = 6.dp
        )
    }

    // Dialog: Add Manual Memory
    if (showAddMemoryDialog) {
        AlertDialog(
            onDismissRequest = { showAddMemoryDialog = false },
            title = {
                Text(
                    text = "Add Long-Term Memory",
                    color = QueenGoldBright,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Enter a fact, task, or plan for Rani to remember permanently.",
                        color = QueenTextSecondary,
                        fontSize = 12.sp
                    )

                    // Category selection chips
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("FACT", "TASK", "PLAN").forEach { cat ->
                            Surface(
                                color = if (addMemoryCategory == cat) QueenGoldSoft else QueenSurfaceVariant,
                                shape = RoundedCornerShape(6.dp),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (addMemoryCategory == cat) QueenGoldBright else QueenBorder
                                ),
                                modifier = Modifier.clip(RoundedCornerShape(6.dp))
                            ) {
                                TextButton(
                                    onClick = { addMemoryCategory = cat },
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text(
                                        text = cat,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (addMemoryCategory == cat) QueenBackground else QueenTextPrimary
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = addMemoryContent,
                        onValueChange = { addMemoryContent = it },
                        label = { Text("Memory Content") },
                        placeholder = { Text("e.g. My sister's birthday is on Oct 25") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .testTag("add_memory_content_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = QueenSurfaceVariant,
                            unfocusedContainerColor = QueenSurfaceVariant,
                            focusedBorderColor = QueenGoldSoft,
                            unfocusedBorderColor = QueenBorder,
                            focusedTextColor = QueenTextPrimary,
                            unfocusedTextColor = QueenTextPrimary
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val text = addMemoryContent.trim()
                        if (text.length >= 3) {
                            viewModel.saveManualMemory(text, addMemoryCategory) { success ->
                                showAddMemoryDialog = false
                                scope.launch {
                                    snackbarHostState.showSnackbar(
                                        if (success) "Memory saved successfully." else "Failed to save memory."
                                    )
                                }
                            }
                        }
                    },
                    enabled = addMemoryContent.trim().length >= 3,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = QueenGoldSoft,
                        contentColor = QueenBackground
                    ),
                    modifier = Modifier.testTag("confirm_add_memory_button")
                ) {
                    Text("Save Memory", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddMemoryDialog = false }) {
                    Text("Cancel", color = QueenTextMuted)
                }
            },
            containerColor = QueenSurface,
            tonalElevation = 6.dp
        )
    }
}
