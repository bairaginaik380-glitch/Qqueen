package com.example.accessibility

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.example.accessibility.model.ViewNode

/**
 * OpenRing ViewTreeParser extracts accessible elements such as text,
 * content descriptions, IDs, and bounding boxes from the active window hierarchy.
 */
class ViewTreeParser(
    private val maxDepth: Int = 30,
    private val maxNodes: Int = 250
) {

    /**
     * Parses an AccessibilityNodeInfo hierarchy into a ViewNode tree.
     */
    fun parse(root: AccessibilityNodeInfo?): ViewNode? {
        if (root == null) return null
        var nodeCount = 0

        fun traverse(info: AccessibilityNodeInfo, depth: Int): ViewNode? {
            if (depth > maxDepth || nodeCount >= maxNodes) return null
            nodeCount++

            val bounds = Rect()
            info.getBoundsInScreen(bounds)

            val node = ViewNode(
                id = info.viewIdResourceName,
                text = info.text?.toString(),
                contentDescription = info.contentDescription?.toString(),
                className = info.className?.toString(),
                packageName = info.packageName?.toString(),
                bounds = bounds,
                isClickable = info.isClickable,
                isEditable = info.isEditable,
                isScrollable = info.isScrollable,
                isCheckable = info.isCheckable,
                isChecked = info.isChecked,
                isEnabled = info.isEnabled,
                isFocused = info.isFocused,
                isVisibleToUser = info.isVisibleToUser,
                nodeInfo = info
            )

            val childCount = info.childCount
            for (i in 0 until childCount) {
                val childInfo = try {
                    info.getChild(i)
                } catch (e: Exception) {
                    null
                } ?: continue

                val childNode = traverse(childInfo, depth + 1)
                if (childNode != null) {
                    node.children.add(childNode)
                }
            }

            return node
        }

        return try {
            traverse(root, 0)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Flattens the hierarchy into a list of non-empty, actionable or informative nodes.
     */
    fun flatten(root: ViewNode?): List<ViewNode> {
        if (root == null) return emptyList()
        val list = mutableListOf<ViewNode>()

        fun collect(node: ViewNode) {
            list.add(node)
            for (child in node.children) {
                collect(child)
            }
        }

        collect(root)
        return list
    }

    /**
     * Finds nodes that are interactive or display meaningful text.
     */
    fun findMeaningfulNodes(root: ViewNode?): List<ViewNode> {
        return flatten(root).filter { node ->
            val hasContent = !node.text.isNullOrBlank() || !node.contentDescription.isNullOrBlank()
            val isOnScreen = node.isVisibleToUser || (!node.bounds.isEmpty && node.bounds.width() > 0 && node.bounds.height() > 0)
            isOnScreen && (node.isClickable || node.isEditable || hasContent)
        }
    }

    /**
     * Searches for a node matching a search query.
     * Prioritizes exact matches, then clickable matches, then partial matches.
     */
    fun findNode(root: ViewNode?, query: String): ViewNode? {
        if (root == null || query.isBlank()) return null
        val all = flatten(root).filter { it.isVisibleToUser }

        // 1. Exact match on clickable elements
        all.firstOrNull { it.isClickable && it.matchesExact(query) }?.let { return it }

        // 2. Exact match on any element
        all.firstOrNull { it.matchesExact(query) }?.let { return it }

        // 3. Clickable elements containing the query
        all.firstOrNull { it.isClickable && it.matchesQuery(query) }?.let { return it }

        // 4. Any element containing the query
        all.firstOrNull { it.matchesQuery(query) }?.let { return it }

        // 5. Match by Resource ID substring
        val cleanQuery = query.trim().lowercase()
        all.firstOrNull { node ->
            node.id?.substringAfterLast('/')?.lowercase()?.contains(cleanQuery) == true
        }?.let { return it }

        return null
    }

    /**
     * Finds the currently focused or first available editable input field.
     */
    fun findEditableNode(root: ViewNode?, target: String? = null): ViewNode? {
        if (root == null) return null
        val all = flatten(root).filter { it.isVisibleToUser && it.isEditable }

        if (!target.isNullOrBlank()) {
            all.firstOrNull { it.matchesQuery(target) }?.let { return it }
        }

        // Return focused editable node if present, or first editable node
        return all.firstOrNull { it.isFocused } ?: all.firstOrNull()
    }

    /**
     * Generates a concise human-readable textual summary of the visible screen for the AI.
     * Prioritizes video titles (e.g. YouTube video_title/watch_title), prominent headings,
     * and visible text nodes.
     */
    fun formatScreenSummary(root: ViewNode?): String {
        if (root == null) return "Screen is empty or not accessible."
        val meaningful = findMeaningfulNodes(root)
        if (meaningful.isEmpty()) return "No accessible text or interactive controls visible."

        val pkg = meaningful.firstOrNull()?.packageName
        val textNodeCount = meaningful.count { !it.text.isNullOrBlank() }
        android.util.Log.d(
            "ViewTreeParser",
            "formatScreenSummary: totalMeaningful=${meaningful.size}, textNodes=$textNodeCount, appPkg=${pkg ?: "unknown"}"
        )

        val sb = StringBuilder()
        if (!pkg.isNullOrBlank()) {
            val appLabel = when {
                pkg.contains("youtube", ignoreCase = true) -> "YouTube ($pkg)"
                pkg.contains("whatsapp", ignoreCase = true) -> "WhatsApp ($pkg)"
                pkg.contains("chrome", ignoreCase = true) -> "Chrome ($pkg)"
                else -> pkg
            }
            sb.append("Current App: ").append(appLabel).append("\n")
        }

        // Identify primary title or video title if available
        val primaryTitleNode = meaningful.firstOrNull { node ->
            val idLower = node.id?.lowercase() ?: ""
            val isTitleId = idLower.contains("video_title") ||
                idLower.contains("watch_title") ||
                idLower.contains("video_headline") ||
                (idLower.contains("title") && !idLower.contains("action_bar") && !idLower.contains("subtitle"))
            isTitleId && (!node.text.isNullOrBlank() || !node.contentDescription.isNullOrBlank())
        }

        if (primaryTitleNode != null) {
            val titleText = primaryTitleNode.text?.takeIf { it.isNotBlank() }
                ?: primaryTitleNode.contentDescription
            if (!titleText.isNullOrBlank()) {
                sb.append("Primary Title / Video Title: \"").append(titleText).append("\"\n")
            }
        }

        // Prioritize: 1) Primary title node, 2) Other titles, 3) Nodes with text, 4) Nodes with content descriptions
        val sortedNodes = meaningful.sortedWith(
            compareByDescending<ViewNode> { it === primaryTitleNode }
                .thenByDescending {
                    val idLower = it.id?.lowercase() ?: ""
                    idLower.contains("title") || idLower.contains("headline")
                }
                .thenByDescending { !it.text.isNullOrBlank() }
                .thenByDescending { !it.contentDescription.isNullOrBlank() }
        )

        sb.append("Visible Elements:\n")
        sortedNodes.take(50).forEachIndexed { index, node ->
            val idLower = node.id?.lowercase() ?: ""
            val isVideoTitle = idLower.contains("video_title") || idLower.contains("watch_title")
            val isTitle = isVideoTitle || idLower.contains("title") || idLower.contains("headline")
            val type = when {
                isVideoTitle -> "Video Title"
                isTitle -> "Title"
                else -> node.className?.substringAfterLast('.') ?: "View"
            }
            val label = node.displayLabel
            val interactive = buildList {
                if (node.isClickable) add("clickable")
                if (node.isEditable) add("editable")
                if (node.isScrollable) add("scrollable")
                if (node.isChecked) add("checked")
            }.joinToString(", ")

            sb.append("${index + 1}. [$type] \"$label\"")
            if (!node.contentDescription.isNullOrBlank() &&
                node.contentDescription != node.text &&
                node.contentDescription != label
            ) {
                sb.append(" (desc: \"${node.contentDescription}\")")
            }
            if (interactive.isNotEmpty()) {
                sb.append(" ($interactive)")
            }
            sb.append("\n")
        }

        return sb.toString().trim()
    }
}
