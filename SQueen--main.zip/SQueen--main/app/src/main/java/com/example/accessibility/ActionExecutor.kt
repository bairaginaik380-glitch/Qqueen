package com.example.accessibility

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import com.example.accessibility.model.ActionResult
import com.example.accessibility.model.ErrorCode
import com.example.accessibility.model.ViewNode

/**
 * OpenRing ActionExecutor performs supported accessibility actions such as
 * clicking elements, entering text, swiping, long-pressing, Back, and Home.
 */
class ActionExecutor(
    private val parser: ViewTreeParser = ViewTreeParser()
) {

    companion object {
        private const val TAG = "ActionExecutor"
    }

    private fun getService(): OpenRingAccessibilityService? {
        return OpenRingAccessibilityService.instance
    }

    /**
     * Finds an accessible element matching target query and clicks it.
     */
    fun click(target: String): ActionResult {
        val service = getService()
            ?: return ActionResult.failure(
                "Accessibility service is not running. Please enable it in Settings.",
                ErrorCode.SERVICE_NOT_CONNECTED
            )

        val rootInfo = service.getRootNodeSafe()
            ?: return ActionResult.failure(
                "Cannot read screen content. Screen may be locked or secure.",
                ErrorCode.ACTION_FAILED
            )

        val rootNode = parser.parse(rootInfo)
        val matchedNode = parser.findNode(rootNode, target)
            ?: return ActionResult.failure(
                "Element '$target' not found on current screen.",
                ErrorCode.NODE_NOT_FOUND
            )

        // 1. First attempt native accessibility ACTION_CLICK on the node or its clickable ancestors
        var current: AccessibilityNodeInfo? = matchedNode.nodeInfo
        var clicked = false
        while (current != null) {
            if (current.isClickable) {
                clicked = current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                if (clicked) break
            }
            current = current.parent
        }

        if (clicked) {
            return ActionResult.success("Clicked '${matchedNode.displayLabel}'.", matchedNode)
        }

        // 2. Fallback to physical coordinate tap gesture
        val bounds = matchedNode.bounds
        if (!bounds.isEmpty) {
            val tapSuccess = service.dispatchTap(matchedNode.centerX, matchedNode.centerY)
            if (tapSuccess) {
                return ActionResult.success("Tapped '${matchedNode.displayLabel}' at (${matchedNode.centerX.toInt()}, ${matchedNode.centerY.toInt()}).", matchedNode)
            }
        }

        return ActionResult.failure("Failed to click '${matchedNode.displayLabel}'.", ErrorCode.ACTION_FAILED)
    }

    /**
     * Clicks at specific screen coordinates (X, Y).
     */
    fun clickAt(x: Float, y: Float): ActionResult {
        val service = getService()
            ?: return ActionResult.failure(
                "Accessibility service is not running.",
                ErrorCode.SERVICE_NOT_CONNECTED
            )

        val success = service.dispatchTap(x, y)
        return if (success) {
            ActionResult.success("Tapped screen at ($x, $y).")
        } else {
            ActionResult.failure("Failed to dispatch tap gesture at ($x, $y).", ErrorCode.ACTION_FAILED)
        }
    }

    /**
     * Types text into a targeted input field or the currently active/focused editable node.
     */
    fun typeText(text: String, target: String? = null): ActionResult {
        val service = getService()
            ?: return ActionResult.failure(
                "Accessibility service is not running.",
                ErrorCode.SERVICE_NOT_CONNECTED
            )

        val rootInfo = service.getRootNodeSafe()
            ?: return ActionResult.failure(
                "Cannot read screen content.",
                ErrorCode.ACTION_FAILED
            )

        val rootNode = parser.parse(rootInfo)
        val editableNode = parser.findEditableNode(rootNode, target)
            ?: return ActionResult.failure(
                if (target != null) "Input field '$target' not found." else "No editable text field found on screen.",
                ErrorCode.NODE_NOT_FOUND
            )

        val info = editableNode.nodeInfo
            ?: return ActionResult.failure("Input node handle is invalid.", ErrorCode.ACTION_FAILED)

        // Try setting text via bundle arguments
        val arguments = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val setSuccess = info.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)

        return if (setSuccess) {
            ActionResult.success("Entered text into '${editableNode.displayLabel}'.", editableNode)
        } else {
            // Focus and retry
            info.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val retry = info.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            if (retry) {
                ActionResult.success("Focused and entered text into '${editableNode.displayLabel}'.", editableNode)
            } else {
                ActionResult.failure("Failed to set text on '${editableNode.displayLabel}'.", ErrorCode.ACTION_FAILED)
            }
        }
    }

    /**
     * Performs a scroll or swipe gesture in the specified direction.
     * Supported directions: "down", "up", "left", "right".
     */
    fun scroll(direction: String): ActionResult {
        val service = getService()
            ?: return ActionResult.failure(
                "Accessibility service is not running.",
                ErrorCode.SERVICE_NOT_CONNECTED
            )

        val dir = direction.trim().lowercase()

        // Attempt Accessibility ACTION_SCROLL_FORWARD / BACKWARD on scrollable node if available
        val rootInfo = service.getRootNodeSafe()
        val rootNode = parser.parse(rootInfo)
        val scrollable = parser.flatten(rootNode).firstOrNull { it.isVisibleToUser && it.isScrollable }

        if (scrollable?.nodeInfo != null) {
            val action = if (dir == "down" || dir == "right") {
                AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            } else {
                AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            }
            if (scrollable.nodeInfo.performAction(action)) {
                return ActionResult.success("Scrolled $dir on '${scrollable.displayLabel}'.")
            }
        }

        // Fallback to center-screen swipe gesture
        val metrics = android.content.res.Resources.getSystem().displayMetrics
        val width = metrics.widthPixels.toFloat()
        val height = metrics.heightPixels.toFloat()

        val startX: Float
        val startY: Float
        val endX: Float
        val endY: Float

        when (dir) {
            "down", "scroll down" -> {
                startX = width * 0.5f
                startY = height * 0.75f
                endX = width * 0.5f
                endY = height * 0.25f
            }
            "up", "scroll up" -> {
                startX = width * 0.5f
                startY = height * 0.25f
                endX = width * 0.5f
                endY = height * 0.75f
            }
            "left", "scroll left" -> {
                startX = width * 0.8f
                startY = height * 0.5f
                endX = width * 0.2f
                endY = height * 0.5f
            }
            "right", "scroll right" -> {
                startX = width * 0.2f
                startY = height * 0.5f
                endX = width * 0.8f
                endY = height * 0.5f
            }
            else -> {
                return ActionResult.failure("Unsupported scroll direction: '$direction'.", ErrorCode.UNSUPPORTED_ACTION)
            }
        }

        val success = service.dispatchSwipe(startX, startY, endX, endY, 350L)
        return if (success) {
            ActionResult.success("Scrolled $dir.")
        } else {
            ActionResult.failure("Failed to scroll $dir.", ErrorCode.ACTION_FAILED)
        }
    }

    /**
     * Long-presses an element matching target query.
     */
    fun longPress(target: String): ActionResult {
        val service = getService()
            ?: return ActionResult.failure(
                "Accessibility service is not running.",
                ErrorCode.SERVICE_NOT_CONNECTED
            )

        val rootInfo = service.getRootNodeSafe()
            ?: return ActionResult.failure("Cannot read screen content.", ErrorCode.ACTION_FAILED)

        val rootNode = parser.parse(rootInfo)
        val matched = parser.findNode(rootNode, target)
            ?: return ActionResult.failure("Element '$target' not found.", ErrorCode.NODE_NOT_FOUND)

        val performed = matched.nodeInfo?.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK) ?: false
        if (performed) {
            return ActionResult.success("Long-pressed '${matched.displayLabel}'.", matched)
        }

        val success = service.dispatchLongPress(matched.centerX, matched.centerY)
        return if (success) {
            ActionResult.success("Long-pressed '${matched.displayLabel}'.", matched)
        } else {
            ActionResult.failure("Failed to long-press '${matched.displayLabel}'.", ErrorCode.ACTION_FAILED)
        }
    }

    /**
     * Navigates back via system global action.
     */
    fun pressBack(): ActionResult {
        val service = getService()
            ?: return ActionResult.failure("Accessibility service is not running.", ErrorCode.SERVICE_NOT_CONNECTED)

        val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
        return if (success) ActionResult.success("Navigated back.")
        else ActionResult.failure("Failed to navigate back.", ErrorCode.ACTION_FAILED)
    }

    /**
     * Navigates home via system global action.
     */
    fun pressHome(): ActionResult {
        val service = getService()
            ?: return ActionResult.failure("Accessibility service is not running.", ErrorCode.SERVICE_NOT_CONNECTED)

        val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
        return if (success) ActionResult.success("Navigated to Home screen.")
        else ActionResult.failure("Failed to navigate to Home.", ErrorCode.ACTION_FAILED)
    }

    /**
     * Opens system notification shade.
     */
    fun openNotifications(): ActionResult {
        val service = getService()
            ?: return ActionResult.failure("Accessibility service is not running.", ErrorCode.SERVICE_NOT_CONNECTED)

        val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
        return if (success) ActionResult.success("Opened notifications shade.")
        else ActionResult.failure("Failed to open notifications.", ErrorCode.ACTION_FAILED)
    }

    /**
     * Opens system quick settings panel.
     */
    fun openQuickSettings(): ActionResult {
        val service = getService()
            ?: return ActionResult.failure("Accessibility service is not running.", ErrorCode.SERVICE_NOT_CONNECTED)

        val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
        return if (success) ActionResult.success("Opened Quick Settings.")
        else ActionResult.failure("Failed to open Quick Settings.", ErrorCode.ACTION_FAILED)
    }

    /**
     * Extracts a textual summary of visible accessible UI elements.
     * Categorizes outcomes into distinct states:
     * - Accessibility service unavailable (SERVICE_NOT_CONNECTED)
     * - Active window/root unavailable (ACTION_FAILED)
     * - Parsing error (ACTION_FAILED)
     * - Window accessible but no readable text/title (NODE_NOT_FOUND, data="NO_ACCESSIBLE_TEXT")
     * - Success with validated, meaningful screen content
     */
    fun readScreen(): ActionResult {
        Log.d(TAG, "readScreen invoked. Checking accessibility service...")
        val service = getService()
        if (service == null) {
            Log.w(TAG, "readScreen failed: Accessibility service is not running")
            return ActionResult.failure(
                "Accessibility service is not running. Please enable Queen AI in Settings -> Accessibility.",
                ErrorCode.SERVICE_NOT_CONNECTED
            )
        }

        val rootInfo = service.getRootNodeSafe()
        if (rootInfo == null) {
            Log.w(TAG, "readScreen failed: Root accessibility node is null (screen locked, secure, or no active window)")
            return ActionResult.failure(
                "Active window or screen content is unavailable. Screen may be locked or off.",
                ErrorCode.ACTION_FAILED
            )
        }

        val rootNode = try {
            parser.parse(rootInfo)
        } catch (e: Exception) {
            Log.e(TAG, "readScreen failed: Exception during tree parsing: ${e.message}")
            null
        }

        if (rootNode == null) {
            Log.w(TAG, "readScreen failed: Tree parsing returned null")
            return ActionResult.failure("Screen content could not be parsed.", ErrorCode.ACTION_FAILED)
        }

        val meaningful = parser.findMeaningfulNodes(rootNode)
        val textNodes = meaningful.filter { !it.text.isNullOrBlank() || !it.contentDescription.isNullOrBlank() }
        if (textNodes.isEmpty()) {
            Log.w(TAG, "readScreen: Window accessible but 0 readable text nodes found")
            return ActionResult.failure(
                "No readable text or titles found on current screen.",
                ErrorCode.NODE_NOT_FOUND,
                data = "NO_ACCESSIBLE_TEXT"
            )
        }

        val summary = parser.formatScreenSummary(rootNode)
        if (summary.isBlank() || summary == "Screen is empty or not accessible." || summary == "No accessible text or interactive controls visible.") {
            Log.w(TAG, "readScreen: Summary formatting produced no accessible text")
            return ActionResult.failure(
                "No readable text or titles found on current screen.",
                ErrorCode.NODE_NOT_FOUND,
                data = "NO_ACCESSIBLE_TEXT"
            )
        }

        val totalNodes = parser.flatten(rootNode).size
        Log.d(
            TAG,
            "readScreen success: totalNodes=$totalNodes, meaningful=${meaningful.size}, textNodes=${textNodes.size}, summaryLength=${summary.length}"
        )
        return ActionResult.success("Screen content retrieved.", summary)
    }
}
