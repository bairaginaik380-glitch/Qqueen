package com.example.accessibility.model

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

/**
 * OpenRing ViewNode representing an accessible element in the current UI hierarchy.
 */
data class ViewNode(
    val id: String? = null,
    val text: String? = null,
    val contentDescription: String? = null,
    val className: String? = null,
    val packageName: String? = null,
    val bounds: Rect = Rect(),
    val isClickable: Boolean = false,
    val isEditable: Boolean = false,
    val isScrollable: Boolean = false,
    val isCheckable: Boolean = false,
    val isChecked: Boolean = false,
    val isEnabled: Boolean = true,
    val isFocused: Boolean = false,
    val isVisibleToUser: Boolean = true,
    val children: MutableList<ViewNode> = mutableListOf(),
    @Transient val nodeInfo: AccessibilityNodeInfo? = null
) {
    /**
     * Best human-readable representation of this node.
     */
    val displayLabel: String
        get() = text?.takeIf { it.isNotBlank() }
            ?: contentDescription?.takeIf { it.isNotBlank() }
            ?: id?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
            ?: className?.substringAfterLast('.')
            ?: "Element"

    /**
     * Matches the node against a search query by text, content description, or resource ID.
     */
    fun matchesQuery(query: String): Boolean {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return false
        if (text?.lowercase()?.contains(q) == true) return true
        if (contentDescription?.lowercase()?.contains(q) == true) return true
        if (id?.lowercase()?.contains(q) == true) return true
        return false
    }

    /**
     * Exact match against text or content description.
     */
    fun matchesExact(query: String): Boolean {
        val q = query.trim()
        if (q.isEmpty()) return false
        if (text?.equals(q, ignoreCase = true) == true) return true
        if (contentDescription?.equals(q, ignoreCase = true) == true) return true
        return false
    }

    /**
     * Center X coordinate for touch dispatch.
     */
    val centerX: Float
        get() = bounds.exactCenterX()

    /**
     * Center Y coordinate for touch dispatch.
     */
    val centerY: Float
        get() = bounds.exactCenterY()
}
