package com.example.accessibility

import android.content.Context
import com.example.accessibility.model.ActionResult
import com.example.accessibility.model.ErrorCode

/**
 * OpenRing ToolDispatcher orchestrates accessibility actions and intent routing
 * for Queen AI's assistant command pipeline.
 */
open class ToolDispatcher(
    private val actionExecutor: ActionExecutor = ActionExecutor(),
    private val intentRouter: IntentRouter = IntentRouter()
) {

    fun isAccessibilityServiceRunning(): Boolean {
        return OpenRingAccessibilityService.isRunning
    }

    /**
     * Dispatches an action tool by name with parameters.
     */
    fun dispatch(toolName: String, params: Map<String, String>, context: Context): ActionResult {
        return when (toolName.trim().lowercase()) {
            ToolSchemas.TOOL_OPEN_APP -> {
                val appName = params["app_name"] ?: params["name"] ?: params["target"] ?: ""
                intentRouter.launchApp(context, appName)
            }
            ToolSchemas.TOOL_CLICK_ELEMENT -> {
                val target = params["target"] ?: params["text"] ?: ""
                actionExecutor.click(target)
            }
            ToolSchemas.TOOL_TYPE_TEXT -> {
                val text = params["text"] ?: params["value"] ?: ""
                val target = params["target"]
                actionExecutor.typeText(text, target)
            }
            ToolSchemas.TOOL_SCROLL -> {
                val direction = params["direction"] ?: "down"
                actionExecutor.scroll(direction)
            }
            ToolSchemas.TOOL_NAVIGATE_BACK -> {
                actionExecutor.pressBack()
            }
            ToolSchemas.TOOL_NAVIGATE_HOME -> {
                actionExecutor.pressHome()
            }
            ToolSchemas.TOOL_READ_SCREEN -> {
                actionExecutor.readScreen()
            }
            else -> {
                ActionResult.failure("Unknown action tool: '$toolName'.", ErrorCode.UNSUPPORTED_ACTION)
            }
        }
    }

    fun openApp(context: Context, appName: String): ActionResult =
        intentRouter.launchApp(context, appName)

    fun click(target: String): ActionResult =
        actionExecutor.click(target)

    fun typeText(text: String, target: String? = null): ActionResult =
        actionExecutor.typeText(text, target)

    fun scroll(direction: String = "down"): ActionResult =
        actionExecutor.scroll(direction)

    fun goBack(): ActionResult =
        actionExecutor.pressBack()

    fun goHome(): ActionResult =
        actionExecutor.pressHome()

    open fun readScreen(): ActionResult =
        actionExecutor.readScreen()
}
