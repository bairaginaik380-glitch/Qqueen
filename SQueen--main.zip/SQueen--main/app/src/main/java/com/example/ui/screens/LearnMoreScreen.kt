package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.QueenBackground
import com.example.ui.theme.QueenBorder
import com.example.ui.theme.QueenBorderGold
import com.example.ui.theme.QueenGold
import com.example.ui.theme.QueenGoldBright
import com.example.ui.theme.QueenGoldSoft
import com.example.ui.theme.QueenSurface
import com.example.ui.theme.QueenSurfaceVariant
import com.example.ui.theme.QueenTextMuted
import com.example.ui.theme.QueenTextPrimary
import com.example.ui.theme.QueenTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LearnMoreScreen(
    onNavigateBack: () -> Unit
) {
    val scrollState = rememberScrollState()

    Scaffold(
        containerColor = QueenBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Learn More",
                        fontWeight = FontWeight.Bold,
                        color = QueenTextPrimary,
                        fontSize = 20.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("learn_more_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = QueenTextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = QueenBackground
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Info Card
            Surface(
                color = QueenSurface,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorderGold),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Queen Access Token Policy",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = QueenGoldBright
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Everything you need to know about your lifetime license, single-device activation, and recovery limitations.",
                        fontSize = 13.sp,
                        color = QueenTextSecondary,
                        lineHeight = 18.sp
                    )
                }
            }

            // CRITICAL WARNING CARD: Factory Reset / Reinstall / Data Clear Notice
            Surface(
                color = Color(0xFF261D0C),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, QueenGoldSoft),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.WarningAmber,
                        contentDescription = "Warning",
                        tint = QueenGoldBright,
                        modifier = Modifier.size(28.dp)
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Access Recovery Warning / महत्वपूर्ण सूचना",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = QueenGoldBright
                        )
                        Text(
                            text = "फ़ोन को Factory Reset करने, ऐप को Reinstall (अनइन्स्टॉल करके पुनः इंस्टॉल) करने, या App Data/Storage Clear करने पर आपके Access Token की recovery की गारंटी नहीं है।",
                            fontSize = 13.sp,
                            color = QueenTextPrimary,
                            fontWeight = FontWeight.Medium,
                            lineHeight = 19.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Factory reset, app reinstall, or clearing application data wipes local keystore credentials. Recovery of access on the same device is NOT guaranteed under these circumstances.",
                            fontSize = 12.sp,
                            color = QueenTextSecondary,
                            lineHeight = 17.sp
                        )
                    }
                }
            }

            // Policy Section 1: Lifetime Single-Device License
            PolicyDetailCard(
                icon = Icons.Default.PhoneAndroid,
                title = "1. Lifetime Single-Device Binding",
                description = "प्रत्येक Access Token केवल एक ही फ़ोन (single physical device) के लिए मान्य होता है। पहली बार activate होने पर token स्थायी रूप से उसी फ़ोन से bind हो जाता है। वही token किसी दूसरे फ़ोन पर स्वीकार नहीं किया जाएगा।"
            )

            // Policy Section 2: Zero Login & Anonymous Authentication
            PolicyDetailCard(
                icon = Icons.Default.Security,
                title = "2. No Login / Private Anonymous Auth",
                description = "ऐप में किसी भी ईमेल, पासवर्ड या गूगल लॉगिन स्क्रीन की आवश्यकता नहीं है। Firebase Anonymous Authentication के माध्यम से आपकी पहचान पूरी तरह निजी और सुरक्षित रहती है।"
            )

            // Policy Section 3: Honest Security & Tamper Notice
            PolicyDetailCard(
                icon = Icons.Default.Info,
                title = "3. Security & Tamper Notice (सुरक्षा की सीमाएं)",
                description = "Client-side Android device checks और Firebase client rules अनधिकृत शेयरिंग को प्रभावी रूप से रोकते हैं। परंतु किसी भी client-side आर्किटेक्चर को रूटेड सिस्टम (rooted devices), कस्टमाइज़्ड रोम या मेमोरी हुकिंग के विरुद्ध 100% अभेद्य (tamper-proof) नहीं कहा जा सकता।"
            )

            // Advice Card
            Surface(
                color = QueenSurfaceVariant,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "सुझाव / Recommendation",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = QueenGoldSoft
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "अपने 10-अक्षरीय Queen Access Token (जैसे Q...) को हमेशा किसी सुरक्षित डायरी या ऑफ़लाइन नोट में लिखकर रखें।",
                        fontSize = 12.sp,
                        color = QueenTextSecondary,
                        lineHeight = 17.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun PolicyDetailCard(
    icon: ImageVector,
    title: String,
    description: String
) {
    Surface(
        color = QueenSurface,
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .background(QueenSurfaceVariant, CircleShape)
                        .border(1.dp, QueenBorderGold, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = QueenGoldSoft,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = QueenTextPrimary
                )
            }
            Text(
                text = description,
                fontSize = 13.sp,
                color = QueenTextSecondary,
                lineHeight = 19.sp
            )
        }
    }
}
