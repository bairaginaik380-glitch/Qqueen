package com.example.data.model

data class VoiceOption(
    val id: String,
    val name: String,
    val description: String,
    val previewGreeting: String,
    val geminiVoiceName: String = id
) {
    companion object {
        val ALL_VOICES = listOf(
            VoiceOption(
                id = "Aoede",
                name = "Aoede (Warm & Playful)",
                description = "Expressive, sweet, and playful voice with a warm companion tone. Ideal for Queen.",
                previewGreeting = "Hey there! I'm Queen. I'm so happy to talk with you today!",
                geminiVoiceName = "Aoede"
            ),
            VoiceOption(
                id = "Kore",
                name = "Kore (Bright & Cheerful)",
                description = "Sunny, upbeat, and enthusiastic cadence with a friendly spark.",
                previewGreeting = "Hello! It's so lovely to hear from you. What are we exploring today?",
                geminiVoiceName = "Kore"
            ),
            VoiceOption(
                id = "Leda",
                name = "Leda (Calm & Soothing)",
                description = "Gentle, serene, and relaxing voice with a calming, empathetic presence.",
                previewGreeting = "Hello there. Take a deep breath, I'm right here with you.",
                geminiVoiceName = "Leda"
            ),
            VoiceOption(
                id = "Puck",
                name = "Puck (Spirited & Witty)",
                description = "Crisp, energetic, and witty delivery with an adventurous vibe.",
                previewGreeting = "Hey! Ready for some great chats? Let's dive right in!",
                geminiVoiceName = "Puck"
            )
        )

        val DEFAULT = ALL_VOICES.first()

        fun getGeminiVoiceName(id: String): String {
            return ALL_VOICES.firstOrNull { it.id.equals(id, ignoreCase = true) }?.geminiVoiceName
                ?: ALL_VOICES.firstOrNull { it.geminiVoiceName.equals(id, ignoreCase = true) }?.geminiVoiceName
                ?: id
        }
    }
}

