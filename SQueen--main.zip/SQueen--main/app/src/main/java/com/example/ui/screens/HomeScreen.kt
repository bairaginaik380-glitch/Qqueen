package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AssistantState
import com.example.ui.components.StarPlayButton
import com.example.ui.theme.QueenBackground
import com.example.ui.theme.QueenBorderGold
import com.example.ui.theme.QueenError
import com.example.ui.theme.QueenGold
import com.example.ui.theme.QueenGoldBright
import com.example.ui.theme.QueenGoldSoft
import com.example.ui.theme.QueenTextMuted
import com.example.ui.theme.QueenTextPrimary
import com.example.ui.theme.QueenTextSecondary
import com.example.ui.viewmodel.AarohiViewModel
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    viewModel: AarohiViewModel,
    onNavigateToSettings: () -> Unit,
    onNavigateToApiKey: () -> Unit,
    onNavigateToCameraVision: () -> Unit,
    onRequestMicAndStart: () -> Unit
) {
    val assistantState by viewModel.assistantState.collectAsState()
    val amplitude by viewModel.amplitude.collectAsState()
    val isSetupComplete by viewModel.isSetupComplete.collectAsState()
    val tamperAlert by viewModel.tamperAlert.collectAsState()
    val pendingCall by viewModel.pendingCall.collectAsState()

    val scope = rememberCoroutineScope()
    var isOpeningCamera by remember { mutableStateOf(false) }
    val cameraOpenProgress = remember { Animatable(0f) }

    fun triggerCameraVisionOpen() {
        if (isOpeningCamera) return
        isOpeningCamera = true
        scope.launch {
            cameraOpenProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing)
            )
            onNavigateToCameraVision()
            cameraOpenProgress.snapTo(0f)
            isOpeningCamera = false
        }
    }

    // Handle back button while voice session is active to cleanly stop and return to Idle
    BackHandler(enabled = assistantState.isActive) {
        viewModel.stopSession()
    }

    if (tamperAlert != null) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissTamperAlert() },
            title = {
                Text(
                    text = "Security Integrity Alert",
                    color = QueenGoldBright,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = tamperAlert ?: "",
                        color = QueenTextPrimary,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Practical defense-in-depth notice: Access to protected AI live session features has been restricted to safeguard credentials. (Note: Client-side integrity checks deter tampering but cannot guarantee total prevention on modified devices.)",
                        color = QueenTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.dismissTamperAlert() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = QueenGoldSoft,
                        contentColor = QueenBackground
                    ),
                    modifier = Modifier.testTag("dismiss_security_alert_button")
                ) {
                    Text("Understood", fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF141416),
            tonalElevation = 6.dp,
            modifier = Modifier.testTag("security_integrity_alert_dialog")
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(QueenBackground)
            // Swipe right-to-left to open Camera Vision (Requirement 1)
            .pointerInput(Unit) {
                detectHorizontalDragGestures { _, dragAmount ->
                    if (dragAmount < -50f && !isOpeningCamera) {
                        triggerCameraVisionOpen()
                    }
                }
            }
            .testTag("home_screen_root")
    ) {
        // MAIN CENTRAL AREA: Large, beautiful 3D-rendered anime character on pure black
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 64.dp, bottom = 100.dp),
            contentAlignment = Alignment.Center
        ) {
            // Subtle, restrained warm golden rim halo behind the character
            Box(
                modifier = Modifier
                    .size(360.dp)
                    .drawBehind {
                        val glowAlpha = when (assistantState) {
                            is AssistantState.Speaking -> 0.16f + amplitude * 0.2f
                            is AssistantState.Listening -> 0.14f + amplitude * 0.2f
                            is AssistantState.Connecting -> 0.12f
                            is AssistantState.Error -> 0.12f
                            else -> 0.08f
                        }
                        val tint = if (assistantState is AssistantState.Error) QueenError else QueenGold
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    tint.copy(alpha = glowAlpha),
                                    Color.Transparent
                                )
                            ),
                            radius = size.width / 1.4f
                        )
                    }
            )

            // Centered 3D Anime Character Illustration
            Image(
                painter = painterResource(id = R.drawable.img_queen_character),
                contentDescription = "Queen AI character portrait",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("queen_character_image")
            )

            // Girl's Head / Face Tap Area — One-shot Gemini Live Voice Test
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth(0.65f)
                    .fillMaxHeight(0.38f)
                    .clip(CircleShape)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        viewModel.testGeminiVoice()
                    }
                    .testTag("queen_head_tap_area")
            )
        }

        // TOP BAR: Queen app icon (left), exact title "Queen" (centered), Camera Vision + Settings icons (right)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Left: Queen app icon (Queen character portrait)
            Surface(
                shape = CircleShape,
                color = Color.Transparent,
                border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorderGold),
                modifier = Modifier
                    .size(38.dp)
                    .align(Alignment.CenterStart)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_queen_icon),
                    contentDescription = "Queen icon",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                        .testTag("queen_top_icon")
                )
            }

            // Center: Exact app title "Queen"
            Text(
                text = "Queen",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = QueenTextPrimary,
                letterSpacing = 1.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.Center)
                    .testTag("queen_title_text")
            )

            // Right: Settings icon
            IconButton(
                onClick = onNavigateToSettings,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .size(44.dp)
                    .testTag("settings_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = QueenGoldSoft
                )
            }
        }

        // RIGHT EDGE SWIPE HINT BADGE (Visual hint that swiping left opens Camera Vision)
        Surface(
            color = Color(0x99141416),
            shape = RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorderGold.copy(alpha = 0.5f)),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .clickable { triggerCameraVisionOpen() }
                .testTag("swipe_to_camera_hint")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Videocam,
                    contentDescription = null,
                    tint = QueenGoldSoft,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = "Vision ‹",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = QueenGoldSoft
                )
            }
        }

        // BOTTOM AREA: Star/Play Button (Compact, elegant, with rotation & gold border)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Subtle, restrained status indicator
            AnimatedVisibility(
                visible = assistantState !is AssistantState.Idle || !isSetupComplete,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                val statusText = when (assistantState) {
                    is AssistantState.Idle -> if (!isSetupComplete) "Setup required to start" else ""
                    is AssistantState.Connecting -> "Connecting to Queen Live..."
                    is AssistantState.Listening -> "Queen is listening..."
                    is AssistantState.Speaking -> "Queen is speaking..."
                    is AssistantState.Interrupted -> "Interrupted"
                    is AssistantState.Reconnecting -> "Reconnecting..."
                    is AssistantState.Error -> (assistantState as AssistantState.Error).message
                }

                if (statusText.isNotEmpty()) {
                    Surface(
                        color = Color(0xDD0D0D0E),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (assistantState is AssistantState.Error) QueenError.copy(alpha = 0.5f)
                            else QueenBorderGold
                        ),
                        modifier = Modifier
                            .padding(horizontal = 24.dp)
                            .padding(bottom = 12.dp)
                    ) {
                        Text(
                            text = statusText,
                            color = when (assistantState) {
                                is AssistantState.Error -> QueenError
                                is AssistantState.Speaking -> QueenGoldBright
                                is AssistantState.Listening -> QueenGold
                                else -> QueenTextSecondary
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                                .testTag("assistant_status_label")
                        )
                    }
                }
            }

            // Quick conversation prompts when session is connected (especially helpful in emulators or quiet environments)
            AnimatedVisibility(
                visible = assistantState is AssistantState.Listening || assistantState is AssistantState.Speaking,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Row(
                    modifier = Modifier
                        .padding(horizontal = 16.dp)
                        .padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("नमस्ते रानी!", "How are you Queen?", "एक चुटकुला सुनाओ").forEach { prompt ->
                        Surface(
                            color = Color(0xAA1C1C20),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, QueenBorderGold.copy(alpha = 0.4f)),
                            modifier = Modifier
                                .clickable { viewModel.sendUserTextMessage(prompt) }
                                .testTag("quick_prompt_${prompt.take(6)}")
                        ) {
                            Text(
                                text = prompt,
                                color = QueenGoldSoft,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }

            // Outgoing Call Confirmation Card (Spoken confirmation or tap to call/cancel)
            AnimatedVisibility(
                visible = pendingCall != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                pendingCall?.let { call ->
                    Surface(
                        color = Color(0xEE1C1C22),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, QueenGoldBright),
                        modifier = Modifier
                            .padding(horizontal = 20.dp)
                            .padding(bottom = 12.dp)
                            .fillMaxWidth()
                            .testTag("pending_call_card")
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "Call ${call.contactName}?",
                                color = QueenGoldBright,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "${call.phoneNumber} • Say 'Yes' or tap Call",
                                color = QueenTextSecondary,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Button(
                                    onClick = { viewModel.cancelPendingCall() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF2C2C32),
                                        contentColor = QueenTextMuted
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("cancel_call_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Cancel call",
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Cancel", fontSize = 13.sp)
                                }
                                Button(
                                    onClick = { viewModel.executePendingCall() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = QueenGoldSoft,
                                        contentColor = QueenBackground
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("confirm_call_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Call,
                                        contentDescription = "Confirm and call",
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Call", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Elegant Center Star/Play Button — exclusively starts and stops Gemini Live session
            StarPlayButton(
                assistantState = assistantState,
                amplitude = amplitude,
                onClick = {
                    if (assistantState.isActive) {
                        viewModel.stopSession()
                    } else if (!isSetupComplete) {
                        onNavigateToApiKey()
                    } else {
                        onRequestMicAndStart()
                    }
                }
            )
        }

        // CIRCULAR SWIPE / LOADING APERTURE ANIMATION (Requirement 1)
        if (isOpeningCamera) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = (cameraOpenProgress.value * 0.85f).coerceIn(0f, 1f))),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    color = Color(0xFF141416),
                    shape = CircleShape,
                    border = androidx.compose.foundation.BorderStroke(
                        (2 + cameraOpenProgress.value * 2).dp,
                        QueenGoldBright
                    ),
                    modifier = Modifier
                        .size((100 + cameraOpenProgress.value * 380).dp)
                        .testTag("camera_swipe_loading_animation")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = "Opening Camera...",
                                tint = QueenGoldBright,
                                modifier = Modifier.size(44.dp)
                            )
                            Text(
                                text = "Opening Vision...",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = QueenGoldBright
                            )
                        }
                    }
                }
            }
        }
    }
}
