package com.example.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * OpenRing Accessibility Service providing screen awareness, event tracking,
 * and programmatic UI automation gestures.
 */
open class OpenRingAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "OpenRingAccessibility"

        @Volatile
        var instance: OpenRingAccessibilityService? = null
            internal set

        val isRunning: Boolean
            get() = instance != null
    }

    @Volatile
    var currentPackageName: String? = null
        private set

    @Volatile
    var foregroundAppPackageName: String? = null
        private set

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "OpenRingAccessibilityService connected successfully")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        currentPackageName = pkg

        // Only track foreground application packages from window state change events,
        // ignoring transient system UI overlays and input methods so background screen reading stays accurate
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && !isTransientSystemPackage(pkg)) {
            foregroundAppPackageName = pkg
            Log.d(TAG, "Foreground app updated: $pkg")
        }
    }

    private fun isTransientSystemPackage(pkg: String): Boolean {
        val lower = pkg.lowercase()
        return lower == "com.android.systemui" ||
            lower == "android" ||
            lower.contains("inputmethod") ||
            lower.contains("keyboard") ||
            lower.contains("navigationbar")
    }

    override fun onInterrupt() {
        Log.w(TAG, "OpenRingAccessibilityService interrupted")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) {
            instance = null
        }
        Log.d(TAG, "OpenRingAccessibilityService unbound")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        Log.d(TAG, "OpenRingAccessibilityService destroyed")
        super.onDestroy()
    }

    /**
     * Safely retrieves the root node in the currently active window,
     * prioritizing the foreground application matching foregroundAppPackageName / currentPackageName.
     * Intermediate candidate nodes are safely recycled to prevent accessibility node leaks.
     */
    @Suppress("DEPRECATION")
    fun getRootNodeSafe(): AccessibilityNodeInfo? {
        val targetPkg = foregroundAppPackageName ?: currentPackageName
        return try {
            var selectedRoot: AccessibilityNodeInfo? = null

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val winList = try { windows } catch (e: Exception) { null }
                if (!winList.isNullOrEmpty()) {
                    val appWindows = winList.filter {
                        it.type == android.view.accessibility.AccessibilityWindowInfo.TYPE_APPLICATION
                    }

                    // 1. Try matching tracked foreground package among application windows
                    if (!targetPkg.isNullOrBlank()) {
                        for (win in appWindows) {
                            val candidate = try { win.root } catch (e: Exception) { null } ?: continue
                            if (candidate.packageName?.toString() == targetPkg) {
                                selectedRoot = candidate
                                break
                            } else {
                                try { candidate.recycle() } catch (ignored: Exception) {}
                            }
                        }
                    }

                    // 2. If no target match yet, try active or focused application window
                    if (selectedRoot == null) {
                        val activeAppWin = appWindows.firstOrNull { it.isActive }
                            ?: appWindows.firstOrNull { it.isFocused }
                            ?: appWindows.firstOrNull()
                        if (activeAppWin != null) {
                            selectedRoot = try { activeAppWin.root } catch (e: Exception) { null }
                        }
                    }

                    // 3. Fallback to any active window in windows list
                    if (selectedRoot == null) {
                        val anyActive = winList.firstOrNull { it.isActive }
                            ?: winList.firstOrNull { it.isFocused }
                        if (anyActive != null) {
                            selectedRoot = try { anyActive.root } catch (e: Exception) { null }
                        }
                    }
                }
            }

            // 4. Fallback to rootInActiveWindow if windows traversal yielded nothing
            if (selectedRoot == null) {
                selectedRoot = rootInActiveWindow
            }

            Log.d(
                TAG,
                "getRootNodeSafe: serviceActive=${instance != null}, rootFound=${selectedRoot != null}, activePkg=${targetPkg ?: "unknown"}, selectedRootPkg=${selectedRoot?.packageName ?: "none"}"
            )
            selectedRoot
        } catch (e: Exception) {
            Log.e(TAG, "Failed to retrieve root node: ${e.message}")
            null
        }
    }

    /**
     * Dispatches a tap gesture at the specified screen coordinates synchronously.
     */
    fun dispatchTap(x: Float, y: Float, timeoutMs: Long = 1000L): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false

        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        return dispatchGestureSync(gesture, timeoutMs)
    }

    /**
     * Dispatches a swipe gesture between two points synchronously.
     */
    fun dispatchSwipe(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long = 300L,
        timeoutMs: Long = 1500L
    ): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false

        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(50))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        return dispatchGestureSync(gesture, timeoutMs)
    }

    /**
     * Dispatches a long-press gesture at the specified coordinate.
     */
    fun dispatchLongPress(x: Float, y: Float, durationMs: Long = 800L, timeoutMs: Long = 1500L): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false

        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        return dispatchGestureSync(gesture, timeoutMs)
    }

    /**
     * Dispatches a gesture synchronously with latch countdown on result callback.
     */
    private fun dispatchGestureSync(gesture: GestureDescription, timeoutMs: Long): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false

        val latch = CountDownLatch(1)
        var gestureCompleted = false

        val callback = object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                gestureCompleted = true
                latch.countDown()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                gestureCompleted = false
                latch.countDown()
            }
        }

        val handler = Handler(Looper.getMainLooper())
        val dispatched = dispatchGesture(gesture, callback, handler)
        if (!dispatched) {
            return false
        }

        return try {
            latch.await(timeoutMs, TimeUnit.MILLISECONDS) && gestureCompleted
        } catch (e: InterruptedException) {
            false
        }
    }
}
