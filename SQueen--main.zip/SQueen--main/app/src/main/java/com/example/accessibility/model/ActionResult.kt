package com.example.accessibility.model

/**
 * OpenRing Error Codes indicating specific failure reasons during screen/action execution.
 */
enum class ErrorCode {
    SERVICE_NOT_CONNECTED,
    NODE_NOT_FOUND,
    ACTION_FAILED,
    UNSUPPORTED_ACTION,
    PERMISSION_DENIED,
    APP_NOT_FOUND,
    CONFIRMATION_REQUIRED,
    TIMEOUT
}

/**
 * Standard result model returned by ActionExecutor, IntentRouter, and ToolDispatcher.
 */
data class ActionResult(
    val isSuccess: Boolean,
    val message: String,
    val errorCode: ErrorCode? = null,
    val data: Any? = null
) {
    companion object {
        fun success(message: String, data: Any? = null): ActionResult =
            ActionResult(isSuccess = true, message = message, errorCode = null, data = data)

        fun failure(message: String, errorCode: ErrorCode, data: Any? = null): ActionResult =
            ActionResult(isSuccess = false, message = message, errorCode = errorCode, data = data)
    }
}
